#!/usr/bin/env ruby


require 'optparse'
require 'pp'
require 'ostruct'
require 'benchmark'

if not ENV["AUDLIB"]
    p "You must set the $AUDLIB variable to the audlib src directory. (Probably trunk/audlib)"
    exit
end

$lib_combos = [:A, :I, :M, :AM, :IM, :IA, :MA, :MI, :AI, :IAM, :AIM, :MIA, :IMA, :AMI, :MAI]

class OptParse
  def self.parse(args)
    options = OpenStruct.new
    opts = OptionParser.new do |opts|
      opts.banner = <<END
Usage: audlib_eval.rb [options] command
Run a given command using audlib and optionally display information collected from its logs.
By default, runs with the combination AIM.

END

      opts.on("-lLIBRARIES", "--libraries LIBRARIES", $lib_combos, "Only eval with the library order LIBRARIES\n \
                                    Must be in the form [A|I|M][A|I|M][A|I|M]") do |l|
        options.libraries = l
      end
      opts.on("-a", "--all-combinations", "Evaluate the program with each possible combination of audlib libraries") do
        options.all_combinations = true
      end
      opts.on("-q", "--quiet", "Don't show the command's output") do
        options.quiet = true
      end

      opts.on("-p", "--parseable", "Call logreader with the parseable output option") do
        options.parseable = true
      end
      opts.on("-s", "--save-logs", "Save the logs even if no parsing errors occured") do
        options.save = true
      end
      opts.on("-S", "--size", "Show the size of the logs in human readable format") do
        options.size = true
      end
      opts.on("-b[ITERATIONS]", "--benchmark[ITERATIONS]", "Show the execution time for each run") do |b|
        options.benchmark = true
        options.iterations = b.to_i
      end
      opts.on("-n", "--no-logging", "Send logs to /dev/null (for benchmarking)") do
        options.no_logging = true
      end
      opts.on("-v", "--verbose", "Show the full logreader output") do
        options.verbose = true
      end
      opts.on("-t", "--table", "Print a table of stats about the log files\n \
                                    Entries are prefixed by A:, I:, or M:, indicating from which library it originated.  ") do
        options.table = true
      end
      opts.on_tail("-h", "--help", "Show this message") do
      end
    end
    begin
      opts.parse!(args)
    rescue Exception => e
      puts e, "", opts
      exit
    end
    if ARGV.size == 0
      puts opts
      exit
    end
    options
  end  # parse()
end

@options = OptParse.parse(ARGV)
if @options.benchmark and not @options.iterations
    @options.iterations = 1 # set default iterations if not specified
end

  # This won't work well for multiple simultaneous runs
  #export AUDLIB_ATTACK=./audlib_attack.out
  #export AUDLIB_INTRUSION=./audlib_intrusion.out
  #export AUDLIB_MISUSE=./audlib_misuse.out

  # This is ideal, but not so good for testing/debugging (keeping copies)
  #export AUDLIB_ATTACK=`mktemp ./out.audlib_attack.XXXXXX`
  #export AUDLIB_INTRUSION=`mktemp ./out.audlib_intrusion.XXXXXX`
  #export AUDLIB_MISUSE=`mktemp ./out.audlib_misuse.XXXXXX`

if @options.no_logging
    ENV['AUDLIB_INTRUSION'] = "/dev/null"
    ENV['AUDLIB_MISUSE'] = "/dev/null"
    ENV['AUDLIB_ATTACK'] = "/dev/null"
else
    ENV['AUDLIB_INTRUSION'] = "/tmp/out.#{$$}.audlib_intrusion"
    ENV['AUDLIB_MISUSE'] = "/tmp/out.#{$$}.audlib_misuse"
    ENV['AUDLIB_ATTACK'] = "/tmp/out.#{$$}.audlib_attack"
end


@command = {}

@command[:A] = 'LD_PRELOAD="$AUDLIB/src/libaudlib_attack.so" '
@command[:I] = 'LD_PRELOAD="$AUDLIB/src/libaudlib_intrusion.so" '
@command[:M] = 'LD_PRELOAD="$AUDLIB/src/libaudlib_misuse.so" '

@command[:AM] = 'LD_PRELOAD="$AUDLIB/src/libaudlib_attack.so $AUDLIB/src/libaudlib_misuse.so" '
@command[:IM] = 'LD_PRELOAD="$AUDLIB/src/libaudlib_intrusion.so $AUDLIB/src/libaudlib_misuse.so" '
@command[:IA] = 'LD_PRELOAD="$AUDLIB/src/libaudlib_intrusion.so $AUDLIB/src/libaudlib_attack.so " '
@command[:MA] = 'LD_PRELOAD="$AUDLIB/src/libaudlib_misuse.so $AUDLIB/src/libaudlib_attack.so" '
@command[:MI] = 'LD_PRELOAD="$AUDLIB/src/libaudlib_misuse.so $AUDLIB/src/libaudlib_intrusion.so" '
@command[:AI] = 'LD_PRELOAD="$AUDLIB/src/libaudlib_attack.so $AUDLIB/src/libaudlib_intrusion.so" '

@command[:IAM] = 'LD_PRELOAD="$AUDLIB/src/libaudlib_intrusion.so $AUDLIB/src/libaudlib_attack.so $AUDLIB/src/libaudlib_misuse.so" '
@command[:AIM] = 'LD_PRELOAD="$AUDLIB/src/libaudlib_attack.so $AUDLIB/src/libaudlib_intrusion.so $AUDLIB/src/libaudlib_misuse.so" '
@command[:MIA] = 'LD_PRELOAD="$AUDLIB/src/libaudlib_misuse.so $AUDLIB/src/libaudlib_intrusion.so $AUDLIB/src/libaudlib_attack.so" '
@command[:IMA] = 'LD_PRELOAD="$AUDLIB/src/libaudlib_intrusion.so $AUDLIB/src/libaudlib_misuse.so $AUDLIB/src/libaudlib_attack.so" '
@command[:AMI] = 'LD_PRELOAD="$AUDLIB/src/libaudlib_attack.so $AUDLIB/src/libaudlib_misuse.so $AUDLIB/src/libaudlib_intrusion.so" '
@command[:MAI] = 'LD_PRELOAD="$AUDLIB/src/libaudlib_misuse.so $AUDLIB/src/libaudlib_attack.so $AUDLIB/src/libaudlib_intrusion.so" '

@libraries = [:AIM]

if @options.libraries
    @libraries = [@options.libraries]
elsif @options.all_combinations
    @libraries = @command.keys.sort_by {|sym| sym.to_s }.sort_by {|sym| sym.to_s.length}
end

def run_command lib_str
  if @options.quiet
      `#{lib_str} #{ARGV[0]}`
  else
      system("#{lib_str} #{ARGV[0]}")
  end
end

def benchmark(bm, lib)
      bm.report(lib.to_s + ":") { @options.iterations.times { run_command(@command[lib]) } }
end

if @options.benchmark
    Benchmark.bmbm(5) do |x|
        @libraries.each do |lib|
            benchmark(x, key)
        end
    end
else
    @libraries.each do |lib| 
        run_command(@command[lib])
    end
end

ret = 0
if @options.verbose and not @options.no_logging #show the actual logreader output
    data = ""
    ["$AUDLIB_ATTACK", "$AUDLIB_INTRUSION", "$AUDLIB_MISUSE"].each do |lib|
        if @options.parseable
            data += `$AUDLIB/../audlogread/logreader -p #{lib}`
        else
            data += `$AUDLIB/../audlogread/logreader #{lib}`
        end
        ret += $?.to_i
    end
    puts data
end

if @options.table and not @options.no_logging #show tallies collected from call_count.pl
  data = `$AUDLIB/call_count.pl $AUDLIB_ATTACK $AUDLIB_INTRUSION $AUDLIB_MISUSE`
  ret = $?.to_i
  puts data
end

if @options.size
    system("du -h $AUDLIB_ATTACK $AUDLIB_INTRUSION $AUDLIB_MISUSE")
end

#p "Tabulating logged calls in $1"
if not @options.no_logging
    if ret == 0 and not @options.save 
  `rm -f "$AUDLIB_ATTACK" "$AUDLIB_INTRUSION" "$AUDLIB_MISUSE"`
    else
        p "Exit was #{ret} -- saving log files for pid=#{$$} in /tmp/"
    end
end

