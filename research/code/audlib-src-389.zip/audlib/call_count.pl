eval 'exec perl -x $0 ${1+"$@"}' # -*-perl-*-
    if 0;
#!perl -w

###
# call_count.pl
#
# Benjamin A. Kuperman 
# 10 June 2007
###

# $Id$

my %counts;
my $retval=0;

# Pass each file through the logreader
foreach $file (@ARGV) {
    open INPUT, "\$AUDLIB/../audlogread/logreader -p $file |" or die "Can't open logreader input: $!";
    # take each liine of input and process it
    while (<INPUT>) {
        next unless /^#(\d+) #(\d+) "([AIM][^"]+)"/;    # contains a call
        my $pid = $1;
        my $ppid = $2;
        my $callname = $3;
        $callname =~ s/%3a/:/ig;    # un-encode certain strings
        $callname =~ s/%2d/-/ig;
        $callname =~ s/%5f/_/ig;
        $counts{$callname}++;       # increase the count
    }
    close INPUT;
    $retval += $? >> 8;
}

# Probably want to see things sorted
my @results;
foreach $key (sort keys %counts) {
    push @results, sprintf("%8d : %s", $counts{$key}, $key); # one line each
}

# print them out in sorted order
foreach $line (sort @results) {
    print "$line \n";
}

exit $retval;
