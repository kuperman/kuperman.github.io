echo "int main() { return 0; }" > AUD_TEMP.c
gcc AUD_TEMP.c -o AUD_TEMP
LIBC_PATH=`ldd AUD_TEMP | grep libc | cut -d' ' -f3`
echo "libc path is found to be $LIBC_PATH"
sed -i "s:LIBC_PATH=[[:alnum:][:punct:]]*:LIBC_PATH=\\\\\"$LIBC_PATH\\\\\":" src/Makefile
rm AUD_TEMP AUD_TEMP.c

echo "#include <stdlib.h>
#include <dlfcn.h>
int main(int argc, char * argv[]) { 
    void * libc_ptr = dlopen(\"$LIBC_PATH\",RTLD_LAZY); 
    return (NULL == dlsym(libc_ptr, argv[1])); 
}" > AUD_TEMP.c
gcc -ldl AUD_TEMP.c -o AUD_TEMP
if ./AUD_TEMP __xstat
then
    sed -i 's:^XSTAT.*$:XSTAT= -DXSTAT #(DO NOT REMOVE THIS LINE):' src/Makefile
else
    sed -i "s:^XSTAT.*$:XSTAT= #(DO NOT REMOVE THIS LINE):" src/Makefile
fi

rm AUD_TEMP AUD_TEMP.c
