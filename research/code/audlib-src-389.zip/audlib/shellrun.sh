#!/bin/bash

# see if $AUDLIB exists and is set
if [ -z "${AUDLIB+xxx}" ] || ([ -z "$AUDLIB" ] && [ -z "${AUDLIB+xxx}" = "xxx" ])
   then echo "The AUDLIB variable must be set to the source directory for audlib. (probably trunk/audlib)"
        echo "Set this by typing 'export AUDLIB=\"/path/to/audlib/\"' "
fi

# set log storage locations
export AUDLIB_INTRUSION="/tmp/out.$$.audlib_intrusion"
export AUDLIB_MISUSE="/tmp/out.$$.audlib_misuse"
export AUDLIB_ATTACK="/tmp/out.$$.audlib_attack"    

# parse function arguments
opts=0
while getopts ":l:aqpsSb:nvthA" opt
    do
        case "$opt" in
            "l")
                libs=$OPTARG
                opts=`expr $opts + 2`
                ;;
            "a")
                all="a"
                ;;
            "q")
                quiet="q"
                ;;
            "p")
                parse="p"
                ;;
            "s")
                save="s"
                ;;
            "S")
                size="S"
                ;;
            "b")
                bench="b"
                times=$OPTARG
                opts=`expr $opts + 2`
                ;;
            "n")
                nolog="n"
                #send logs to /dev/null to prevent them from being stored
                export AUDLIB_INTRUSION="/dev/null"
                export AUDLIB_MISUSE="/dev/null"
                export AUDLIB_ATTACK="/dev/null"
                ;;
            "v")
                verb="v"
                ;;
            "t")
                tab="t"
                ;;
            "A")
                special="A"
                ;;
            "?") 
                echo "Bad parameter $OPTARG.  Use option h for help"
                exit 0
                ;;
            ":")
                echo "Option $OPTARG expects an argument. Use option h for help"
                exit 0
                ;;
            "h")
                #show help banner.  Maybe use printf instead of echo?
                echo "Usage: aud_run [options] command"
                echo "Run a given command using audlib and optionally display information collected from its logs.  "
                echo "By default, runs with the combination AIM."
                echo "-l [LIBRARIES] Only eval with the library order LIBRARIES. Must be like AI or MIA or M."
                echo "-a Evaluate the command with each possible combination of audlib libraries"
                echo "-q Don't show the command's output"
                echo "-p Call logreader with the parseable output option"
                echo "-s Save the logs even if no parsing errors occured"
                echo "-S Show the size of the logs in human readable format"
                echo "-b [ITERATIONS] Show the execution time for each run"
                echo "-n Send logs to /dev/null (no logging) (for benchmarking)"
                echo "-v Show the full logreader output"
                echo "-t Print a table of stats about the log files. Entries are prefixed by A:, I:, or M:, indicating from which library it originated.  "
                echo "-h Show this message"
                exit 0
        esac 
        hasopts=1
done 
    
# if there are options we havent detected, then (hopefully) they are all in one block    
if [ "$hasopts" = "1" ] && [ "$opts" = "0" ]
    then opts=1
fi

              
# make sure we arent trying to use a specific combination and every combination
if [ ! -z $libs ] && [ ! -z $all ]
    then echo "Ignoring option a"
    unset all
fi

# make sure some libraries have been selected - default case
if [ -z $libs ] && [ -z $all ]
    then libs="AIM"
fi

# set the LD_PRELOAD var
if [ ! -z $libs ]
    then 
    if [ $libs == "A" ] 
        then export LD_PRELOAD="$AUDLIB/src/libaudlib_attack.so"
    elif [ $libs == "I" ]
        then export LD_PRELOAD="$AUDLIB/src/libaudlib_intrusion.so"
    elif [ $libs == "M" ]
        then export LD_PRELOAD="$AUDLIB/src/libaudlib_misuse.so" 
    elif [ $libs == "AM" ]
         then export LD_PRELOAD="$AUDLIB/src/libaudlib_attack.so $AUDLIB/src/libaudlib_misuse.so" 
    elif [ $libs == "IM" ]
        then export LD_PRELOAD="$AUDLIB/src/libaudlib_intrusion.so $AUDLIB/src/libaudlib_misuse.so" 
    elif [ $libs == "IA" ]
        then export LD_PRELOAD="$AUDLIB/src/libaudlib_intrusion.so $AUDLIB/src/libaudlib_attack.so " 
    elif [ $libs == "MA" ]
        then export LD_PRELOAD="$AUDLIB/src/libaudlib_misuse.so $AUDLIB/src/libaudlib_attack.so" 
    elif [ $libs == "MI" ]
        then export LD_PRELOAD="$AUDLIB/src/libaudlib_misuse.so $AUDLIB/src/libaudlib_intrusion.so" 
    elif [ $libs == "AI" ]
        then export LD_PRELOAD="$AUDLIB/src/libaudlib_attack.so $AUDLIB/src/libaudlib_intrusion.so" 
    elif [ $libs == "IAM" ]
        then export LD_PRELOAD="$AUDLIB/src/libaudlib_intrusion.so $AUDLIB/src/libaudlib_attack.so $AUDLIB/src/libaudlib_misuse.so"
    elif [ $libs == "AIM" ] 
        then export LD_PRELOAD="$AUDLIB/src/libaudlib_attack.so $AUDLIB/src/libaudlib_intrusion.so $AUDLIB/src/libaudlib_misuse.so" 
    elif [ $libs == "MIA" ]
        then export LD_PRELOAD="$AUDLIB/src/libaudlib_misuse.so $AUDLIB/src/libaudlib_intrusion.so $AUDLIB/src/libaudlib_attack.so" 
    elif [ $libs == "IMA" ]
        then export LD_PRELOAD="$AUDLIB/src/libaudlib_intrusion.so $AUDLIB/src/libaudlib_misuse.so $AUDLIB/src/libaudlib_attack.so" 
    elif [ $libs == "AMI" ]
        then export LD_PRELOAD="$AUDLIB/src/libaudlib_attack.so $AUDLIB/src/libaudlib_misuse.so $AUDLIB/src/libaudlib_intrusion.so" 
    elif [ $libs == "MAI" ]
        then export LD_PRELOAD="$AUDLIB/src/libaudlib_misuse.so $AUDLIB/src/libaudlib_attack.so $AUDLIB/src/libaudlib_intrusion.so" 
    fi
fi

# verbose mode shows you the LD_PRELOAD variable
if [ "$verb" = "v" ] && [ -z $all ]
    then echo "LD_PRELOAD=$LD_PRELOAD"
fi

#Then the rest of the arguments are the function we want to run

#shift out the parameters passed to this script.
shift $opts

if [ -z $all ]
    then
        if [ -z $bench ] 
            then    
                if [ -z $quiet ] 
                    then 
                        $* #run command as usual now that the vars have been set
                    else
                        $* > /dev/null #redirect output to dev/null so it isnt displayed
                fi
            else 
                if [ -z $quiet ]
                    then
                        for (( i=1; i<=$times; i++ ))
                            do
                                time $* #time the run
                        done
                    else
                        for (( i=1; i<=$times; i++ ))
                            do
                                time $* > /dev/null #time the run, supress output
                        done
                fi
        fi
	retval=$?
    else # a was set and we're going to recursively call ourself with the same options
        for lib in "A" "I" "M" "AM" "IM" "IA" "MA" "MI" "AI" "IAM" "AIM" "MIA" "IMA" "AMI" "MAI"
        do
            unset all
            libs=$lib
            source $0 "-A" $* #a bit hacky?  Keeps persistent pid
        done
fi

errs=0      
#if we're verbose and keeping logs, display the logs with logreader
if [ "$verb" = "v" ] && [ -z $nolog ] && [ -z $all ]
    then
    unset LD_PRELOAD
    for type in $AUDLIB_ATTACK $AUDLIB_INTRUSION $AUDLIB_MISUSE 
    do
        if [ "$parse" = "p" ]
            then 
                $AUDLIB/../audlogread/logreader -p $type
            else
                 $AUDLIB/../audlogread/logreader $type
         fi
         errs=`expr $errs + $?`
    done
fi

#If we asked for a table and we have logs, make one
if [ "$tab" = "t" ] && [ -z $nolog ] && [ -z $all ]
    then
    unset LD_PRELOAD
    $AUDLIB/call_count.pl $AUDLIB_ATTACK $AUDLIB_INTRUSION $AUDLIB_MISUSE
    errs=`expr $errs + $?`
fi

#display size of log dirs       
if [ "$size" = "S" ] && [ -z $all ]
   then du -h $AUDLIB_ATTACK $AUDLIB_INTRUSION $AUDLIB_MISUSE
fi

#exit and delete logs if appropriate
if [ -z $nolog ] && [ -z $all ]
    then
        if [ "$errs" = "0" ] && [ -z $save ]
            then
                rm -f "$AUDLIB_ATTACK" "$AUDLIB_INTRUSION" "$AUDLIB_MISUSE" 
            else 
                echo "Exiting with code $errs.  Log files saved for pid $$ in /tmp/"
        fi
    else echo "No logs generated.  Or a strange mixup."
fi				

exit $retval