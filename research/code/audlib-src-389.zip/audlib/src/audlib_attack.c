// vim:sw=4
#define log_newent(x)	    audlib_log_newent("A:" x, A_pid, A_ppid)
#define log_commitent(x)    audlib_log_commitent(x,A_fd) 
#define INITIALIZED         attack_initialized
#define LIB_LETTER          "A"

/*
 * audlib_attack.c
 *
 * Benjamin A. Kuperman
 * 02 July 2002
 */

/*
 * $Id: audlib_attack.c 380 2010-07-27 22:39:47Z jakimmel $
 *
 */

#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdarg.h>
#include <sys/resource.h>   /* for getrlimit */
#include <sysexits.h>
#include "macros.h"
#include "proclib.h"
#include "protos.h"
#include "logent.h"
#include "whereptr.h"
#include "error.h"


/*------------------------------------------------------------------------
 * prototypes
 *------------------------------------------------------------------------
 */
/* audlib_attack.c */
void audlib_attack_init(void);
void audlib_attack_fini(void);

/*------------------------------------------------------------------------
 * macros
 *------------------------------------------------------------------------
 */
void __attribute__ ((constructor)) audlib_attack_init(void);
void __attribute__ ((destructor))  audlib_attack_fini(void);

/*------------------------------------------------------------------------
 * Global Variables
 *------------------------------------------------------------------------
 */
static FILE *A_output;	/* where to put the output */
static int  A_fd=-1;	/* file descriptor to use */
static pid_t A_pid;
static pid_t A_ppid;
static int attack_initialized=0;

/*------------------------------------------------------------------------
 * 
 ##
 #    #    #     #     #####          #  #            ######     #    #    #    #
 #    ##   #     #       #             ##             #          #    ##   #    #
 #    # #  #     #       #            ###             #####      #    # #  #    #
 #    #  # #     #       #           #   # #          #          #    #  # #    #
 #    #   ##     #       #           #    #           #          #    #   ##    #
 #    #    #     #       #            ###  #          #          #    #    #    #
 
 *------------------------------------------------------------------------
 */

#include <sys/procfs.h>
/*------------------------------------------------------------------------
 * init and fini
 *------------------------------------------------------------------------
 */
void audlib_attack_init() {
    char *currentwd;
    int i;
    int curent;
    int openlog_succeeded;
    intptr_t should_interp;
    procInfo_t *procinfo=NULL;
    
    
#ifdef DEBUG
    audlib_debug("entering audlib_attack_init");
    
    audlib_debug("getting filename");
#endif
    /* do global initializations if needed */
    audlib_initialize();
    openlog_succeeded = audlib_openlog("AUDLIB_ATTACK",&A_fd,&A_output); 
    
    /* get the pid */
#ifdef DEBUG
    audlib_debug("Get the pid");
#endif
    if (-1 == (A_pid=getpid())) {
        /* failed to get the pid */
#ifdef DEBUG
        audlib_debug("attack lib couldn't get the pid");
#endif
        audlib_error(AUD_CANT_GET_PID, "A:init");
    }
    if (-1 == (A_ppid=getppid())) {
        /* failed to get the pid */
        audlib_error(AUD_CANT_GET_PPID, "A:init");
    }
#ifdef DEBUG
    audlib_debug("pid is %d",A_pid);
#endif
    
    procinfo = getProcInfo();
    AUDLIB_LOOKUP_INTERP(should_interp, procinfo->execpath); //see if we should interpose this program
    init_whereptr(); //Read the /proc/self/maps file to enable pointer location identification
    
    
    if (NULL == (currentwd = aud_getcwd())) {
        //failed get current working directory
        audlib_error(AUD_CANT_GET_CWD, "A:init");
    }
    
    //if openlog failed, don't log anything
    attack_initialized = (openlog_succeeded && should_interp);
    if (attack_initialized) {
        if (-1 == (curent = log_newent("init"))) {
            audlib_error(AUD_CANT_MAKE_LOG_ENTRY, "A:init");
        }
        audlib_log_uid(curent, procinfo->ruid);
        audlib_log_uid(curent, procinfo->euid);
        audlib_log_uid(curent, procinfo->suid);
        audlib_log_gid(curent, procinfo->rgid);
        audlib_log_gid(curent, procinfo->egid);
        audlib_log_gid(curent, procinfo->sgid);
        audlib_log_str(curent, currentwd);
        audlib_log_int(curent, procinfo->argc);
        audlib_log_buffer(curent, procinfo->cmdline,
                          procinfo->cmdline_size);
        audlib_log_int(curent, procinfo->envcount);
        for (i=0; i<procinfo->envcount;i++) {
            audlib_log_str(curent, environ[i]);
        }
        log_commitent(curent);
    }
    
#ifdef DEBUG
    audlib_debug("exiting  audlib_attack_init");
#endif
}

void audlib_attack_fini() {
    if (attack_initialized) {
        attack_initialized=0;
#ifdef DEBUG 
        audlib_debug("entering audlib_attack_fini");
#endif
        
        //empty log message
        log_commitent(log_newent("fini"));
        
        if (stderr != A_output) {
            (*__fcloseptr)(A_output);
        }
#ifdef DEBUG 
        audlib_debug("exiting  audlib_attack_fini");
#endif
    }
}

/*------------------------------------------------------------------------
 * close - this is to prevent problems with someone trying to close our
 * file descriptor that we are using to generate logging messages
 *------------------------------------------------------------------------
 */
#ifdef CLOSE_FIX
int close(int fildes) {
    static  int (*fptr)(int )=NULL;
    static intptr_t log_enabled =  true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(int ),"close",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        /* I think the problems comes from something trying to close my FD */
        if (fildes==A_fd) {
            curent = log_newent("close-fail");
            audlib_log_int(curent, fildes);
            log_commitent(curent);
            return(-1);
        }
    }
    return((*fptr)(fildes));
}
#endif

int getrlimit(__rlimit_resource_t resource, struct rlimit *rlp) {
    static int (*fptr)(__rlimit_resource_t, struct rlimit *)=NULL;
    static intptr_t log_enabled = false;
    int ret;
    int curent;
    
    AUDLIB_LOOKUP_COMMAND( int (*)(__rlimit_resource_t,struct rlimit *),
                          "getrlimit",fptr,-1,log_enabled,LIB_LETTER);
    ret=(*fptr)(resource,rlp);
    
    if (attack_initialized) {
        /* we are using the highest available fd for myself */
        if (RLIMIT_NOFILE == resource) {
            rlp->rlim_cur -= 1; /* return one less */
            if(log_enabled) {
                curent = log_newent("getrlimit-fix");
                audlib_log_int(curent, rlp->rlim_cur);
                log_commitent(curent);
            }
        }
    }
    
    return(ret);
}

/* undefine this to not have buffer overflow attacks */
#define BO_ATTACKS
#define TOCTTOU_ATTACKS


/*------------------------------------------------------------------------
 * 
 * #####  ###### #####   ####  #    # ######  ###### #      #      #
 * #    # #      #    # #    # #    # #     # #      #      #      #
 * #    # #      #    # #    # #    # #     # #      #      #      #
 * #####  ###### #####  #    # #    # ######  ###### #      #      #
 * #    # #      #    # #    # #    # #     # #      #      #      #
 * #    # #      #    # #    #  #  #  #     # #      #       # ## #
 * #####  #      #    #  ####    ##   #     # #      ######   #  #
 * 
 *------------------------------------------------------------------------
 */

#ifdef BO_ATTACKS
/*------------------------------------------------------------------------ 
 * strcpy - 
 *------------------------------------------------------------------------
 */
char *strcpy(char *dst, const char *src) {
    static char *(*fptr)(char *, const char *)=NULL;    
    static intptr_t log_enabled =  true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(char *(*)(char *, const char *),"strcpy",fptr,NULL,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("strcpy");
        /* each string argument */
        /* output DEST then SRC */
        audlib_log_dst(curent, dst);
        audlib_log_str(curent, src);
        log_commitent(curent);
    }
    
    return((*fptr)(dst,src));
}


/*------------------------------------------------------------------------ 
 * strcat - 
 *------------------------------------------------------------------------
 */
char *strcat(char *s, const char *append) {
    static char *(*fptr)(char *, const char *)=NULL;
    static intptr_t log_enabled =  true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(char *(*)(char *, const char *),"strcat",fptr,NULL,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("strcat");
        audlib_log_str(curent, s);
        audlib_log_str(curent, append);
        log_commitent(curent);
    }
    
    return((*fptr)(s,append));
}


/*------------------------------------------------------------------------ 
 * gets - 
 *------------------------------------------------------------------------
 */
char *gets(char *str) {
    static char *(*fptr)(char *)=NULL;
    static intptr_t log_enabled =  true;
    char *ret;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(char *(*)(char *),"gets",fptr,NULL,log_enabled,LIB_LETTER);
    
    //log entry before calling function 
    if (attack_initialized && log_enabled) {
        curent = log_newent("gets_pre");
        audlib_log_dst(curent, str);
        log_commitent(curent);
    }
    
    /* In this case, it would be useful to have the input */
    ret=(*fptr)(str);
    
    //log entry with input received from stdin
    if (attack_initialized && log_enabled) {
        curent = log_newent("gets");
        audlib_log_str(curent, str);
        log_commitent(curent);
    }
    
    return(ret);
}

#ifdef HAS_VSCANF
/*------------------------------------------------------------------------ 
 * scanf - 
 *------------------------------------------------------------------------
 */
int scanf(const char *format, ...) {
    va_list ap;
    int ret;
    int curent;
    
    static int (*fptr)(const char *, ...)=NULL;
    static intptr_t log_enabled =  true;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, va_list),"vscanf",fptr,0,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    va_start(ap,format);
    if (attack_initialized && log_enabled) {
        /* can't normally count the arguments because (according to the varargs
         * manpage) it is up to the callee to determine where it ends.  It
         * suggests that this is to be determined based on the format string
         */
        curent = log_newent("scanf");
        audlib_log_str(curent, format);
        log_commitent(curent);
        
    }
    ret=(*fptr)(format,ap);
    va_end(ap);
    return(ret);
}
#endif


/*------------------------------------------------------------------------ 
 * vscanf - 
 *------------------------------------------------------------------------
 */
int vscanf(const char *format, va_list ap) {
    int curent;
    
    static int (*fptr)(const char *, va_list )=NULL;
    static intptr_t log_enabled =  true;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, va_list ),"vscanf",fptr,0,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("vscanf");
        audlib_log_str(curent, format);
        log_commitent(curent);
    }
    
    return((*fptr)(format,ap));
}


#ifdef HAS_VFSCANF
/*------------------------------------------------------------------------ 
 * fscanf - 
 *------------------------------------------------------------------------
 */
int fscanf(FILE *stream, const char *format, ...) {
    static int (*fptr)(FILE *, const char *, va_list)=NULL;
    static intptr_t log_enabled =  true;
    va_list ap;
    int ret, size;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(FILE *, const char *, va_list),"vfscanf",fptr,
                          0,log_enabled,LIB_LETTER);
    
    /* generate audit information */
	va_start(ap,format);
    if (attack_initialized && log_enabled) {
        curent = log_newent("fscanf");
        audlib_log_str(curent, format);
        log_commitent(curent);
    }
    ret=(*fptr)(stream,format,ap);
    va_end(ap);
    return(ret);
}
#endif


/*------------------------------------------------------------------------ 
 * vfscanf - 
 *------------------------------------------------------------------------
 */
int vfscanf(FILE *stream, const char *format, va_list ap) {
    static int (*fptr)(FILE *, const char *, va_list )=NULL;
    static intptr_t log_enabled =  true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(FILE *, const char *, va_list ),"vfscanf",fptr,
                          0,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("vfscanf");
        audlib_log_str(curent, format);
        log_commitent(curent);
    }
    
    return((*fptr)(stream,format,ap));
}


#ifdef HAS_VSSCANF
/*------------------------------------------------------------------------ 
 * sscanf - 
 *------------------------------------------------------------------------
 */
int sscanf(const char *str, const char *format, ...) {
    static int (*fptr)(const char *, const char *, ...)=NULL;
    static intptr_t log_enabled =  true;
    va_list ap;
    int ret;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, const char *, ...),"vsscanf",
                          fptr,0,log_enabled,LIB_LETTER);
    
    /* generate audit information */
	va_start(ap,format);
    if (attack_initialized && log_enabled) {
        curent = log_newent("sscanf");
        audlib_log_str(curent, str);
        audlib_log_str(curent, format);
        log_commitent(curent);
    }
    ret=(*fptr)(str,format,ap);
    va_end(ap);
    
    return(ret);
}
#endif


/*------------------------------------------------------------------------ 
 * vsscanf - 
 *------------------------------------------------------------------------
 */
int vsscanf(const char *str, const char *format, va_list ap) {
    static int (*fptr)(const char *, const char *, va_list )=NULL;
    static intptr_t log_enabled =  true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, const char *, va_list ),"vsscanf"
                          ,fptr,0,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("vsscanf");
        audlib_log_str(curent, str);
        audlib_log_str(curent, format);
        log_commitent(curent);
    }
    
    return((*fptr)(str,format,ap));
}


/*------------------------------------------------------------------------ 
 * sprintf - 
 *------------------------------------------------------------------------
 */
int sprintf(char *str, const char *format, ...) {
    static int (*fptr)(char *, const char *, ...)=NULL;
    static intptr_t log_enabled =  true;
    va_list ap;
    int ret;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(char *, const char *, ...),"vsprintf",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
	va_start(ap,format);
    if (attack_initialized && log_enabled) {
        curent = log_newent("sprintf");
        audlib_log_dst(curent, str);
        audlib_log_str(curent, format);
        log_commitent(curent);
    }
    ret=(*fptr)(str,format,ap);
    va_end(ap);
    
    return(ret);
}


/*------------------------------------------------------------------------ 
 * vsprintf - 
 *------------------------------------------------------------------------
 */
int vsprintf(char *str, const char *format, va_list ap) {
    static int (*fptr)(char *, const char *, va_list )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(char *, const char *, va_list ),"vsprintf",
                          fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("vsprintf");
        audlib_log_dst(curent, str);
        audlib_log_str(curent, format);
        log_commitent(curent);
    }
    
    return((*fptr)(str,format,ap));
}

/*------------------------------------------------------------------------ 
 * realpath - 
 *------------------------------------------------------------------------
 */
char *realpath(const char *path, char *resolved_path) {
    static char *(*fptr)(const char *, char *)=NULL;
    static intptr_t log_enabled = true;
    char *ret;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(char *(*)(const char *, char *),"realpath",fptr,NULL,log_enabled,LIB_LETTER);
    
    // _pre log entry
    if (attack_initialized && log_enabled) {
        curent = log_newent("realpath_pre");
        audlib_log_str(curent, path);
        audlib_log_dst(curent, resolved_path);
        log_commitent(curent);
    }
    
    // get return value
    ret = (*fptr)(path, resolved_path);
    
    // log entry with resolved path
    if (attack_initialized && log_enabled) {
        curent = log_newent("realpath");
        audlib_log_str(curent, path);
        audlib_log_str(curent, resolved_path);
        audlib_log_pointer(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}


/*------------------------------------------------------------------------ 
 * getwd - 
 *------------------------------------------------------------------------
 */
char *getwd(char *buf) {
    static char *(*fptr)(char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    char *ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(char *(*)(char *),"getwd",fptr,NULL,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("getwd_pre");
        audlib_log_dst(curent, buf);
        log_commitent(curent);
    }
    
    ret = ((*fptr)(buf));
    
    if (attack_initialized && log_enabled) {
        curent = log_newent("getwd");
        audlib_log_str(curent, buf);
        log_commitent(curent);
    }
    
    return (ret);
}

#endif /* BO_ATTACKS */


/*------------------------------------------------------------------------
 * 
 * ######  ######    ###   #     # ####### #######
 * #     # #     #    #    ##    #    #    #
 * #     # #     #    #    # #   #    #    #
 * ######  ######     #    #  #  #    #    #####
 * #       #   #      #    #   # #    #    #
 * #       #    #     #    #    ##    #    #
 * #       #     #   ###   #     #    #    #
 * 
 *------------------------------------------------------------------------
 */

/*------------------------------------------------------------------------ 
 * printf - 
 *------------------------------------------------------------------------
 */
int printf(const char *format, /* args*/ ...) {
    va_list ap;
    int ret;
    static int (*fptr)(const char *, /* args*/ ...)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, /* args*/ ...),"vprintf",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("printf");
        audlib_log_str(curent, format);
        log_commitent(curent);
    }
    
    va_start(ap,format);
    ret=(*fptr)(format,ap);
    va_end(ap);
    return(ret);
}


/*------------------------------------------------------------------------ 
 * fprintf - 
 *------------------------------------------------------------------------
 */
int fprintf(FILE *stream,	const  char  *format,  /*  args*/ ...) {
    va_list ap;
    int ret;
    static int (*fptr)(FILE *,	const  char  *,  /*  args*/ ...)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(FILE *, const  char  *,  /*  args*/ ...) ,
                          "vfprintf",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("fprintf");
        audlib_log_str(curent, format);
        log_commitent(curent);
    }
    
    va_start(ap,format);
    ret=(*fptr)(stream,format,ap);
    va_end(ap);
    return(ret);
}


#ifndef BO_ATTACKS
/*------------------------------------------------------------------------ 
 * sprintf - 
 *------------------------------------------------------------------------
 */
int sprintf(char *str, const char *format, ...) {
    static int (*fptr)(char *, const char *, ...)=NULL;
    static intptr_t log_enabled =  true;
    va_list ap;
    int ret;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(char *, const char *, ...),"vsprintf",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
	va_start(ap,format);
    if (attack_initialized && log_enabled) {
        curent = log_newent("sprintf");
        audlib_log_dst(curent, str);
        audlib_log_str(curent, format);
        log_commitent(curent);
    }
    ret=(*fptr)(str,format,ap);
    va_end(ap);
    
    return(ret);
}

#endif


/*------------------------------------------------------------------------ 
 * snprintf - 
 *------------------------------------------------------------------------
 */
int snprintf(char *s, size_t n, const char *format, /* args*/ ...) {
    va_list ap;
    int ret, curent;
    static int (*fptr)(char *, size_t , const char *, va_list)=NULL;
    static intptr_t log_enabled = true;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(char *, size_t , const char *, va_list),
                          "vsnprintf", fptr, -1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("snprintf");
        audlib_log_dst(curent, s);
        audlib_log_size(curent, n);
        audlib_log_str(curent, format);
        log_commitent(curent);
    }
    
    va_start(ap, format);
    ret = ((*fptr)(s, n , format, ap));
    va_end(ap);
    return(ret);
}


/*------------------------------------------------------------------------ 
 * vprintf - 
 *------------------------------------------------------------------------
 */
int vprintf(const char *format, va_list ap) {
    static int (*fptr)(const char *, va_list )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, va_list ),"vprintf",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("vprintf");
        audlib_log_str(curent, format);
        log_commitent(curent);
    }
    
    return((*fptr)(format,ap));
}


/*------------------------------------------------------------------------ 
 * vfprintf - 
 *------------------------------------------------------------------------
 */
int vfprintf(FILE *stream, const char *format, va_list ap) {
    static int (*fptr)(FILE *, const char *, va_list )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(FILE *, const char *, va_list ),"vfprintf",
                          fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("vfprintf");
        audlib_log_str(curent, format);
        log_commitent(curent);
    }
    
    return((*fptr)(stream,format,ap));
}


#ifndef BO_ATTACKS
/*------------------------------------------------------------------------ 
 * vsprintf - 
 *------------------------------------------------------------------------
 */
int vsprintf(char *s, const char *format, va_list ap) {
    static int (*fptr)(char *, const char *, va_list )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(char *, const char *, va_list ),"vsprintf",
                          fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("vsprintf");
        audlib_log_dst(curent, s);
        audlib_log_str(curent, format);
        log_commitent(curent);
    }
    
    return((*fptr)(s,format,ap));
}
#endif


/*------------------------------------------------------------------------ 
 * vsnprintf - 
 *------------------------------------------------------------------------
 */
int vsnprintf(char *s, size_t n, const char *format, va_list ap) {
    static int (*fptr)(char *,size_t , const char *, va_list )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(char *,size_t , const char *, va_list ),
                          "vsnprintf",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("vsnprintf");
        audlib_log_dst(curent, s);
        audlib_log_size(curent, n);
        audlib_log_str(curent, format);
        log_commitent(curent);
    }
    
    return((*fptr)(s,n,format,ap));
}



#ifdef TOCTTOU_ATTACKS
/*------------------------------------------------------------------------
 * 
 * 
 *   #####   ####    ####    #####   #####   ####   #    #
 *     #    #    #  #    #     #       #    #    #  #    #
 *     #    #    #  #          #       #    #    #  #    #
 *     #    #    #  #          #       #    #    #  #    #
 *     #    #    #  #    #     #       #    #    #  #    #
 *     #     ####    ####      #       #     ####    ####
 * 
 *------------------------------------------------------------------------
 */

/* For the purposes of this program, I am going to be looking for functions
 * that utilize a file name that is specified by a char * and not through a
 * file handle of some sort
 */

/*------------------------------------------------------------------------ 
 * access - 
 *------------------------------------------------------------------------
 */
int access(const char *path, int amode) {
    static int (*fptr)(const char *, int )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, int ),"access",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path,amode));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("access");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * faccessat - 
 *------------------------------------------------------------------------
 */
int faccessat(int dirfd, const char *path, int mode, int flags) {
    static int (*fptr)(int, const char *, int, int )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, int, int ),"faccessat",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(dirfd,path,mode,flags));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("faccessat");
        audlib_log_str(curent, path);
        audlib_log_int(curent, flags);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*
 * HAS_ACL environment variable indicates if current platform has acl
 */
#ifdef HAS_ACL 
#include <sys/acl.h>
/*------------------------------------------------------------------------ 
 * acl - 
 *------------------------------------------------------------------------
 */
int acl(const char *pathp, int cmd, int nentries, aclent_t *aclbufp) {
    static int (*fptr)(const char *, int , int , aclent_t *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, int , int , aclent_t *),"acl",
                          fptr, -1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("acl");
        audlib_log_str(curent, pathp);
        log_commitent(curent);
    }
    
    return((*fptr)(pathp,cmd,nentries,aclbufp));
}
#endif 

/*------------------------------------------------------------------------ 
 * chmod - 
 *------------------------------------------------------------------------
 */
int chmod(const char *path, mode_t mode) {
    static int (*fptr)(const char *, mode_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, mode_t ),"chmod",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path,mode));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("chmod");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * fchmodat - 
 *------------------------------------------------------------------------
 */
int fchmodat(int dirfd, const char *path, mode_t mode, int flags) {
    static int (*fptr)(int, const char *, mode_t, int )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, mode_t, int ),"fchmodat",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(dirfd,path,mode,flags));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("fchmodat");
        audlib_log_str(curent, path);
        audlib_log_int(curent, flags);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}


/*------------------------------------------------------------------------ 
 * chown - 
 *------------------------------------------------------------------------
 */
int chown(const char *path, uid_t owner, gid_t group) {
    static int (*fptr)(const char *, uid_t , gid_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, uid_t , gid_t ),"chown",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path,owner,group));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("chown");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * fchownat - 
 *------------------------------------------------------------------------
 */
int fchownat(int dirfd, const char *path, uid_t owner, gid_t group, int flags) {
    static int (*fptr)(int, const char *, uid_t , gid_t, int )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, uid_t , gid_t, int ),"fchownat",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(dirfd,path,owner,group,flags));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("fchownat");
        audlib_log_str(curent, path);
        audlib_log_int(curent, flags);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}


/*------------------------------------------------------------------------ 
 * creat - 
 *------------------------------------------------------------------------
 */
int creat(const char *pathname, mode_t mode) {
    static int (*fptr)(const char *, mode_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, mode_t ),"creat",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(pathname,mode));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("creat");
        audlib_log_str(curent, pathname);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * creat64 - 
 *------------------------------------------------------------------------
 */
int creat64(const char *file, mode_t mode) {
    static int (*fptr)(const char *, mode_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, mode_t ),"creat64",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(file,mode));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("creat64");
        audlib_log_str(curent, file);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * execl - 
 *------------------------------------------------------------------------
 */
int execl(const char *path, const char *arg, ...) {
    static int (*fptr)(const char *, char *const *, char *const *)=NULL;
    static intptr_t log_enabled = true;
    int curent, ret;
    va_list ap;
    char **argptrs;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const *, char *const *),
                          "execve", fptr, -1,log_enabled,LIB_LETTER);
    
    //generate passable array argument pointers
    va_start(ap, arg);
    argptrs = aud_vargptrs(arg, ap);
    va_end(ap);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("execl");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    ret = ((*fptr)(path, argptrs, environ));
    (*__freeptr)(argptrs);
    return (ret);
}


/*------------------------------------------------------------------------ 
 * execle - 
 *------------------------------------------------------------------------
 */
int execle(const char *path, const char *arg , ...) {
    static int (*fptr)(const char *, char *const *, char *const *)=NULL;
    static intptr_t log_enabled = true;
    int curent, ret;
    va_list ap;
    char **argptrs, **envp;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const *, char *const *),
                          "execve", fptr, -1,log_enabled,LIB_LETTER);
    
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("execle");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    /* generate passable array argument pointers */
    va_start(ap, arg);
    argptrs = aud_vargptrs(arg, ap);
    envp = aud_vargptrs(va_arg(ap, char *), ap);
    va_end(ap);
    
    
    ret = ((*fptr)(path, argptrs, envp));
    (*__freeptr)(argptrs);
    (*__freeptr)(envp);
    return (ret);
}

/*------------------------------------------------------------------------ 
 * execlp - 
 *------------------------------------------------------------------------
 */
int execlp(const char *file, const char *arg, ...) {
    static int (*fptr)(const char *, char *const *)=NULL;
    static intptr_t log_enabled = true;
    int curent, ret;
    va_list ap;
    char **argptrs;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const *), "execvp", fptr,
                          -1,log_enabled,LIB_LETTER);
    
    /* generate passable array argument pointers */
    va_start(ap, arg);
    argptrs = aud_vargptrs(arg, ap);
    va_end(ap);
    
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("execlp");
        audlib_log_str(curent, file);
        log_commitent(curent);
    }
    
    ret = ((*fptr)(file, argptrs));
    (*__freeptr)(argptrs);
    return (ret);
}


/*------------------------------------------------------------------------ 
 * execv - 
 *------------------------------------------------------------------------
 */
int execv(const char *path, char *const argv[]) {
    static int (*fptr)(const char *, char *const argv[])=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const argv[]),"execv",fptr,
                          -1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("execv");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    
    ret = ((*fptr)(path, argv));
    return (ret);
}


/*------------------------------------------------------------------------ 
 * execve - 
 *------------------------------------------------------------------------
 */
int execve(const char *path, char *const argv[], char *const envp[]) {
    static int (*fptr)(const char *, char *const argv[], char *const envp[])=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const argv[], 
                                  char *const envp[]),"execve",fptr,-1,log_enabled,LIB_LETTER);
    
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("execve");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    ret = ((*fptr)(path, argv, envp));
    return (ret);
}


/*------------------------------------------------------------------------ 
 * execvp - 
 *------------------------------------------------------------------------
 */
int execvp(const char *file, char *const argv[]) {
    static int (*fptr)(const char *, char *const argv[])=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const argv[]),"execvp",
                          fptr,-1,log_enabled,LIB_LETTER);
    
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("execvp");
        audlib_log_str(curent, file);
        log_commitent(curent);
    }
    
    ret = ((*fptr)(file, argv));
    return (ret);
}

/*------------------------------------------------------------------------ 
 * getcwd - 
 *------------------------------------------------------------------------
 */
char *getcwd(char *buf, size_t size) {
    static char *(*fptr)(char *, size_t) = NULL;
    static intptr_t log_enabled = true;
    int curent;
    char *ret;
    
    AUDLIB_LOOKUP_COMMAND(char *(*)(char *, size_t), "getcwd", fptr, NULL,log_enabled,LIB_LETTER);
    
    if (attack_initialized && log_enabled) {
        curent = log_newent("getcwd_pre");
        audlib_log_dst(curent, buf);
        audlib_log_size(curent, size);
        log_commitent(curent);
    }
    
    ret = (*fptr)(buf, size);
    
    if (attack_initialized && log_enabled) {
        curent = log_newent("getcwd");
        audlib_log_str(curent, buf);
        audlib_log_size(curent, size);
        audlib_log_str(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * chdir - 
 *------------------------------------------------------------------------
 */
int chdir(const char *path) {
    static int (*fptr)(const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *),"chdir",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("chdir");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * chroot - 
 *------------------------------------------------------------------------
 */
int chroot(const char *path) {
    static int (*fptr)(const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *),"chroot",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("chroot");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * unlink - 
 *------------------------------------------------------------------------
 */
int unlink(const char *path) {
    static int (*fptr)(const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *),"unlink",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("unlink");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * unlinkat - 
 *------------------------------------------------------------------------
 */
int unlinkat(int dirfd, const char *path, int flags) {
    static int (*fptr)(int, const char *, int )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, int),"unlinkat",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(dirfd,path,flags));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("unlinkat");
        audlib_log_str(curent, path);
        audlib_log_int(curent, flags);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * lchown - 
 *------------------------------------------------------------------------
 */
int lchown(const char *path, uid_t owner, gid_t group) {
    static int (*fptr)(const char *, uid_t , gid_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, uid_t , gid_t ),"lchown",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path,owner,group));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("lchown");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}


/*------------------------------------------------------------------------ 
 * link - 
 *------------------------------------------------------------------------
 */
int link(const char *existing, const char *new) {
    static int (*fptr)(const char *, const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, const char *),"link",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(existing,new));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("link");
        audlib_log_str(curent, existing);
        audlib_log_str(curent, new);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * linkat - 
 *------------------------------------------------------------------------
 */
int linkat(int olddirfd, const char *oldpath, 
           int newdirfd, const char *newpath, int flags) {
    static int (*fptr)(int, const char *, int, const char *, int)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, int, const char *, int),"linkat",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(olddirfd, oldpath, newdirfd, newpath, flags));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("linkat");
        audlib_log_str(curent, oldpath);
        audlib_log_str(curent, newpath);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}


/*------------------------------------------------------------------------ 
 * lstat - 
 *------------------------------------------------------------------------
 */
int lstat(const char *path, struct stat *buf) {
    static int (*fptr)(const char *, struct stat *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, struct stat *),"lstat",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path,buf));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("lstat");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * lstat64 - 
 *------------------------------------------------------------------------
 */
int lstat64(const char *path, struct stat64 *buf) {
    static int (*fptr)(const char *, struct stat64 *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, struct stat64 *),"lstat64",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path,buf));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("lstat64");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}


/*------------------------------------------------------------------------ 
 * mknod - 
 *------------------------------------------------------------------------
 */
int mknod(const char *path, mode_t mode, dev_t dev) {
    static int (*fptr)(const char *, mode_t , dev_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, mode_t , dev_t ),"mknod",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path,mode,dev));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("mknod");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * mknodat - 
 *------------------------------------------------------------------------
 */
int mknodat(int dirfd, const char *path, mode_t mode, dev_t dev) {
    static int (*fptr)(int, const char *, mode_t , dev_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, mode_t , dev_t ),"mknodat",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(dirfd,path,mode,dev));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("mknodat");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}


/*------------------------------------------------------------------------ 
 * mount - 
 *------------------------------------------------------------------------
 */
int  mount(const  char *source, const char *target, const char *filesystemtype,
           unsigned long mountflags, const void *data) {
    static int (*fptr)(const  char * , const char * , const char * ,
                       unsigned long , const void * ) = NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, const char *, const char * ,
                                  unsigned long, const void *), "mount", fptr, -1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("mount_pre");
        audlib_log_str(curent, source);
        audlib_log_str(curent, target);
        log_commitent(curent);
    }
    
    ret = ((*fptr)(source, target, filesystemtype, mountflags, data));
    
    if (attack_initialized && log_enabled) {
        curent = log_newent("mount");
        audlib_log_str(curent, source);
        audlib_log_str(curent, target);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return(ret);
}


/*------------------------------------------------------------------------ 
 * umount - 
 *------------------------------------------------------------------------
 */
int umount(const char *file) {
    static int (*fptr)(const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *),"umount",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("umount");
        audlib_log_str(curent, file);
        log_commitent(curent);
    }
    
    return((*fptr)(file));
}


/*------------------------------------------------------------------------ 
 * umount2 - 
 *------------------------------------------------------------------------
 */
int umount2(const char *file, int mflag) {
    static int (*fptr)(const char *, int )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, int ),"umount2",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("umount2");
        audlib_log_str(curent, file);
        audlib_log_int(curent, mflag);
        log_commitent(curent);
    }
    
    return((*fptr)(file,mflag));
}


/*------------------------------------------------------------------------ 
 * open - 
 *------------------------------------------------------------------------
 */

/* This works for GCC version >= 3.4. For earlier versions of GCC, and also probably for Solaris,
 * this should be declared as int open(const char *path, int oflag, mode_t mode);
 * Thus, we should check for this at compile time.
 */

int open(const char *path, int oflag, ...) {
    static int (*fptr)(const char *, int , /* mode_t mode */...)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, int , /* mode_t mode */...),"open",fptr,-1,log_enabled,LIB_LETTER);
    
    int mode;
    if (oflag & O_CREAT)
    {
        va_list arg;
        va_start(arg, oflag);
        mode = va_arg(arg, int);
        va_end(arg);
    }
    
    ret = ((*fptr)(path,oflag, mode));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("open");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * openat - 
 *------------------------------------------------------------------------
 */

/* This works for GCC version >= 3.4. For earlier versions of GCC, and also probably for Solaris,
 * this should be declared as int openat(int dirfd, const char *path, int oflag, mode_t mode);
 * Thus, we should check for this at compile time.
 */

int openat(int dirfd, const char *path, int oflag, ...) {
    static int (*fptr)(int, const char *, int , /* mode_t mode */...)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, int , /* mode_t mode */...),"openat",fptr,-1,log_enabled,LIB_LETTER);
    
    int mode;
    if (oflag & O_CREAT)
    {
        va_list arg;
        va_start(arg, oflag);
        mode = va_arg(arg, int);
        va_end(arg);
    }
    
    ret = ((*fptr)(dirfd,path,oflag, mode));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("openat");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * open64 - 
 *------------------------------------------------------------------------
 */
int open64(const char *path, int oflag, ...) {
    static int (*fptr)(const char *, int , /* mode_t mode */...)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, int , /* mode_t mode */...),"open64",fptr,-1,log_enabled,LIB_LETTER);
    
    int mode;
    if (oflag & O_CREAT)
    {
        va_list arg;
        va_start(arg, oflag);
        mode = va_arg(arg, int);
        va_end(arg);
    }
    
    ret = ((*fptr)(path,oflag, mode));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("open64");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * openat64 - 
 *------------------------------------------------------------------------
 */
int openat64(int dirfd, const char *path, int oflag, ...) {
    static int (*fptr)(int, const char *, int , /* mode_t mode */...)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, int , /* mode_t mode */...),"openat64",fptr,-1,log_enabled,LIB_LETTER);
    
    int mode;
    if (oflag & O_CREAT)
    {
        va_list arg;
        va_start(arg, oflag);
        mode = va_arg(arg, int);
        va_end(arg);
    }
    
    ret = ((*fptr)(dirfd, path,oflag, mode));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("openat64");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}


/*------------------------------------------------------------------------ 
 * rename - 
 *------------------------------------------------------------------------
 */
int rename(const char *old, const char *new) {
    static int (*fptr)(const char *, const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, const char *),"rename",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(old,new));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("rename");
        audlib_log_str(curent, old);
        audlib_log_str(curent, new);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * renameat - 
 *------------------------------------------------------------------------
 */
int renameat(int olddirfd, const char *old, int newdirfd, const char *new) {
    static intptr_t log_enabled = true;
    static int (*fptr)(int, const char *, int, const char *)=NULL;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, int, const char *),"renameat",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(olddirfd,old,newdirfd,new));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("renameat");
        audlib_log_str(curent, old);
        audlib_log_str(curent, new);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}


/*------------------------------------------------------------------------ 
 * stat - 
 *------------------------------------------------------------------------
 */
int stat(const char *path, struct stat *buf) {
    static int (*fptr)(const char *, struct stat *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, struct stat *),"stat",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path,buf));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("stat");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * fstatat - 
 *------------------------------------------------------------------------
 */
int fstatat(int dirfd, const char *path, struct stat *buf, int flags) {
    static int (*fptr)(int, const char *, struct stat *,int)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, struct stat *, int),"fstatat",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(dirfd,path,buf,flags));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("fstatat");
        audlib_log_str(curent, path);
        audlib_log_int(curent, flags);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * fstatat64 - 
 *------------------------------------------------------------------------
 */
int fstatat64(int dirfd, const char *path, struct stat64 *buf, int flags) {
    static int (*fptr)(int, const char *, struct stat64 *,int)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, struct stat64 *, int),"fstatat64",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(dirfd,path,buf,flags));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("fstatat64");
        audlib_log_str(curent, path);
        audlib_log_int(curent, flags);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * stat64 - 
 *------------------------------------------------------------------------
 */
int stat64(const char *path, struct stat64 *buf) {
    static int (*fptr)(const char *, struct stat64 *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, struct stat64 *),"stat64",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path,buf));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("stat64");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}


#include <sys/statvfs.h>
/*------------------------------------------------------------------------ 
 * statvfs - 
 *------------------------------------------------------------------------
 */
int statvfs(const char *path, struct statvfs *buf) {
    static int (*fptr)(const char *, struct statvfs *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, struct statvfs *),"statvfs",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path,buf));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("statvfs");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * statvfs64 - 
 *------------------------------------------------------------------------
 */
int statvfs64(const char *path, struct statvfs64 *buf) {
    static int (*fptr)(const char *, struct statvfs64 *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, struct statvfs64 *),"statvfs64",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path,buf));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("statvfs64");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}


/*------------------------------------------------------------------------ 
 * symlink - 
 *------------------------------------------------------------------------
 */
int symlink(const char *name1, const char *name2) {
    static int (*fptr)(const char *, const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, const char *),"symlink",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(name1,name2));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("symlink");
        audlib_log_str(curent, name1);
        audlib_log_str(curent, name2);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * symlinkat - 
 *------------------------------------------------------------------------
 */
int symlinkat(const char *name1, int newdirfd, const char *name2) {
    static int (*fptr)(const char *, int, const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, int, const char *),"symlinkat",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(name1,newdirfd,name2));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("symlinkat");
        audlib_log_str(curent, name1);
        audlib_log_str(curent, name2);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}


#include <utime.h>
/*------------------------------------------------------------------------ 
 * utime - 
 *------------------------------------------------------------------------
 */
int utime(const char *path, const struct utimbuf *times) {
    static int (*fptr)(const char *, const struct utimbuf *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, const struct utimbuf *),"utime",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path,times));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("utime");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}


/*------------------------------------------------------------------------ 
 * utimes - 
 *------------------------------------------------------------------------
 */
int utimes(const char *path, const struct timeval times[2]) {
    static int (*fptr)(const char *, const struct timeval times[2])=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, const struct timeval times[2]),
                          "utimes",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path, times));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("utimes");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * futimesat - 
 *------------------------------------------------------------------------
 */
int futimesat(int dirfd, const char *path, const struct timeval times[2]) {
    static int (*fptr)(int, const char *, const struct timeval times[2])=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, const struct timeval times[2]),
                          "futimesat",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(dirfd, path, times));
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("futimesat");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}
#endif /* TOCTTOU_ATTACKS */

/*------------------------------------------------------------------------ 
 * fork - 
 *------------------------------------------------------------------------
 */
pid_t fork(void) {
    static pid_t (*fptr)(void)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(pid_t (*)(void),"fork",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)());
    
    /* generate audit information */
    if (attack_initialized && log_enabled) {
        curent = log_newent("fork");
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/* vim:set fdm=marker:fdl=0:fen :*/
