// vim:sw=4:
#define log_newent(x)	    audlib_log_newent("I:" x, I_pid, I_ppid)
#define log_commitent(x)    audlib_log_commitent(x,I_fd)
#define INITIALIZED         intrusion_initialized
#define LIB_LETTER          "I"


/*
 * audlib_intrusion.c
 *
 * Benjamin A. Kuperman
 * 02 July 2002
 */

/*
 * $Id: audlib_intrusion.c 380 2010-07-27 22:39:47Z jakimmel $
 *
 */

/* 
 * Design
 * ------
 * Generate audit data relating to:
 *  - user
 *  - program executed
 *
 * Based on Lane and Brodley
 */

#include <stdlib.h>
#include <unistd.h>
#include <sys/procfs.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <sys/resource.h>   /* for getrlimit */
#include <sys/time.h>
#include <stdarg.h>
#include "macros.h"
#include "protos.h"
#include "proclib.h"
#include "logent.h"
#include "whereptr.h"
#include "error.h"

/*------------------------------------------------------------------------
 * prototypes
 *------------------------------------------------------------------------
 */
/* audlib_attack.c */
void audlib_intrusion_init(void);
void audlib_intrusion_fini(void);

/*------------------------------------------------------------------------
 * macros
 *------------------------------------------------------------------------
 */
void __attribute__ ((constructor)) audlib_intrusion_init(void);
void __attribute__ ((destructor))  audlib_intrusion_fini(void);


/*------------------------------------------------------------------------
 * Global Variables
 *------------------------------------------------------------------------
 */
static FILE *I_output;	/* where to put the output */
static int  I_fd=-1;	/* file descriptor to use */
static pid_t I_pid;
static pid_t I_ppid;
static int intrusion_initialized=0;

/*------------------------------------------------------------------------
 * init and fini
 *------------------------------------------------------------------------
 */
void audlib_intrusion_init() {
    /* stat(s) of executable(s) will go here */
    struct stat statbuf, lstatbuf;
    char *loginname;
    int curent, openlog_succeeded;
    intptr_t should_interp;
    procInfo_t *procinfo;
    
    /* do global initializations if needed */
    audlib_initialize();
    /* set things up for logging */
    openlog_succeeded = audlib_openlog("AUDLIB_INTRUSION",&I_fd,&I_output);
    
    /* get the pid */
    if (-1 == (I_pid=getpid())) {
        audlib_error(AUD_CANT_GET_PID, "I:init");
        /* failed to get the pid */
    }
    if (-1 == (I_ppid=getppid())) {
        /* failed to get the pid */
        audlib_error(AUD_CANT_GET_PPID, "I:init");
    }
    
    //Load or create procInfo_t. The lowercase label denotes error condition.
    procinfo = getProcInfo();
    AUDLIB_LOOKUP_INTERP(should_interp, procinfo->execpath); //see if we should interpose this program
    init_whereptr(); //Read the /proc/self/maps file to enable pointer location identification
    
    //Get executable stat
    if (mystat(procinfo->execpath, &statbuf)) {
        audlib_error(AUD_FAILED_STAT, "I:init");
    }
    
    //Get executabe lstat
    if (mylstat(procinfo->execpath, &lstatbuf)) {
        audlib_error(AUD_FAILED_LSTAT, "I:init");
    }
    
    //Get username of current user
    errno=0;
    if (NULL==(loginname = aud_getlogin())) {
        audlib_error(AUD_CANT_GET_USERNAME, "I:init");
    }
    
    //if openlog failed, don't log anything
    intrusion_initialized = (openlog_succeeded && should_interp);
    if (intrusion_initialized) {
        /* dump exec information */
        curent = log_newent("init");
        audlib_log_str(curent, loginname);
        audlib_log_uid(curent, procinfo->ruid);
        audlib_log_uid(curent, procinfo->euid);
        audlib_log_uid(curent, procinfo->suid);
        audlib_log_gid(curent, procinfo->rgid);
        audlib_log_gid(curent, procinfo->egid);
        audlib_log_gid(curent, procinfo->sgid);
        audlib_log_buffer(curent, procinfo->cmdline,
                          procinfo->cmdline_size);
        audlib_log_stat(curent, statbuf);
        audlib_log_stat(curent, lstatbuf);
        log_commitent(curent);
    }
    
}

void audlib_intrusion_fini() {
    struct mytms tmsbuf;
    struct stat statbuf, lstatbuf;
    char *loginname;
    int curent;
    procInfo_t *procinfo;
    
    if (intrusion_initialized) {
        
        procinfo = getProcInfo();
        
        if (mytimes(&tmsbuf)) {
            audlib_error(AUD_CANT_GET_TIME_INFO, "I:fini");
        }
        
        //Get executable stat
        if (mystat(procinfo->execpath, &statbuf)) {
            audlib_error(AUD_FAILED_STAT, "I:fini");
        }
        
        //Get executabe lstat
        if (mylstat(procinfo->execpath, &lstatbuf)) {
            audlib_error(AUD_FAILED_LSTAT, "I:fini");
        }
        
        //Get username of current user
        if (NULL==(loginname = aud_getlogin())) {
            audlib_error(AUD_CANT_GET_USERNAME, "I:fini");
        }
        
        /* dump exec information */
        curent = log_newent("fini");
        audlib_log_str(curent, loginname);
        audlib_log_uid(curent, procinfo->ruid);
        audlib_log_uid(curent, procinfo->euid);
        audlib_log_uid(curent, procinfo->suid);
        audlib_log_gid(curent, procinfo->rgid);
        audlib_log_gid(curent, procinfo->egid);
        audlib_log_gid(curent, procinfo->sgid);
        audlib_log_buffer(curent, procinfo->cmdline, procinfo->cmdline_size);
        audlib_log_stat(curent, statbuf);
        audlib_log_stat(curent, lstatbuf);
        audlib_log_time(curent, tmsbuf.utime);
        audlib_log_time(curent, tmsbuf.stime);
        audlib_log_time(curent, tmsbuf.cutime);
        audlib_log_time(curent, tmsbuf.cstime);
        log_commitent(curent);
        
        (*__fcloseptr)(I_output); //this does fflush anyway
        intrusion_initialized=0;
    }
}


/*------------------------------------------------------------------------
 * close - this is to prevent problems with someone trying to close our
 * file descriptor that we are using to generate logging messages
 *------------------------------------------------------------------------
 */
#ifdef CLOSE_FIX
int close(int fildes) {
    static  int (*fptr)(int )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(int ),"close",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (intrusion_initialized && log_enabled) {
        /* I think the problems comes from something trying to close my FD */
        if (fildes==I_fd) {
            curent = log_newent("close-fail");
            audlib_log_int(curent, fildes);
            log_commitent(curent);
            return(-1);
        }
    }
    return((*fptr)(fildes));
}
#endif

/*------------------------------------------------------------------------ 
 * execl - 
 *------------------------------------------------------------------------
 */
int execl(const char *path, const char *arg, ...) {
    static int (*fptr)(const char *, char *const *, char *const *)=NULL;
    static intptr_t log_enabled = true;
    int curent, ret;
    va_list ap;
    char **argptrs;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const *, char *const *),
                          "execve", fptr, -1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (intrusion_initialized && log_enabled) {
        curent = log_newent("execl");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    //generate passable array argument pointers
    va_start(ap, arg);
    argptrs = aud_vargptrs(arg, ap);
    va_end(ap);
    
    ret = ((*fptr)(path, argptrs, environ));
    (*__freeptr)(argptrs);
    return (ret);
}


/*------------------------------------------------------------------------ 
 * execle - 
 *------------------------------------------------------------------------
 */
int execle(const char *path, const char *arg , ...) {
    static int (*fptr)(const char *, char *const *, char *const *)=NULL;
    static intptr_t log_enabled = true;
    int curent, ret;
    va_list ap;
    char **argptrs, **envp;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const *, char *const *),
                          "execve", fptr, -1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (intrusion_initialized && log_enabled) {
        curent = log_newent("execle");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    /* generate passable array argument pointers */
    va_start(ap, arg);
    argptrs = aud_vargptrs(arg, ap);
    envp = aud_vargptrs(va_arg(ap, char *), ap);
    va_end(ap);
    
    ret = ((*fptr)(path, argptrs, envp));
    (*__freeptr)(argptrs);
    return (ret);
}

/*------------------------------------------------------------------------ 
 * execlp - 
 *------------------------------------------------------------------------
 */
int execlp(const char *file, const char *arg, ...) {
    static int (*fptr)(const char *, char *const *)=NULL;
    static intptr_t log_enabled = true;
    int curent, ret;
    va_list ap;
    char **argptrs;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const *), "execvp", fptr,
                          -1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (intrusion_initialized && log_enabled) {
        curent = log_newent("execlp");
        audlib_log_str(curent, file);
        log_commitent(curent);
    }
    
    /* generate passable array argument pointers */
    va_start(ap, arg);
    argptrs = aud_vargptrs(arg, ap);
    va_end(ap);
    
    ret = ((*fptr)(file, argptrs));
    (*__freeptr)(argptrs);
    return (ret);
}

/*------------------------------------------------------------------------ 
 * execv - 
 *------------------------------------------------------------------------
 */
int execv(const char *path, char *const argv[]) {
    static int (*fptr)(const char *, char *const *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const *),"execv",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (intrusion_initialized && log_enabled) {
        curent = log_newent("execv");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(path, argv));
}

/*------------------------------------------------------------------------ 
 * execve - 
 *------------------------------------------------------------------------
 */
int execve(const char *path, char *const argv[], char *const envp[]) {
    static int (*fptr)(const char *, char *const *, char *const *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const *, char *const *),
                          "execve",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (intrusion_initialized && log_enabled) {
        curent = log_newent("execve");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(path, argv, envp));
}

/*------------------------------------------------------------------------ 
 * execvp - 
 *------------------------------------------------------------------------
 */
int execvp(const char *file, char *const argv[]) {
    static int (*fptr)(const char *, char *const *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const *),"execvp",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (intrusion_initialized && log_enabled) {
        curent = log_newent("execvp");
        audlib_log_str(curent, file);
        log_commitent(curent);
    }
    
    return ((*fptr)(file, argv));
}

/*------------------------------------------------------------------------ 
 * getrlimit - 
 *------------------------------------------------------------------------
 */
int getrlimit(__rlimit_resource_t resource, struct rlimit *rlp) {
    static int (*fptr)(__rlimit_resource_t, struct rlimit *)=NULL;
    static intptr_t log_enabled = false;
    int ret;
    int curent;
    
    AUDLIB_LOOKUP_COMMAND( int (*)(__rlimit_resource_t,struct rlimit *),
                          "getrlimit",fptr,-1,log_enabled,LIB_LETTER);
    
    ret=(*fptr)(resource,rlp);
    if (intrusion_initialized) {
        /* we are using the highest available fd for myself */
        if (RLIMIT_NOFILE == resource) {
            rlp->rlim_cur -= 1; /* return one less */
            if(log_enabled) {
                curent = log_newent("getrlimit-fix");
                audlib_log_int(curent, rlp->rlim_cur);
                log_commitent(curent);
            }
        }
    }
    return(ret);
}

/*------------------------------------------------------------------------ 
 * chdir - 
 *------------------------------------------------------------------------
 */
int chdir(const char *path) {
    static int (*fptr)(const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *),"chdir",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path));
    
    /* generate audit information */
    if (intrusion_initialized && log_enabled) {
        curent = log_newent("chdir");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * chroot - 
 *------------------------------------------------------------------------
 */
int chroot(const char *path) {
    static int (*fptr)(const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *),"chroot",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)(path));
    
    /* generate audit information */
    if (intrusion_initialized && log_enabled) {
        curent = log_newent("chroot");
        audlib_log_str(curent, path);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/*------------------------------------------------------------------------ 
 * fork - 
 *------------------------------------------------------------------------
 */
pid_t fork(void) {
    static pid_t (*fptr)(void)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(pid_t (*)(void),"fork",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)());
    
    /* generate audit information */
    if (intrusion_initialized && log_enabled) {
        curent = log_newent("fork");
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/* vim:set fdm=marker:fdl=0:fen :*/
