#define log_newent(x)	    audlib_log_newent("M:" x, M_pid, M_ppid)
#define log_commitent(x)    audlib_log_commitent(x,M_fd)
#define INITIALIZED         misuse_initialized
#define LIB_LETTER          "M"

/*
 * audlib_misuse.c
 *
 * Benjamin A. Kuperman
 * 19 July 2003
 */

/*
 * $Id: audlib_misuse.c 387 2010-07-29 22:07:54Z jakimmel $
 *
 */

/* 
 * Design
 * ------
 *  - Record user identification
 *  - Keep track of resource utilization
 *	- processing time
 *	- memory?
 *	- process count?
 *	- file descriptors?
 *  - Record file accesses (ala Janus)
 */

#include <stdlib.h>
#include <unistd.h>
#include <sys/procfs.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/uio.h>
#include <errno.h>
#include "macros.h"
#include <sys/resource.h>   /* for getrlimit */
#include "protos.h"
#include "proclib.h"
#include "logent.h"
#include "whereptr.h"
#include "error.h"

/*------------------------------------------------------------------------
 * prototypes
 *------------------------------------------------------------------------
 */
void audlib_misuse_init(void);
void audlib_misuse_fini(void);


/*------------------------------------------------------------------------
 * macros
 *------------------------------------------------------------------------
 */
void __attribute__ ((constructor)) audlib_misuse_init(void);
void __attribute__ ((destructor))  audlib_misuse_fini(void);


/*------------------------------------------------------------------------
 * Global Variables
 *------------------------------------------------------------------------
 */
static FILE *M_output=(FILE *)-1;	/* where to put the output */
static int  M_fd=-1;	/* file descriptor to use */
static pid_t M_pid;
static pid_t M_ppid;
static int  misuse_initialized=0;

/*------------------------------------------------------------------------
 * init and fini
 *------------------------------------------------------------------------
 */
void audlib_misuse_init() {
    struct stat statbuf, lstatbuf;    /* stat of executable file */
    int curent, openlog_succeeded;
    intptr_t should_interp;
    procInfo_t *procinfo=NULL;
    
    /* do global initializations if needed */
    audlib_initialize();
    /* set things up for logging */
    openlog_succeeded = audlib_openlog("AUDLIB_MISUSE",&M_fd,&M_output);
    
    /* get the pid */
    if (-1 == (M_pid=getpid())) {
        /* failed to get the pid */
        audlib_error(AUD_CANT_GET_PID, "M:init");
    }
    if (-1 == (M_ppid=getppid())) {
        /* failed to get the pid */
        audlib_error(AUD_CANT_GET_PPID, "M:init");
    }
    
    //The lowercase label denotes error condition.
    procinfo = getProcInfo();
    AUDLIB_LOOKUP_INTERP(should_interp, procinfo->execpath); //see if we should interpose this program
    init_whereptr(); //Read the /proc/self/maps file to enable pointer location identification
    
    // this is a fix for valgrind.  Changed to memset because bzero is deprecated
    (*__memsetptr)(&statbuf, 0, sizeof(statbuf));
    (*__memsetptr)(&lstatbuf, 0, sizeof(lstatbuf));
    
    //Get executable stat
    if (mystat(procinfo->execpath, &statbuf)) {
        audlib_error(AUD_FAILED_STAT, "M:init");
    }
    
    //Get executable lstat
    if (mylstat(procinfo->execpath, &lstatbuf)) {
        audlib_error(AUD_FAILED_LSTAT, "M:init");
    }
    
    //if openlog failed, don't log anything
    misuse_initialized = (openlog_succeeded && should_interp);
    //Log information
    if (misuse_initialized) {
        if (-1 == (curent = log_newent("init"))) {
            audlib_error(AUD_CANT_MAKE_LOG_ENTRY, "M:init");
        }
        audlib_log_uid(curent, procinfo->ruid);
        audlib_log_uid(curent, procinfo->euid);
        audlib_log_uid(curent, procinfo->suid);
        audlib_log_gid(curent, procinfo->rgid);
        audlib_log_gid(curent, procinfo->egid);
        audlib_log_gid(curent, procinfo->sgid);
        audlib_log_stat(curent, statbuf);
        audlib_log_stat(curent, lstatbuf);
        log_commitent(curent);
    }
    
}

void audlib_misuse_fini() {
    struct mytms tmsbuf;
    int curent;
    procInfo_t *procinfo=NULL;
    
    if (misuse_initialized) {
        
        procinfo = getProcInfo();
        
        if (mytimes(&tmsbuf)) {
            audlib_error(AUD_CANT_GET_TIME_INFO, "M:fini");
        }
        
        curent = log_newent("fini");
        audlib_log_uid(curent, procinfo->ruid);
        audlib_log_uid(curent, procinfo->euid);
        audlib_log_uid(curent, procinfo->suid);
        audlib_log_gid(curent, procinfo->rgid);
        audlib_log_gid(curent, procinfo->egid);
        audlib_log_gid(curent, procinfo->sgid);
        audlib_log_time(curent, tmsbuf.utime);
        audlib_log_time(curent, tmsbuf.stime);
        audlib_log_time(curent, tmsbuf.cutime);
        audlib_log_time(curent, tmsbuf.cstime);
        log_commitent(curent);
        
        (*__fcloseptr)(M_output);
        misuse_initialized=0;
    }
}


/*----------------------------------------------------------------------------*/

/*------------------------------------------------------------------------ 
 * open - 
 *------------------------------------------------------------------------
 */
int open(const char *path, int oflag, mode_t mode) {
    static  int (*fptr)(const char *, int , /* mode_t mode */...)=NULL;
    static intptr_t log_enabled = true;
    int ret;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(const char *, int , /* mode_t mode */...),"open",fptr,-1,log_enabled,LIB_LETTER);
    
    /* make the call, save the return value */
    ret=(*fptr)(path,oflag, mode);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("open");
        audlib_log_int(curent, oflag);
        audlib_log_mode(curent, mode);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return(ret);
}

/*------------------------------------------------------------------------ 
 * openat - 
 *------------------------------------------------------------------------
 */
int openat(int dirfd, const char *path, int oflag, mode_t mode) {
    static  int (*fptr)(int, const char *, int , /* mode_t mode */...)=NULL;
    static intptr_t log_enabled = true;
    int ret;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(int, const char *, int , /* mode_t mode */...),
                          "openat",fptr,-1,log_enabled,LIB_LETTER);
    
    /* make the call, save the return value */
    ret=(*fptr)(dirfd,path,oflag, mode);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("openat");
        audlib_log_int(curent, oflag);
        audlib_log_mode(curent, mode);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return(ret);
}

/*------------------------------------------------------------------------ 
 * open64 - 
 *------------------------------------------------------------------------
 */
int open64(const char *path, int oflag, mode_t mode) {
    static  int (*fptr)(const char *, int , /* mode_t mode */...)=NULL;
    static intptr_t log_enabled = true;
    int ret;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(const char *, int , /* mode_t mode */...),
                          "open64",fptr,-1,log_enabled,LIB_LETTER);
    
    /* make the call, save the return value */
    ret=(*fptr)(path,oflag, mode);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("open64");
        audlib_log_int(curent, oflag);
        audlib_log_mode(curent, mode);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return(ret);
}

/*------------------------------------------------------------------------ 
 * openat64 - 
 *------------------------------------------------------------------------
 */
int openat64(int dirfd, const char *path, int oflag, mode_t mode) {
    static  int (*fptr)(int, const char *, int , /* mode_t mode */...)=NULL;
    static intptr_t log_enabled = true;
    int ret;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(int, const char *, int , /* mode_t mode */...),
                          "openat64",fptr,-1,log_enabled,LIB_LETTER);
    
    /* make the call, save the return value */
    ret=(*fptr)(dirfd,path,oflag, mode);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("openat64");
        audlib_log_int(curent, oflag);
        audlib_log_mode(curent, mode);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return(ret);
}


/*------------------------------------------------------------------------ 
 * close - 
 *------------------------------------------------------------------------
 */
int close(int fildes) {
    static  int (*fptr)(int )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(int ),"close",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("close");
        audlib_log_int(curent, fildes);
        log_commitent(curent);
        
#ifdef CLOSE_FIX
        /* I think the problems comes from something trying to close my FD */
        if (fildes==M_fd) {
            curent = log_newent("close-fail");
            audlib_log_int(curent, fildes);
            log_commitent(curent);
            return(-1);
        }
#endif
    }
    return((*fptr)(fildes));
}


/*------------------------------------------------------------------------ 
 * creat - 
 *------------------------------------------------------------------------
 */
int creat(const char *path, mode_t mode) {
    static  int (*fptr)(const char *, mode_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(const char *, mode_t ),"creat",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("creat");
        audlib_log_str(curent, path);
        audlib_log_mode(curent, mode);
        log_commitent(curent);
    }
    
    return((*fptr)(path,mode));
}

/*------------------------------------------------------------------------ 
 * creat64 - 
 *------------------------------------------------------------------------
 */
int creat64(const char *path, mode_t mode) {
    static  int (*fptr)(const char *, mode_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(const char *, mode_t ),"creat64",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("creat64");
        audlib_log_str(curent, path);
        audlib_log_mode(curent, mode);
        log_commitent(curent);
    }
    
    return((*fptr)(path,mode));
}


/*------------------------------------------------------------------------ 
 * chmod - 
 *------------------------------------------------------------------------
 */
int chmod(const char *path, mode_t mode) {
    static  int (*fptr)(const char *, mode_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(const char *, mode_t ),"chmod",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("chmod");
        audlib_log_str(curent, path);
        audlib_log_mode(curent, mode);
        log_commitent(curent);
    }
    
    return((*fptr)(path,mode));
}


/*------------------------------------------------------------------------ 
 * fchmod - 
 *------------------------------------------------------------------------
 */
int fchmod(int fildes, mode_t mode) {
    static  int (*fptr)(int , mode_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(int , mode_t ),"fchmod",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("fchmod");
        audlib_log_int(curent, fildes);
        audlib_log_mode(curent, mode);
        log_commitent(curent);
    }
    
    return((*fptr)(fildes,mode));
}

/*------------------------------------------------------------------------ 
 * fchmodat - 
 *------------------------------------------------------------------------
 */
int fchmodat(int dirfd, const char *path, mode_t mode, int flags) {
    static  int (*fptr)(int, const char *, mode_t, int )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(int, const char *, mode_t, int ),"fchmodat",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("fchmodat");
        audlib_log_str(curent, path);
        audlib_log_mode(curent, mode);
        log_commitent(curent);
    }
    
    return((*fptr)(dirfd,path,mode,flags));
}


/*------------------------------------------------------------------------ 
 * chown - 
 *------------------------------------------------------------------------
 */
int chown(const char *path, uid_t owner, gid_t group) {
    static  int (*fptr)(const char *, uid_t , gid_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(const char *, uid_t , gid_t ),"chown",fptr,
                          -1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("chown");
        audlib_log_str(curent, path);
        audlib_log_uid(curent, owner);
        audlib_log_gid(curent, group);
        log_commitent(curent);
    }
    
    return((*fptr)(path,owner,group));
}

/*------------------------------------------------------------------------ 
 * fchownat - 
 *------------------------------------------------------------------------
 */
int fchownat(int dirfd, const char *path, uid_t owner, gid_t group, int flags) {
    static  int (*fptr)(int, const char *, uid_t , gid_t, int )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(int, const char *, uid_t , gid_t, int ),"fchownat",fptr,
                          -1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("fchownat");
        audlib_log_str(curent, path);
        audlib_log_uid(curent, owner);
        audlib_log_gid(curent, group);
        log_commitent(curent);
    }
    
    return((*fptr)(dirfd,path,owner,group,flags));
}


/*------------------------------------------------------------------------ 
 * lchown - 
 *------------------------------------------------------------------------
 */
int lchown(const char *path, uid_t owner, gid_t group) {
    static  int (*fptr)(const char *, uid_t , gid_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(const char *, uid_t , gid_t ),"lchown",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("lchown");
        audlib_log_str(curent, path);
        audlib_log_uid(curent, owner);
        audlib_log_gid(curent, group);
        log_commitent(curent);
    }
    
    return((*fptr)(path,owner,group));
}


/*------------------------------------------------------------------------ 
 * fchown - 
 *------------------------------------------------------------------------
 */
int fchown(int fildes, uid_t owner, gid_t group) {
    static  int (*fptr)(int , uid_t , gid_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(int , uid_t , gid_t ),"fchown",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("fchown");
        audlib_log_int(curent, fildes);
        audlib_log_uid(curent, owner);
        audlib_log_gid(curent, group);
        log_commitent(curent);
    }
    
    return((*fptr)(fildes,owner,group));
}


/*------------------------------------------------------------------------ 
 * stat - 
 *------------------------------------------------------------------------
 */
int stat(const char *path, struct stat *buf) {
    static  int (*fptr)(const char *, struct stat *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(const char *, struct stat *),"stat",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("stat");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(path,buf));
}

/*------------------------------------------------------------------------ 
 * fstatat - 
 *------------------------------------------------------------------------
 */
int fstatat(int dirfd, const char *path, struct stat *buf, int flags) {
    static  int (*fptr)(int, const char *, struct stat *, int)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(int, const char *, struct stat *, int),"fstatat",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("fstatat");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(dirfd,path,buf,flags));
}

/*------------------------------------------------------------------------ 
 * fstatat64 - 
 *------------------------------------------------------------------------
 */
int fstatat64(int dirfd, const char *path, struct stat64 *buf, int flags) {
    static  int (*fptr)(int, const char *, struct stat64 *, int)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(int, const char *, struct stat64 *, int),"fstatat64",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("fstatat64");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(dirfd,path,buf,flags));
}

/*------------------------------------------------------------------------ 
 * stat64 - 
 *------------------------------------------------------------------------
 */
int stat64(const char *path, struct stat64 *buf) {
    static  int (*fptr)(const char *, struct stat64 *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(const char *, struct stat64 *),"stat64",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("stat64");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(path,buf));
}


/*------------------------------------------------------------------------ 
 * lstat - 
 *------------------------------------------------------------------------
 */
int lstat(const char *path, struct stat *buf) {
    static  int (*fptr)(const char *, struct stat *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(const char *, struct stat *),"lstat",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("lstat");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(path,buf));
}

/*------------------------------------------------------------------------ 
 * lstat64 - 
 *------------------------------------------------------------------------
 */
int lstat64(const char *file, struct stat64 *buf) {
    static  int (*fptr)(const char *, struct stat64 *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(const char *, struct stat64 *),"lstat64",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("lstat64");
        audlib_log_str(curent, file);
        log_commitent(curent);
    }
    
    return((*fptr)(file,buf));
}


/*------------------------------------------------------------------------ 
 * fstat - 
 *------------------------------------------------------------------------
 */
int fstat(int fildes, struct stat *buf) {
    static  int (*fptr)(int , struct stat *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(int , struct stat *),"fstat",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("fstat");
        audlib_log_int(curent, fildes);
        log_commitent(curent);
    }
    
    return((*fptr)(fildes,buf));
}


/*------------------------------------------------------------------------ 
 * unlink - 
 *------------------------------------------------------------------------
 */
int unlink(const char *path) {
    static  int (*fptr)(const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(const char *),"unlink",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("unlink");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(path));
}

/*------------------------------------------------------------------------ 
 * unlinkat - 
 *------------------------------------------------------------------------
 */
int unlinkat(int dirfd, const char *path, int flags) {
    static int (*fptr)(int, const char *, int )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, int),"unlinkat",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("unlinkat");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(dirfd,path,flags));
}


/*------------------------------------------------------------------------ 
 * truncate - 
 *------------------------------------------------------------------------
 */
int truncate(const char *path, off_t length) {
    static  int (*fptr)(const char *, off_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(const char *, off_t ),"truncate",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("truncate");
        audlib_log_str(curent, path);
        audlib_log_offset(curent, length);
        log_commitent(curent);
    }
    
    return((*fptr)(path,length));
}


/*------------------------------------------------------------------------ 
 * ftruncate - 
 *------------------------------------------------------------------------
 */
int ftruncate(int fildes, off_t length) {
    static  int (*fptr)(int , off_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(int , off_t ),"ftruncate",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("ftruncate");
        audlib_log_int(curent, fildes);
        audlib_log_offset(curent, length);
        log_commitent(curent);
    }
    
    return((*fptr)(fildes,length));
}


/*------------------------------------------------------------------------ 
 * fopen - 
 *------------------------------------------------------------------------
 */
FILE *fopen(const char *filename, const char *mode) {
    static  FILE *(*fptr)(const char *, const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( FILE *(*)(const char *, const char *),"fopen",fptr,
                          NULL,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("fopen");
        audlib_log_str(curent, filename);
        audlib_log_str(curent, mode);
        log_commitent(curent);
    }
    
    return((*fptr)(filename,mode));
}

/*------------------------------------------------------------------------ 
 * fopen64 - 
 *------------------------------------------------------------------------
 */
FILE *fopen64(const char *filename, const char *mode) {
    static  FILE *(*fptr)(const char *, const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( FILE *(*)(const char *, const char *),"fopen64",fptr,
                          NULL,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("fopen64");
        audlib_log_str(curent, filename);
        audlib_log_str(curent, mode);
        log_commitent(curent);
    }
    
    return((*fptr)(filename,mode));
}


/*------------------------------------------------------------------------ 
 * fclose - 
 *------------------------------------------------------------------------
 */
int fclose(FILE *stream) {
    static  int (*fptr)(FILE *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(FILE *),"fclose",fptr,EOF,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("fclose");
        audlib_log_pointer(curent, stream);
        log_commitent(curent);
    }
    
    return((*fptr)(stream));
}


/*------------------------------------------------------------------------ 
 * symlink - 
 *------------------------------------------------------------------------
 */
int symlink(const char *name1, const char *name2) {
    static  int (*fptr)(const char *, const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(const char *, const char *),"symlink",fptr,
                          -1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("symlink");
        audlib_log_str(curent, name1);
        audlib_log_str(curent, name2);
        log_commitent(curent);
    }
    
    return((*fptr)(name1,name2));
}

/*------------------------------------------------------------------------ 
 * symlinkat - 
 *------------------------------------------------------------------------
 */
int symlinkat(const char *name1, int newdirfd, const char *name2) {
    static int (*fptr)(const char *, int, const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, int, const char *),"symlinkat",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("symlinkat");
        audlib_log_str(curent, name1);
        audlib_log_str(curent, name2);
        log_commitent(curent);
    }
    
    return((*fptr)(name1,newdirfd,name2));
}


/*------------------------------------------------------------------------ 
 * rename - 
 *------------------------------------------------------------------------
 */
int rename(const char *old, const char *new) {
    static  int (*fptr)(const char *, const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(const char *, const char *),"rename",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("rename");
        audlib_log_str(curent, old);
        audlib_log_str(curent, new);
        log_commitent(curent);
    }
    
    return((*fptr)(old,new));
}

/*------------------------------------------------------------------------ 
 * renameat - 
 *------------------------------------------------------------------------
 */
int renameat(int olddirfd, const char *old, int newdirfd, const char *new) {
    static int (*fptr)(int, const char *, int, const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, int, const char *),"renameat",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("renameat");
        audlib_log_str(curent, old);
        audlib_log_str(curent, new);
        log_commitent(curent);
    }
    
    return((*fptr)(olddirfd,old,newdirfd,new));
}


/*------------------------------------------------------------------------ 
 * tmpfile - 
 *------------------------------------------------------------------------
 */
FILE *tmpfile(void) {
    static  FILE *(*fptr)()=NULL;
    static intptr_t log_enabled = true;
    FILE *ret;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( FILE *(*)(),"tmpfile",fptr,NULL,log_enabled,LIB_LETTER);
    
    ret=(*fptr)();
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("tmpfile");
        audlib_log_pointer(curent, ret);
        log_commitent(curent);
    }
    
    return(ret);
}


/*------------------------------------------------------------------------ 
 * mktemp - 
 *------------------------------------------------------------------------
 */
char *mktemp(char *template) {
    static  char *(*fptr)(char *)=NULL;
    static intptr_t log_enabled = true;
    char *ret;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( char *(*)(char *),"mktemp",fptr,NULL,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    ret=(*fptr)(template);
    if (misuse_initialized && log_enabled) {
        curent = log_newent("mktemp");
        audlib_log_str(curent, template);
        audlib_log_str(curent, ret);
        log_commitent(curent);
    }
    
    return(ret);
}


/*------------------------------------------------------------------------ 
 * mkstemp - 
 *------------------------------------------------------------------------
 */
int mkstemp(char *template) {
    static  int (*fptr)(char *)=NULL;
    static intptr_t log_enabled = true;
    int ret;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(char *),"mkstemp",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    ret=((*fptr)(template));
    if (misuse_initialized && log_enabled) {
        curent = log_newent("mkstemp");
        audlib_log_str(curent, template);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return(ret);
}


/*------------------------------------------------------------------------ 
 * access - 
 *------------------------------------------------------------------------
 */
int access(const char *path, int amode) {
    static int (*fptr)(const char *, int )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, int ),"access",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("access");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(path,amode));
}

/*------------------------------------------------------------------------ 
 * faccessat - 
 *------------------------------------------------------------------------
 */
int faccessat(int dirfd, const char *path, int mode, int flags) {
    static int (*fptr)(int, const char *, int, int )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, int, int ),"faccessat",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("faccessat");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(dirfd,path,mode,flags));
}

#ifdef HAS_ACL
#include <sys/acl.h>	    /* for acl */
/*------------------------------------------------------------------------ 
 * acl - 
 *------------------------------------------------------------------------
 */
int acl(const char *pathp, int cmd, int nentries, aclent_t *aclbufp) {
    static int (*fptr)(const char *, int , int , aclent_t *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, int , int , aclent_t *),"acl",
                          fptr, -1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("acl");
        audlib_log_str(curent, pathp);
        log_commitent(curent);
    }
    
    return((*fptr)(pathp,cmd,nentries,aclbufp));
}

/*------------------------------------------------------------------------ 
 * facl - 
 *------------------------------------------------------------------------
 */
int facl(int fildes, int cmd, int nentries, aclent_t *aclbufp) {
    static int (*fptr)(int , int , int , aclent_t *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int , int , int , aclent_t *),"facl",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("facl");
        audlib_log_int(curent, fildes);
        log_commitent(curent);
    }
    
    return((*fptr)(fildes,cmd,nentries,aclbufp));
}
#endif

/*------------------------------------------------------------------------ 
 * execl - 
 *------------------------------------------------------------------------
 */
int execl(const char *path, const char *arg, ...) {
    static int (*fptr)(const char *, char *const *, char *const *)=NULL;
    static intptr_t log_enabled = true;
    int curent, ret;
    va_list ap;
    char **argptrs;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const *, char *const *),
                          "execve", fptr, -1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("execl");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    //generate passable array argument pointers
    va_start(ap, arg);
    argptrs = aud_vargptrs(arg, ap);
    va_end(ap);
    
    ret = ((*fptr)(path, argptrs, environ));
    (*__freeptr)(argptrs);
    return (ret);
}


/*------------------------------------------------------------------------ 
 * execle - 
 *------------------------------------------------------------------------
 */
int execle(const char *path, const char *arg , ...) {
    static int (*fptr)(const char *, char *const *, char *const *)=NULL;
    static intptr_t log_enabled = true;
    int curent, ret;
    va_list ap;
    char **argptrs, **envp;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const *, char *const *),
                          "execve", fptr, -1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("execle");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    /* generate passable array argument pointers */
    va_start(ap, arg);
    argptrs = aud_vargptrs(arg, ap);
    envp = aud_vargptrs(va_arg(ap, char *), ap);
    va_end(ap);
    
    ret = ((*fptr)(path, argptrs, envp));
    (*__freeptr)(argptrs);
    return (ret);
}

/*------------------------------------------------------------------------ 
 * execlp - 
 *------------------------------------------------------------------------
 */
int execlp(const char *file, const char *arg, ...) {
    static int (*fptr)(const char *, char *const *)=NULL;
    static intptr_t log_enabled = true;
    int curent, ret;
    va_list ap;
    char **argptrs;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const *), "execvp", fptr,
                          -1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("execlp");
        audlib_log_str(curent, file);
        log_commitent(curent);
    }
    
    /* generate passable array argument pointers */
    va_start(ap, arg);
    argptrs = aud_vargptrs(arg, ap);
    va_end(ap);
    
    ret = ((*fptr)(file, argptrs));
    (*__freeptr)(argptrs);
    return (ret);
}


/*------------------------------------------------------------------------ 
 * execv - 
 *------------------------------------------------------------------------
 */
int execv(const char *path, char *const argv[]) {
    static int (*fptr)(const char *, char *const argv[])=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const argv[]),"execv",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("execv");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(path,argv));
}


/*------------------------------------------------------------------------ 
 * execve - 
 *------------------------------------------------------------------------
 */
int execve(const char *path, char *const argv[], char *const envp[]) {
    static int (*fptr)(const char *, char *const argv[], char *const envp[])=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const argv[], 
                                  char *const envp[]),"execve",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("execve");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(path,argv,envp));
}


/*------------------------------------------------------------------------ 
 * execvp - 
 *------------------------------------------------------------------------
 */
int execvp(const char *file, char *const argv[]) {
    static int (*fptr)(const char *, char *const argv[])=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, char *const argv[]),"execvp",
                          fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("execvp");
        audlib_log_str(curent, file);
        log_commitent(curent);
    }
    
    return((*fptr)(file,argv));
}

/*------------------------------------------------------------------------ 
 * link - 
 *------------------------------------------------------------------------
 */
int link(const char *existing, const char *new) {
    static int (*fptr)(const char *, const char *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, const char *),"link",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("link");
        audlib_log_str(curent, existing);
        audlib_log_str(curent, new);
        log_commitent(curent);
    }
    
    return((*fptr)(existing,new));
}

/*------------------------------------------------------------------------ 
 * linkat - 
 *------------------------------------------------------------------------
 */
int linkat(int olddirfd, const char *oldpath, 
           int newdirfd, const char *newpath, int flags) {
    static int (*fptr)(int, const char *, int, const char *, int)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, int, const char *, int),"linkat",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("linkat");
        audlib_log_str(curent, oldpath);
        audlib_log_str(curent, newpath);
        log_commitent(curent);
    }
    
    return((*fptr)(olddirfd, oldpath, newdirfd, newpath, flags));
}


/*------------------------------------------------------------------------ 
 * mknod - 
 *------------------------------------------------------------------------
 */
int mknod(const char *path, mode_t mode, dev_t dev) {
    static int (*fptr)(const char *, mode_t , dev_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, mode_t , dev_t ),"mknod",fptr,
                          -1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("mknod");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(path,mode,dev));
}

/*------------------------------------------------------------------------ 
 * mknodat - 
 *------------------------------------------------------------------------
 */
int mknodat(int dirfd, const char *path, mode_t mode, dev_t dev) {
    static int (*fptr)(int, const char *, mode_t , dev_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, mode_t , dev_t ),"mknodat",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("mknodat");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(dirfd,path,mode,dev));
}


#include <sys/statvfs.h>
/*------------------------------------------------------------------------ 
 * statvfs - 
 *------------------------------------------------------------------------
 */
int statvfs(const char *path, struct statvfs *buf) {
    static int (*fptr)(const char *, struct statvfs *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, struct statvfs *),"statvfs",fptr
                          ,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("statvfs");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(path,buf));
}

/*------------------------------------------------------------------------ 
 * statvfs64 - 
 *------------------------------------------------------------------------
 */
int statvfs64(const char *path, struct statvfs64 *buf) {
    static int (*fptr)(const char *, struct statvfs64 *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, struct statvfs64 *),"statvfs64",fptr
                          ,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("statvfs64");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(path,buf));
}


#include <utime.h>
/*------------------------------------------------------------------------ 
 * utime - 
 *------------------------------------------------------------------------
 */
int utime(const char *path, const struct utimbuf *times) {
    static int (*fptr)(const char *, const struct utimbuf *)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, const struct utimbuf *),"utime",
                          fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("utime");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(path,times));
}


/*------------------------------------------------------------------------ 
 * utimes - 
 *------------------------------------------------------------------------
 */
int utimes(const char *path, const struct timeval times[2]) {
    static int (*fptr)(const char *, const struct timeval times[2])=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(const char *, const struct timeval times[2]),
                          "utimes",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("utimes");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(path,times));
}

/*------------------------------------------------------------------------ 
 * futimesat - 
 *------------------------------------------------------------------------
 */
int futimesat(int dirfd, const char *path, const struct timeval times[2]) {
    static int (*fptr)(int, const char *, const struct timeval times[2])=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(int (*)(int, const char *, const struct timeval times[2]),
                          "futimesat",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("futimesat");
        audlib_log_str(curent, path);
        log_commitent(curent);
    }
    
    return((*fptr)(dirfd,path,times));
}


/*------------------------------------------------------------------------ 
 * dup2 - 
 *------------------------------------------------------------------------
 */
int dup2(int fildes, int fildes2) {
    static  int (*fptr)(int , int )=NULL;
    static intptr_t log_enabled = true;
    int ret;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(int , int ),"dup2",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    ret=((*fptr)(fildes,fildes2));
    
    if (misuse_initialized && log_enabled) {
        curent = log_newent("dup2");
        audlib_log_int(curent, fildes);
        audlib_log_int(curent, fildes2);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return(ret);
}


/*------------------------------------------------------------------------ 
 * dup - 
 *------------------------------------------------------------------------
 */
int dup(int fildes) {
    static  int (*fptr)(int )=NULL;
    static intptr_t log_enabled = true;
    int ret;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( int (*)(int ),"dup",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    ret=((*fptr)(fildes));
    
    if (misuse_initialized && log_enabled) {
        curent = log_newent("dup");
        audlib_log_int(curent, fildes);
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return(ret);
}


/*------------------------------------------------------------------------ 
 * write - 
 *------------------------------------------------------------------------
 */
ssize_t write(int fildes, const void *buf, size_t nbyte) {
    static  ssize_t (*fptr)(int , const void *, size_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( ssize_t (*)(int , const void *, size_t ),"write",fptr
                          ,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("write");
        audlib_log_int(curent, fildes);
        audlib_log_size(curent, nbyte);
        log_commitent(curent);
    }
    
    return((*fptr)(fildes,buf,nbyte));
}


/*------------------------------------------------------------------------ 
 * pwrite - 
 *------------------------------------------------------------------------
 */
ssize_t pwrite(int fildes, const void  *buf,  size_t  nbyte, off_t offset) {
    static  ssize_t (*fptr)(int , const void  *,  size_t  , off_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( ssize_t (*)(int , const void  *,  size_t  , off_t ),
                          "pwrite",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("pwrite");
        audlib_log_int(curent, fildes);
        audlib_log_size(curent, nbyte);
        audlib_log_offset(curent, offset);
        log_commitent(curent);
    }
    
    return((*fptr)(fildes,buf,nbyte,offset));
}


/*------------------------------------------------------------------------ 
 * read - 
 *------------------------------------------------------------------------
 */
ssize_t read(int fildes, void *buf, size_t nbyte) {
    static  ssize_t (*fptr)(int , void *, size_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( ssize_t (*)(int , void *, size_t ),"read",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("read");
        audlib_log_int(curent, fildes);
        audlib_log_size(curent, nbyte);
        log_commitent(curent);
    }
    
    return((*fptr)(fildes,buf,nbyte));
}


/*------------------------------------------------------------------------ 
 * pread - 
 *------------------------------------------------------------------------
 */
ssize_t pread(int fildes, void  *buf,  size_t  nbyte,  off_t offset) {
    static  ssize_t (*fptr)(int , void  *,  size_t  ,  off_t )=NULL;
    static intptr_t log_enabled = true;
    int curent;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND( ssize_t (*)(int , void  *,  size_t  ,  off_t ),
                          "pread",fptr,-1,log_enabled,LIB_LETTER);
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("pread");
        audlib_log_int(curent, fildes);
        audlib_log_size(curent, nbyte);
        audlib_log_offset(curent, offset);
        log_commitent(curent);
    }
    
    return((*fptr)(fildes,buf,nbyte,offset));
}

//changed signature to match prototype in sys/resource.h
/*------------------------------------------------------------------------ 
 * getrlimit - 
 *------------------------------------------------------------------------
 */
int getrlimit(__rlimit_resource_t resource, struct rlimit *rlp) {
    static int (*fptr)(__rlimit_resource_t, struct rlimit *)=NULL;
    static intptr_t log_enabled = false;
    int ret;
    int curent;
    
    AUDLIB_LOOKUP_COMMAND( int (*)(__rlimit_resource_t,struct rlimit *),
                          "getrlimit",fptr,-1,log_enabled,LIB_LETTER);
    
    ret=(*fptr)(resource,rlp);
    
    if (misuse_initialized) {
        /* we are using the highest available fd for myself */
        if (RLIMIT_NOFILE == resource) {
            rlp->rlim_cur -= 1; /* return one less */
            if (log_enabled) {
                curent = log_newent("getrlimit-fix");
                audlib_log_int(curent, rlp->rlim_cur);
                log_commitent(curent); 
            }
        }
    }
    return(ret);
}

/*------------------------------------------------------------------------ 
 * fork - 
 *------------------------------------------------------------------------
 */
pid_t fork(void) {
    static pid_t (*fptr)(void)=NULL;
    static intptr_t log_enabled = true;
    int curent;
    int ret;
    
    /* lookup next function */
    AUDLIB_LOOKUP_COMMAND(pid_t (*)(void),"fork",fptr,-1,log_enabled,LIB_LETTER);
    
    ret = ((*fptr)());
    
    /* generate audit information */
    if (misuse_initialized && log_enabled) {
        curent = log_newent("fork");
        audlib_log_int(curent, ret);
        log_commitent(curent);
    }
    
    return (ret);
}

/* vim:set fdm=marker:fdl=0:fen :set sw=4:*/
