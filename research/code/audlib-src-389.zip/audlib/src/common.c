/*
 * common.c
 *
 * Benjamin A. Kuperman
 * 02 July 2002
 *
 * Routines which are common to all libraries
 */

/*
 * $Id: common.c 387 2010-07-29 22:07:54Z jakimmel $
 *
 *
 */

#include <dlfcn.h>
#include <sys/types.h>
#include <pwd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/resource.h> /* for dup2 and getrlimit */
#ifdef LINUX
#include <linux/limits.h>
#else
#include <limits.h>
#endif /* LINUX */
#include <sys/times.h>
#include <sys/time.h>
#include <string.h>
#include <stdarg.h>
#include <syslog.h>
#include <stddef.h>
#include <errno.h>
#include <pthread.h>
#include "macros.h"
#include "protos.h"
#include "proclib.h"
#include "logent.h"
#include "whereptr.h"
#include "error.h"
#include "config.h"
#include "paths.h"
#include "hashtable.h"

//try this many times to set/unset locks.
#define FCNTL_MAX_TRIES 10 

//initial size for generic hashtables.
#define HT_INIT_SIZE 24

// Things needed for newer versions of glibc (2.7 and up I think)
#ifdef O_CLOEXEC
#define AUDLIB_OPEN_ARGS O_WRONLY|O_APPEND|O_CREAT|O_LARGEFILE|O_CLOEXEC
#define FOPEN_EXTRA "e"
#else
#define AUDLIB_OPEN_ARGS O_WRONLY|O_APPEND|O_CREAT|O_LARGEFILE
#define FOPEN_EXTRA ""
#endif /* FD_CLOEXEC */

//We need this to make pthread_once work so init is called only once
static pthread_once_t init_complete = PTHREAD_ONCE_INIT;

//hashtable pointers.  Different tables ensure no overlapping keys.
static hashtable *table;

/*------------------------------------------------------------------------
 * libopen - open a dynamic library
 *------------------------------------------------------------------------
 */
void *libopen(const char *path) {
    void *ptr;
#ifdef DEBUG
    audlib_debug("Entering libopen");
    audlib_debug(path);
#endif
    if (NULL == (ptr=dlopen(path,RTLD_LAZY))) {
#ifdef DEBUG
        audlib_debug(dlerror());
#endif
    }
#ifdef DEBUG
    audlib_debug("Exiting libopen");
#endif
    return(ptr);
}


/*------------------------------------------------------------------------
 * getfunc - search for the next library function
 *------------------------------------------------------------------------
 */
void *getfunc(void *handle, const char *name) {
    void *result;
    
#ifdef DEBUG
    audlib_debug("Entering getfunc(%s)",name);
#endif
    if (!handle) {
#ifdef DEBUG
        audlib_debug("Passed a null pointer looking up: ");
        audlib_debug(name);
#endif
        return NULL;
    }
    result=dlsym(handle,name);
#ifdef DEBUG
    audlib_debug("Exiting getfunc(%s): %d",name,result);
#endif
    return result; //result is NULL if this fails
}


/*------------------------------------------------------------------------
 * audlib_initialize - set up some local calls for functions like write
 *------------------------------------------------------------------------
 */
ssize_t (*__writeptr)(int , const void *, size_t )=NULL;
ssize_t (*__readptr)(int , void *, size_t )=NULL;
size_t  (*__fwriteptr)(const void *, size_t, size_t, FILE *)=NULL;
int     (*__openptr)(const char *, int , /* mode_t mode */...)=NULL;
int	(*__closeptr)(int )=NULL;
int	(*__fcloseptr)(FILE *)=NULL;
#ifdef DEBUG
int	(*__vprintfptr)(const char *, va_list)=NULL;
int	(*__printfptr)(const char *, /* args*/ ...)=NULL; 

#endif
int	(*__fprintfptr)(FILE *, const char *, /* args*/ ...)=NULL;

int	(*__snprintfptr)(char *, size_t, const char *, /* args*/ ...)=NULL;
int	(*__vsnprintfptr)(char *, size_t, const char *, va_list)=NULL;
#ifdef XSTAT
int	(*__statptr)(int,const char *, struct stat *)=NULL;
int	(*__lstatptr)(int,const char *, struct stat *)=NULL;
#else
int	(*__lstatptr)(const char *, struct stat *)=NULL;
int	(*__statptr)(const char *, struct stat *)=NULL;
#endif /* XSTAT */
int	(*__sscanfptr)(const char *, const char *, ...)=NULL;
char	*(*__fgetsptr)(char *, int , FILE *)=NULL;
FILE	*(*__fopenptr)(const char *, const char *)=NULL;
size_t	(*__strlenptr)(const char *)=NULL;
int	(*__readlinkptr)(const char * , char * , size_t )=NULL;
char	*(*__getloginptr)(void)=NULL;
int	(*__clock_gettimeptr)(clockid_t, struct timespec *)=NULL;
void	*(*__memcpyptr)(void *, const void *, size_t)=NULL;
char	*(*__strncpyptr)(char *, const char *, size_t)=NULL;
void	*(*__mallocptr)(size_t)=NULL;
void	*(*__reallocptr)(void *, size_t)=NULL;
void	(*__freeptr)(void *)=NULL;
clock_t	(*__timesptr)(struct tms *)=NULL;
char	*(*__get_current_dir_nameptr)(void)=NULL;
int     (*__dup2ptr)(int oldfd, int newfd)=NULL;
void *(*__memsetptr)(void *s, int c, size_t n)=NULL;
int (*__strcmpptr)(const char *s1, const char *s2)=NULL;
int (*__strncmpptr)(const char *s1, const char *s2, size_t n)=NULL;
char *(*__strndupptr)(const char *s, size_t n)=NULL;
int (*__fgetcptr)(FILE *file)=NULL;
int (*__ungetcptr)(int c, FILE *file)=NULL;
char *(*__indexptr)(const char *s, int c)=NULL;
char *(*__rindexptr)(const char *s, int c)=NULL;
char *(*__getenvptr)(const char *name)=NULL;
int (*__fcntlptr)(int fd, int cmd, ... /* arg */ )=NULL;


/*
 * Does the initialization for audlib.  pthread_once makes sure that the
 * process is done exacrlt once regardless of how many libraries are involved.
 */
void audlib_initialize() {    
    pthread_once(&init_complete, audlib_initialize_real);
}


/*
 * Gets function pointers.  Any interposed function that we use should
 * have a pointer initialized here.  Also initializes everything config
 * file based.
 */
void audlib_initialize_real() {
    void *libc_ptr;
    
    /* open the library */
    libc_ptr=libopen(LIBC_PATH);
    
    /* look up things */
    __readptr=getfunc(libc_ptr,"read");
    __writeptr=getfunc(libc_ptr,"write");
    __fwriteptr=getfunc(libc_ptr,"fwrite");
    __openptr=getfunc(libc_ptr,"open");
    __closeptr=getfunc(libc_ptr,"close");
    __fcloseptr=getfunc(libc_ptr,"fclose");
#ifdef XSTAT
    __statptr=getfunc(libc_ptr,"__xstat");
    __lstatptr=getfunc(libc_ptr,"__lxstat");
#else
    __statptr=getfunc(libc_ptr,"stat");
    __lstatptr=getfunc(libc_ptr,"lstat");
#endif /* XSTAT */
#ifdef DEBUG
    __vprintfptr=getfunc(libc_ptr,"vprintf");
    __printfptr=getfunc(libc_ptr,"printf");
#endif
    __fprintfptr=getfunc(libc_ptr,"fprintf");
    
    __snprintfptr=getfunc(libc_ptr,"snprintf");
    __vsnprintfptr=getfunc(libc_ptr,"vsnprintf");
    __sscanfptr=getfunc(libc_ptr,"sscanf");
    __fopenptr=getfunc(libc_ptr,"fopen");
    __fgetsptr=getfunc(libc_ptr,"fgets");
    __strlenptr=getfunc(libc_ptr,"strlen");
    __readlinkptr=getfunc(libc_ptr,"readlink");
    __getloginptr=getfunc(libc_ptr,"getlogin");
    __memcpyptr=getfunc(libc_ptr,"memcpy");
    __strncpyptr=getfunc(libc_ptr,"strncpy");
    __mallocptr=getfunc(libc_ptr,"malloc");
    __reallocptr=getfunc(libc_ptr,"realloc");
    __freeptr=getfunc(libc_ptr,"free");
    __timesptr=getfunc(libc_ptr,"times");
    __get_current_dir_nameptr=getfunc(libc_ptr,"get_current_dir_name");
    __dup2ptr=getfunc(libc_ptr,"dup2");
    __memsetptr=getfunc(libc_ptr,"memset");
    __strcmpptr=getfunc(libc_ptr,"strcmp");
    __strncmpptr=getfunc(libc_ptr,"strncmp");
    __strndupptr=getfunc(libc_ptr,"strndup");
    __fgetcptr=getfunc(libc_ptr,"fgetc");
    __ungetcptr=getfunc(libc_ptr,"ungetc");
    __rindexptr=getfunc(libc_ptr,"rindex");
    __indexptr=getfunc(libc_ptr,"index");
    __getenvptr=getfunc(libc_ptr,"getenv");
    __fcntlptr=getfunc(libc_ptr,"fcntl");
    
    //need to resolve clock_gettime from librt
    __clock_gettimeptr = dlsym(dlopen(LIBRT_PATH, RTLD_LAZY), "clock_gettime");
    
    /* make sure that we got all the needed pointers */
    if (!(__readptr && __writeptr && __fwriteptr && __openptr && __fprintfptr
#ifdef DEBUG
          && __vprintfptr && __printfptr 
#endif
          && __closeptr && __fcloseptr && __statptr && __snprintfptr &&
          __vsnprintfptr && __sscanfptr && __fopenptr && __fgetsptr &&
          __strlenptr && __lstatptr && __readlinkptr && __getloginptr &&
          __clock_gettimeptr && __memcpyptr && __strncpyptr && __mallocptr
          && __reallocptr && __freeptr && __timesptr && __dup2ptr &&
          __get_current_dir_nameptr && __memsetptr && __strcmpptr && 
          __strncmpptr && __strndupptr && __fgetcptr && __ungetcptr &&
          __rindexptr && __indexptr && __getenvptr && __fcntlptr)) {
        char * errmsg = "common::Failed to find libc functions\n";
        write(STDERR_FILENO, errmsg, strlen(errmsg));
        exit(EXIT_FAILURE);
    }
    
    openlog("Audlib", LOG_PID, LOG_USER); //initialize syslog
#ifdef DEBUG
    audlib_debug("initializing table");
#endif
    table = (hashtable *)(*__mallocptr)(sizeof(hashtable)); //allocating the tables is important
    if ( ht_init(table,AUDLIB_FUNCTIONS_INTERPOSED) == 0) { //create hash table for storing config/logging info
        (*__snprintfptr)(audlib_errmsg,127,"Hash table creation failed");
        audlib_error(AUD_GENERIC_FAILURE,"C:audlib_initialize");
    } 
    
#ifdef DEBUG
    audlib_debug("table init done");
#endif
    init_configuration(); //read in our configuration file and set up the audlib_config pointer
    
    /* clean things up */
    dlclose(libc_ptr);
}

#ifdef DEBUG
/*------------------------------------------------------------------------
 * audlib_debug - print a message if global var dbg is non-zero
 *------------------------------------------------------------------------
 */
void audlib_debug(const char *format, ...) {
    va_list ap;
    
    /* only print as desired && only if output initialized */
    if (__vsnprintfptr && __printfptr) {
        va_start(ap,format);
        (*__vprintfptr)(format,ap);
        va_end(ap);
        (*__printfptr)("\n");
    }
}
#endif

/*------------------------------------------------------------------------
 * audlib_locklog - lock the entire log file we are using for a write
 * (so that only one entry is written at a time)
 *------------------------------------------------------------------------
 */
int audlib_locklog(int fd) {
    struct flock lock;
    int i = 0;
    int retval = -1;
    lock.l_type = F_WRLCK;
    lock.l_start = 0; /* From the beginning of the file. */
    lock.l_whence = SEEK_SET;
    lock.l_len = 0; /* The entire length of the file. */
    /* This fixes an error when trying to run X (kde) through audlib.  */
    do {
        retval = (*__fcntlptr)(fd, F_SETLKW, &lock);
    } while ((i++ < FCNTL_MAX_TRIES) && (retval == -1) && (EINTR == errno));
    return retval;
}

/*------------------------------------------------------------------------
 * audlib_unlocklog - release the log we've obtained on the log file
 * (so other entries can be written)
 *------------------------------------------------------------------------
 */
int audlib_unlocklog(int fd) {
    struct flock lock;
    int i = 0;
    int retval = -1;
    lock.l_type = F_UNLCK;
    lock.l_start = 0; /* From the beginning of the file. */
    lock.l_whence = SEEK_SET;
    lock.l_len = 0; /* The entire length of the file. */
    /* This fixes an error when trying to run X (kde) through audlib.  */
    do {
        retval = (*__fcntlptr)(fd, F_SETLKW, &lock);
    } while ((i++ < FCNTL_MAX_TRIES) && (retval == -1) && (EINTR == errno));
    return retval;
}


#include <sysexits.h>
/*------------------------------------------------------------------------
 * audlib_locklog_exit - lock the file or exit
 *------------------------------------------------------------------------
 */
void audlib_locklog_exit(int fd) {
    if (audlib_locklog(fd)) {
        audlib_error(AUD_CANT_GET_LOCK, "C:locklog_exit");
    }
}

/*------------------------------------------------------------------------
 * audlib_unlocklog_exit - unlock the file or exit
 *------------------------------------------------------------------------
 */
void audlib_unlocklog_exit(int fd) {
    if (audlib_unlocklog(fd)) {
        audlib_error( AUD_CANT_UNLOCK, "C:unlocklog_exit");
    }
}

/*------------------------------------------------------------------------
 * mywrite - write out data (handling error conditions)
 *           (error handling taken from APUEv2)
 *------------------------------------------------------------------------
 */
ssize_t mywrite(int fd, const void *buf, size_t nbyte) {
    size_t  nleft;
    ssize_t nwritten;
    
    // Nothing to write, nothing to do
    if (0==nbyte)
        return(0);
    
    // We are using the regular write() call and continuing if interrupted
    
    nleft = nbyte;
    audlib_locklog_exit(fd);    // lock the log file
    while (nleft > 0) {
        nwritten = (*__writeptr)(fd,buf,nleft);
        if (errno == EFBIG) {
            return -2;
        }
        else if ( nwritten < 0 ) {
            AUDLIB_ERROR(-1, AUD_LOG_WRITE_FAILURE, "C:mywrite");
            if (nleft == nbyte) {
                audlib_unlocklog_exit(fd);
                return (-1);    // error
            } else {
                break;          // error, return amount written so far
            }
        } else if (0 == nwritten) {
            break;
        }
        nleft -= nwritten;
        buf   += nwritten;
    }
    audlib_unlocklog_exit(fd);  // release the log file
    return(nbyte - nleft);
}


/*------------------------------------------------------------------------
 * audlib_openlog - open the log file to be used
 *
 *  stderr will be used in the event of error
 *------------------------------------------------------------------------
 */
int  audlib_openlog(const char *envfield,int *fd, FILE **stream) {
    int fd2;	/* for dup2 */
    struct rlimit rlp;
    char *outfile;
    char buf[5];
    (*__snprintfptr)(buf,5,"L<%c>",envfield[7]);
    
    if (NULL != (outfile = (char *) aud_ht_get(buf))) { //Look for L<LIB_LETTER>
        if (-1 == (*fd = (*__openptr)(outfile, AUDLIB_OPEN_ARGS ,S_IRUSR|S_IWUSR,0600)) && errno != EROFS) {
            AUDLIB_ERROR(-1, AUD_LOG_OPEN_FAILURE, "C:audlib_openlog");
        }
    } else if (NULL != (outfile = (char *) aud_ht_get("L<all>"))) { 
        if (-1 == (*fd = (*__openptr)(outfile, AUDLIB_OPEN_ARGS ,S_IRUSR|S_IWUSR,0600)) && errno != EROFS) {
            AUDLIB_ERROR(-1, AUD_LOG_OPEN_FAILURE, "C:audlib_openlog");
        }
    } else if ((outfile=(*__getenvptr)(envfield))) {
        /* a filename is specified in the ENV */
        if (-1 == (*fd = (*__openptr)(outfile, AUDLIB_OPEN_ARGS ,S_IRUSR|S_IWUSR,0600)) && errno != EROFS) {
            AUDLIB_ERROR(-1, AUD_LOG_OPEN_FAILURE, "C:audlib_openlog");
        }
    } else if ((outfile = AUD_LOG_PATH)) { //default log path
        
        if (-1 == (*fd = (*__openptr)(outfile, AUDLIB_OPEN_ARGS ,S_IRUSR|S_IWUSR,0600))) {
            //when opening the default logfile fails, or filesystem is readonly (same thing, kind of), don't log  
            *stream=stderr;
            *fd=STDERR_FILENO;
            
            //destroying the hash table means nothing gets logged
            (*__freeptr)(table);
            ht_init(table,1);
            
            return 0; //returning 0 means INITIALIZED is false
        }
    }
    
    /* At this point, fd will either be a specified file or stderr.  Whichever
     * it is, we need to dup it so that we can use it (and protect it from
     * closing).
     */
    
    if (getrlimit(RLIMIT_NOFILE,&rlp) == -1) {
        AUDLIB_ERROR(-2, AUD_LOG_OPEN_FAILURE, "C:audlib_openlog");
    } else {
        fd2=(*__dup2ptr)(*fd,rlp.rlim_cur-1);
        if (-1 == fd2)  {
            AUDLIB_ERROR(-3, AUD_LOG_OPEN_FAILURE, "C:audlib_openlog");
        } else {
            if (STDERR_FILENO != *fd)
                (*__closeptr)(*fd);
            
#ifdef FD_CLOEXEC
            // make sure it closes across an exec
            int oldflags;
            oldflags = (*__fcntlptr)(fd2, F_GETFD);
            if (oldflags < 0)  {
                AUDLIB_ERROR(-666, AUD_LOG_OPEN_FAILURE, "C:audlib_openlog");
            }
            else {
                oldflags |= FD_CLOEXEC;
                oldflags = (*__fcntlptr)(fd2, F_SETFD, oldflags);
                if (oldflags < 0)  {
                    AUDLIB_ERROR(-666, AUD_LOG_OPEN_FAILURE, "C:audlib_openlog");
                }
            }
#endif /* FD_CLOEXEC */
            
            *fd=fd2;
            if (NULL == (*stream=fdopen(*fd,"a" FOPEN_EXTRA))) {
                (*__closeptr)(*fd);
                AUDLIB_ERROR(-4, AUD_LOG_OPEN_FAILURE, "C:audlib_openlog");
            }
        }
    }
    return 1;
}


/*
 * Function generateProcInfo by paksoy
 *
 * Reads information about self  process and stores it in specified
 * procInfo_t.
 * Reads from:
 * 	/proc/self/stat
 * 	/proc/self/cmdline
 * 	getresuid and getresgid
 *
 * Return:
 * 	pointer to a procInfo_t with generated information,
 * 	NULL on failure
 */
procInfo_t *generateProcInfo() {
    procInfo_t *target;
    FILE *procFile, *cmdlineFile;
    int getreserr, bytecount = 0;
    int nullcount=0;
    char cur;
    
    //open file descriptors
    procFile = (*__fopenptr)("/proc/self/stat","r" FOPEN_EXTRA);
    cmdlineFile = (*__fopenptr)("/proc/self/cmdline","r" FOPEN_EXTRA);
    
    //check if files opened successfully
    if (procFile && cmdlineFile) {
        target = (*__mallocptr)(sizeof(procInfo_t)+INIT_CMD_STR);
        target->cmdline_cap = INIT_CMD_STR;
        
        //read stat output into string
        (*__fgetsptr)(target->statStr,MAX_STAT_STR,procFile);
        
        (*__sscanfptr)(target->statStr,
                       "%d %s %c %d %d %d %d %d %lu %lu %lu %lu %lu %lu %lu %ld %ld %ld %ld"
                       " %ld %ld %lu %lu %ld %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu %lu"
                       " %lu %d %d",
                       &(target->pid), target->comm, &(target->state), &(target->ppid),
                       &(target->pgrp), &(target->session), &(target->tty_nr),
                       &(target->tpgid), &(target->flags), &(target->minflt),
                       &(target->cminflt), &(target->majflt), &(target->cmajflt),
                       &(target->utime), &(target->stime), &(target->cutime),
                       &(target->cstime), &(target->prioroty), &(target->nice),
                       &(target->zero), &(target->itrealvalue), &(target->starttime),
                       &(target->vsize), &(target->rss), &(target->rlim),
                       &(target->startcode), &(target->endcode), &(target->startstack),
                       &(target->kstkesp), &(target->kstkeip), &(target->signal),
                       &(target->blocked), &(target->sigignore), &(target->sigcatch),
                       &(target->wchan), &(target->nswap), &(target->cnswap),
                       &(target->exit_signal), &(target->processor));
        
        //read process credentials
        getreserr = getresuid(&(target->ruid), &(target->euid), &(target->suid));
        getreserr += getresgid(&(target->rgid), &(target->egid), &(target->sgid));
        if (getreserr<0)
            return NULL;
        
        //read command line in
        while(EOF != (cur=(*__fgetcptr)(cmdlineFile))) {
            if (bytecount >= target->cmdline_cap) {
                //Maximum capacity exceeded
                if (target->cmdline_cap==ARG_MAX)
                    return NULL;
                
#ifdef RA_EXP	
                target->cmdline_cap = (target->cmdline_cap * 2);
#else
                target->cmdline_cap += INIT_CMD_STR; //same as 1024
#endif
                
                if (target->cmdline_cap>ARG_MAX)
                    target->cmdline_cap = ARG_MAX;
                
                target = (*__reallocptr)(target, sizeof(procInfo_t) + target->cmdline_cap);
            }
            
            target->cmdline[bytecount] = cur;
            bytecount++;
            
            // count the number of arguments
            if ('\0' == cur) {
                nullcount++;
            }
        }
        
        //write the total number of the command line into struct
        target->cmdline_size = bytecount;
        //create arguments start pointer
        target->argstart = &(target->cmdline[(*__strlenptr)(target->cmdline)+1]);
        // record the number of arguments
        target->argc = nullcount;
        
        
        //get the actual path to executable from /proc/self/exe
        (*__memsetptr)(target->execpath,0,PATH_MAX);   // readlink doesn't put a null
        if (-1 == (aud_readlink("/proc/self/exe", target->execpath, PATH_MAX))) {
            return NULL;
        }
        
        (*__fcloseptr)(procFile);
        (*__fcloseptr)(cmdlineFile);
    }
    //file open error
    else 
        return NULL;
    
    /* calculate the number of entries and size of environ */
    target->envlength=0;
    for (target->envcount=0;
         environ[target->envcount] != NULL;
         target->envcount++) {
        target->envlength += (*__strlenptr)(environ[target->envcount]) + 1;
    }
    
    //return pointer to information
    return target;
}

procInfo_t *audlib_procbuf=NULL;

/*-----------------------------------------------------------------------------
 * getProcInfo - retrieve the current procInfo and generate appropriate error messages if necessary
 *-----------------------------------------------------------------------------
 */
procInfo_t *getProcInfo() {
    if (NULL == audlib_procbuf)
        audlib_procbuf = generateProcInfo();
    if (NULL == audlib_procbuf) {
        (*__snprintfptr)(audlib_errmsg, 127, "Could not acquire process info");
        AUDLIB_ERROR(NULL, AUD_GENERIC_FAILURE, "C:getProcInfo");
    }
    return audlib_procbuf;
}

/*-----------------------------------------------------------------------------
 * init_configuration - Starts the read process for the config file
 *-----------------------------------------------------------------------------
 */
void init_configuration() {
    procInfo_t *procinfo;
    procinfo = getProcInfo();
    read_config(procinfo->execpath);
}

/*-----------------------------------------------------------------------------
 * getErrorConfiguration - retrieve the error config parameters
 *-----------------------------------------------------------------------------
 */
intptr_t getErrorConfiguration(const char *call_label) {
    void *result = (void *)(*__mallocptr)(sizeof(void *));
    intptr_t eflags = -1;
    char buf[(*__strlenptr)(call_label)+5];
    (*__snprintfptr)(buf,(*__strlenptr)(call_label)+4,"E<%s>",call_label);
    if(NULL != (result = aud_ht_get(buf))) {
        eflags = (intptr_t) result -1;
    }
    else if (NULL != (result = aud_ht_get("E<all>"))) {
        eflags = (intptr_t) result -1;
    }
    else eflags = AUD_EXIT | AUD_PERROR | AUD_SYSLOG; //default does everything
    
    return eflags;
}

/*----------------------------------------------------------------------------
 * mytimes - calls system function times() and modifies the output
 * 
 * Parameter:
 * 	mytms_t *target: the destination to store results in
 *
 * Return:
 * 	0 on success,
 * 	-1 on failure
 *----------------------------------------------------------------------------
 */
int mytimes(struct mytms *target) {
    struct tms tmp;
    double tempfloat;
    //get number of clock ticks per second for platform
    double tickpersec = (double) sysconf(_SC_CLK_TCK);
    
    //error check
    if (((*__timesptr)(&tmp)==-1)||(tickpersec==-1))
        return (-1);
    
    //convert clock ticks to seconds
    tempfloat =  ((double) tmp.tms_utime) / tickpersec;
    target->utime.tv_sec = (int) tempfloat;
    target->utime.tv_nsec = (tempfloat - ((double) ((int) tempfloat))) *
	1000000000;
    
    tempfloat =  ((double) tmp.tms_stime) / tickpersec;
    target->stime.tv_sec = (int) tempfloat;
    target->stime.tv_nsec = (tempfloat - ((double) ((int) tempfloat))) *
	1000000000;
    
    tempfloat =  ((double) tmp.tms_cutime) / tickpersec;
    target->cutime.tv_sec = (int) tempfloat;
    target->cutime.tv_nsec = (tempfloat - ((double) ((int) tempfloat))) *
	1000000000;
    
    tempfloat =  ((double) tmp.tms_cstime) / tickpersec;
    target->cstime.tv_sec = (int) tempfloat;
    target->cstime.tv_nsec = (tempfloat - ((double) ((int) tempfloat))) *
	1000000000;
    
    return (0);
}

/*----------------------------------------------------------------------------
 * aud_strlen - wraps around strlen. prevents infinite loops caused by logger
 * logging itself
 *
 * Parameter:
 *	const char *s: pointer to the beginning of null terminated character
 *	array
 *
 * Returns:
 *	number of characters in string not including '\0'
 *----------------------------------------------------------------------------
 */
size_t aud_strlen(const char *s) {
    return ((*__strlenptr)(s));
}

/*----------------------------------------------------------------------------
 * aud_vargptrs - creates a null terminated array of pointers from given
 * va_list
 *
 * Paramerter
 *	char *firstarg	: first argument to put into array
 *	va_list args	: rest of arguments
 *
 * Return:
 *	On success: a pointer to an array of arrays
 *	On failure: NULL
 *
 * Note: dont forget to (*__freeptr)() returned pointer
 *----------------------------------------------------------------------------
 */
#define ARGARRAYCAP_INITIAL 10
char **aud_vargptrs(const char *firstarg, va_list args) {
    int argarraycap, i;
    char **ret;
    
    argarraycap = ARGARRAYCAP_INITIAL;
    ret = (char **) (*__mallocptr)(argarraycap*sizeof(char *));
    
    //first argument is arg
    ret[0] = (char *) firstarg;
    //fill in rest of arguments from va_arg
    for (i=1; ret[i-1]!=NULL; i++) {
        if (i>=argarraycap) {
            argarraycap += ARGARRAYCAP_INITIAL;
            ret = (char **)(*__reallocptr)(ret, argarraycap*sizeof(char *));
        }
        ret[i] = va_arg(args, char *);
    }
    
    return (ret);
}


//------------------------------------------------------------------------------
// Log entry augment functions:
//	audlib_log_str	    : log a string (nul terminated char array)
//	audlib_log_buffer   : log a binary buffer
//	audlib_log_int	    : log an integer
//	audlib_log_long	    : log a long integer
//	audlib_log_mode	    : log a mode_t
//	audlib_log_uid	    : log a uid_t
//	audlib_log_gid	    : log a gid_t
//	audlib_log_size	    : log a size_t
//	audlib_log_stat	    : log a struct stat
//	audlib_log_pointer  : log a void * pointer
//	audlib_log_offset   : log a off_t
//------------------------------------------------------------------------------

/*------------------------------------------------------------------------------
 * logs an integer into the given log entry
 *
 * Parameters:
 *	int entryhandle	: handle of the log entry to add to
 *	int integer	: integer value to log
 *
 * Return:
 *	on success: 0
 *	on failure: -1
 *------------------------------------------------------------------------------
 */
int audlib_log_int(int entryhandle, int integer) {
    return (audlib_log_data(entryhandle, &integer, SIZE_INT));
}

/*------------------------------------------------------------------------------
 * audlib_log_long - logs a long integer into the given log entry
 *------------------------------------------------------------------------------
 */
int audlib_log_long(int entryhandle, long longint) {
    return (audlib_log_data(entryhandle, &longint, SIZE_LONG));
}

/*------------------------------------------------------------------------------
 * audlib_log_mode - logs a mode_t into the given log entry
 *------------------------------------------------------------------------------
 */
int audlib_log_mode(int entryhandle, mode_t mode) {
    return (audlib_log_data(entryhandle, &mode, SIZE_MODE));
}

/*------------------------------------------------------------------------------
 * audlib_log_uid - logs a uid into the given log entry
 *------------------------------------------------------------------------------
 */
int audlib_log_uid(int entryhandle, uid_t uid) {
    return (audlib_log_data(entryhandle, &uid, SIZE_UID));
}

/*------------------------------------------------------------------------------
 * audlib_log_gid - logs a gid into the given log entry
 *------------------------------------------------------------------------------
 */
int audlib_log_gid(int entryhandle, gid_t gid) {
    return (audlib_log_data(entryhandle, &gid, SIZE_GID));
}

/*------------------------------------------------------------------------------
 * audlib_log_size - logs a size_t into the given log entry
 *------------------------------------------------------------------------------
 */
int audlib_log_size(int entryhandle, size_t size) {
    return (audlib_log_data(entryhandle, &size, SIZE_SIZE));
}

/*------------------------------------------------------------------------------
 * audlib_log_pointer - logs a pointer into the given log entry
 *------------------------------------------------------------------------------
 */
int audlib_log_pointer(int entryhandle, void *ptr) {
    return (audlib_log_data(entryhandle, &ptr, sizeof(void *)));
}

/*------------------------------------------------------------------------------
 * audlib_log_stat - logs a struct stat into the given log entry
 *------------------------------------------------------------------------------
 */
int audlib_log_stat(int entryhandle, struct stat statbuf) {
    return (audlib_log_data(entryhandle, &statbuf, SIZE_STAT));
}

/*------------------------------------------------------------------------------
 * audlib_log_offset - logs a variable of type off_t into the given log entry
 *------------------------------------------------------------------------------
 */
int audlib_log_offset(int entryhandle, off_t offset) {
    return (audlib_log_data(entryhandle, &offset, SIZE_OFFSET));
}

/*------------------------------------------------------------------------------
 * audlib_log_time - logs a time into the given log entry
 *------------------------------------------------------------------------------
 */
int audlib_log_time(int entryhandle, aud_time time) {
    return (audlib_log_data(entryhandle, &time, SIZE_TIME));
}

/*------------------------------------------------------------------------------
 * audlib_log_str - log a null terminated string into entry
 *
 * Parameters:
 *	int entryhandle	: handle of the log entry to add to
 *	const char *src	: pointer to null terminated string to log
 *
 * Return:
 *	on success: 0
 *	on failure: -1
 *------------------------------------------------------------------------------
 */
int audlib_log_str(int entryhandle, const char *src) {
    struct token_str *writebuf;
    size_t strsize;
    int ret;
    
    if (NULL == src)
        strsize = 0;
    else
        strsize = (*__strlenptr)(src);
    
    //create string token
    writebuf = (struct token_str *) (*__mallocptr)(SIZE_STR(strsize));
    
    writebuf->str_where = where_pointer(src);
    writebuf->str_size = strsize;
    if (NULL == src)
        (*__memcpyptr)(writebuf->str_start, "", strsize+1);
    else
        (*__memcpyptr)(writebuf->str_start, src, strsize+1);
    
    //write token to entry
    ret = (audlib_log_data(entryhandle, writebuf, SIZE_STR(strsize)));
    
    //free write buffer
    (*__freeptr)(writebuf);
    
    return (ret);
}

/*------------------------------------------------------------------------------
 * audlib_log_dst - log information about a string buffer pointer into an entry
 *
 * Parameters:
 *	int entryhandle	: handle of the log entry to add to
 *	const char *src	: pointer to null terminated string to log
 *
 * Return:
 *	on success: 0
 *	on failure: -1
 *------------------------------------------------------------------------------
 */
int audlib_log_dst(int entryhandle, const char *dst) {
    char wherechar = where_pointer(dst);
    
    //if any data log operation fails return -1
    if (    (audlib_log_data(entryhandle, &wherechar, sizeof(char))) ||
	    (audlib_log_data(entryhandle, &dst, sizeof(char *))))
        return (-1);
    
    return (0);
}

/*------------------------------------------------------------------------------
 * audlib_log_buffer - log a binary buffer token into given entry
 *
 * Parameters:
 *	int entryhandle	: handle of the log entry to add to
 *	void *data	: data to read from
 *	size_t size	: size of the data to write
 *
 * Return:
 *	on success: 0
 *	on failure: -1
 *------------------------------------------------------------------------------
 */
int audlib_log_buffer(int entryhandle, const void *data, size_t size) {
    char wherechar = where_pointer(data);
    //write token to entry, check if any of the writes failed
    if (    (audlib_log_data(entryhandle, &size, sizeof(size_t))) ||
	    (audlib_log_data(entryhandle, &wherechar, sizeof(char))) ||
	    (audlib_log_data(entryhandle, data, size))) {
        return (-1);
    }
    return (0);
}

/*------------------------------------------------------------------------------
 * audlib_log_data - puts binary data into given log entry. watches out for size an reallocated
 * memory if necessary.
 *
 * Parameters:
 *	int entryhandle	: handle of the log entry to add to
 *	int integer	: integer value to log
 *  size_t size : size of buffer
 *
 * Return:
 *	on success: 0
 *	on failure: -1
 *------------------------------------------------------------------------------
 */
int audlib_log_data(int entryhandle, const void *buf, size_t size) {
    struct logent_header *entptr;
    
    if (size<0)
        //negative size invalid
        return (-1);
    
    if (size==0)
        //no need to do anything
        return (0);
    
    if (NULL==(entptr = audlib_getentry(entryhandle))) {
        //Could not resolve entry ptr
        AUDLIB_ERROR(-1, AUD_GET_ENTRY_FAILURE, "C:audlib_log_data");
    }
    
    (entptr->size) += size;
    //realloc if size exceeds capacity
    if ((entptr->size) > (entptr->cap)) {
        while (entptr->size > entptr->cap)  // ensure that this is large enough
            (entptr->cap) += LOGENT_SIZE_INIT;
        entptr->endptr -= (intptr_t) entptr;     // let endptr hold the size of the record
        entptr = (struct logent_header *) (*__reallocptr)(entptr, (entptr->cap));
        if (NULL == entptr) {
            //failed realloc
            (entptr->cap) -= LOGENT_SIZE_INIT;
            (entptr->size) -= size;
            AUDLIB_ERROR(-1, AUD_FILL_ENTRY_FAILURE, "C:audlib_log_data");
        }
        entptr->endptr += (intptr_t) entptr;     // add the new pointer to the size so that endptr points to "new" space
        audlib_setentry(entryhandle,entptr);
    }
    
    //binary copy buffer into entry
    (*__memcpyptr)(entptr->endptr, buf, size);
    
    //advance endptr
    entptr->endptr += size;
    
    //success
    return 0;
}

/*------------------------------------------------------------------------
 * 
 * 
 *   ####   #    #  #####   #####    ####   #####    #####
 *  #       #    #  #    #  #    #  #    #  #    #     #
 *   ####   #    #  #    #  #    #  #    #  #    #     #
 *       #  #    #  #####   #####   #    #  #####      #
 *  #    #  #    #  #       #       #    #  #   #      #
 *   ####    ####   #       #        ####   #    #     #
 * 
 *------------------------------------------------------------------------
 */

int mystat(const char *path, struct stat *buf) {
#ifdef XSTAT
    return ((*__statptr)(_STAT_VER, path, buf));
#else
    return( (*__statptr)(path,buf) );
#endif
}

int mylstat(const char *path, struct stat *buf) {
#ifdef XSTAT
    return ((*__lstatptr)(_STAT_VER, path, buf));
#else
    return( (*__lstatptr)(path,buf) );
#endif
}

int aud_readlink(const char *path, char *buf, size_t bufsiz) {
    return( (*__readlinkptr)(path,buf,bufsiz) );
}

char *aud_getlogin(void) {
    struct passwd *pwent;
    if (NULL == (pwent=getpwuid(geteuid()))) {
        return NULL;
    }
    return pwent->pw_name;
}

char *aud_getcwd(void) {
    return ((*__get_current_dir_nameptr)());
}

void *aud_ht_get(const char *key) {
#ifdef DEBUG
    audlib_debug("Get for: %s",key);
#endif
    return ht_get(table,key);
}

void aud_ht_put(char *key, void *value) {
#ifdef DEBUG
    audlib_debug("%s => %d",key,value);
#endif
    ht_put(table,key,value,HT_ADD_UPDATE);
}

void aud_ht_put_and(char * key, intptr_t value) {
#ifdef DEBUG
    audlib_debug("%s => %d",key,value);
#endif
    ht_put(table,key, (void *)value,HT_ADD_AND);
}

// vim:sw=4:foldmethod=marker:foldenable
