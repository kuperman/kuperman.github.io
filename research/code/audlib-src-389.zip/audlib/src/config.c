#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include "config.h"
#include "protos.h"
#include "paths.h"
#include "error.h"

/*-------------------------------------------------------
 * get_bin_name - extract the binary name from a path
 *-------------------------------------------------------
 */
const char * get_bin_name(const char * path) {
    char * name;
    name = (*__rindexptr)(path, '/');
    if (NULL == name) //path wasn't a full path
        return path;
    return name+1; //string starting after the /
}

/*-------------------------------------------------------
 * make_flag - translate a flag name (i.e. perror, exit, and syslog) into a
 * numeric flag
 *-------------------------------------------------------
 */
intptr_t make_flag(char * flag) {
    if ((*__strlenptr)(flag) <= 0)
        return -1;
    if ('p' == flag[0])
        return AUD_PERROR;
    else if ('s' == flag[0])
        return AUD_SYSLOG;
    else if ('e' == flag[0])
        return AUD_EXIT;
    return 0;
}

/*-------------------------------------------------------
 * isstrchr - is c a valid configuration string character?
 *-------------------------------------------------------
 */
int isstrchr(char c) {
    return (isalnum(c) || '_' == c || ':' == c || '/' == c || '.' == c || '!' == c || '<' == c || '>' == c || '-' == c || '+' == c || '=' == c);
}


/*-------------------------------------------------------
 * skip_until_nl - ignore input until we encounter a newline
 *-------------------------------------------------------
 */
void skip_until_nl(FILE * file) {
    char c;
    while ('\n' != (c = (*__fgetcptr)(file)) && EOF != c);
}

/*-------------------------------------------------------
 * skip_config_block - ignore input until we reach the end of a block
 *-------------------------------------------------------
 */
void skip_config_block(FILE * file) {
    char c;
    while ('}' != (c = (*__fgetcptr)(file))) {
        if ('#' == c)
            skip_until_nl(file);
    }
}

/*-------------------------------------------------------
 * skip_unwanted - if a # is encountered, treat it as a comment and skip until the next valid character
 *-------------------------------------------------------
 */
void skip_unwanted(FILE * file) { //comments and whitespace
    char c;
    while (EOF != (c = (*__fgetcptr)(file))) {
        if ('#' == c)
            skip_until_nl(file);
        else if (!isspace(c)) {
            (*__ungetcptr)(c, file);
            return;
        }
    }
}
            
/*-------------------------------------------------------
 * more_input - checks to see if there is more input
 *
 * Returns:
 *      0 if EOF has been reached
 *      1 if there is more input
 *-------------------------------------------------------
 */
int more_input(FILE * file) {
    char c;
    if (EOF == (c = (*__fgetcptr)(file)))
        return 0;
    (*__ungetcptr)(c, file);
    return 1;
}

/*-------------------------------------------------------
 * Allocates a buffer and reads in a string of letters and _ and :
 * 
 * Returns:
 *      A pointer to the allocated buffer.
 *-------------------------------------------------------
 */
char * read_string(FILE * file) {
    int i = 0;
    char c;
    char * str = (*__mallocptr)(sizeof(char) * 128);
    while (isstrchr(c = (*__fgetcptr)(file)) && i != 127)
        str[i++] = c;
    (*__ungetcptr)(c, file);
    str[i] = '\0';
    return str;
}


/*-------------------------------------------------------
 * parse_config_line - read and parse the next line of the config file
 * syntax is:
 *      [!][KEY:]VALUE where KEY is one of A,I,M,E<NAME>, or L<NAME>
 *      NAME has the form "all" or lib_letter:function
 *      VALUE is either a function, an action to take on error, or a path
 *-------------------------------------------------------
 */
void parse_config_line(FILE * file) {
    void *value = (void *)2; //2 is true
    char * key;
    char c;
    
    skip_unwanted(file);
    key = read_string(file);
    if ('!' == key[0]) {
        value = (void *)1; //1 is false 
        key++;
    } else if ('L' == key[0] || 'E' == key[0]) {
        value = (*__indexptr)(key, '=') + 1; //pointer to the first path char
        key = (*__strndupptr)(key,value - (void*)key -1); //add a terminating null and discard the path
    } 
    if ('E' == key[0]) {
        aud_ht_put_and(key, make_flag(value));
    } else {
        aud_ht_put(key,value);
    }
    skip_unwanted(file);
    
    while(',' == (c = (*__fgetcptr)(file))) {
        skip_unwanted(file);
        key = read_string(file);
        value = (void *)2; //need to make sure this is reset
        if ('!' == key[0]) {
            value = (void *)1; //1 is false 
            key++;
        } else if ('L' == key[0] || 'E' == key[0]) {
            value = (*__indexptr)(key, '=') + 1; //pointer to the first path char
            key = (*__strndupptr)(key,value - (void *)key - 1); //add a terminating null and discard the path
        }
        if ('E' == key[0]) {
            aud_ht_put_and(key,make_flag(value));
        } else {
            aud_ht_put(key,value);
        }        
        skip_unwanted(file);
    }
    (*__ungetcptr)(c, file);
}

/*-------------------------------------------------------
 * parse_config_block - read and parse the next full configuration block
 * syntax is:
 *      program_label {
 *          line1
 *          line2
 *          line3...
 *      }
 *-------------------------------------------------------
 */
void parse_config_block(FILE * file) {
    char c;
    do {
        skip_unwanted(file);
        if ('}' == (c = (*__fgetcptr)(file))) {
            return;
        }
        else {
            (*__ungetcptr)(c, file);
            parse_config_line(file);
        }
    } while (more_input(file)); 
}


/*-------------------------------------------------------
 * read_config - read the audlib config file and generate a configuration structure
 *
 * parameter:
 *      name - full path to the binary being run (this affects which block in the config file is read)
 *
 * returns:
 *      a try object filled with configuration data
 *-------------------------------------------------------
 */
void read_config(const char * name) {
    FILE * file; 
    char * progname;
    char * fullpath;
    intptr_t val = 2;

    fullpath = (*__getenvptr)("AUDLIB_CONFIG");
    
    //If no env. variable is set, try default path
    if (fullpath == NULL)
        fullpath = AUD_CONFIG_PATH;

    if (NULL != fullpath) {
        file = (*__fopenptr)(fullpath, "r");

        if (NULL != file) {
            do {
                skip_unwanted(file);
                progname = read_string(file);
                if ((*__strlenptr)(progname) > 0) {
                    skip_unwanted(file);
                    if ('{' == (*__fgetcptr)(file)) {
                        if (progname[0] == '!') { //!NAME means don't interpose
                            val = 1;
                            progname++;
                        }
                        if (0 == (*__strcmpptr)("Default", progname) || 0 == (*__strcmpptr)(name, progname)
                                || 0 == (*__strcmpptr)(get_bin_name(name), progname)) {

                            aud_ht_put(progname,(void *)val);
#ifdef DEBUG
                            audlib_debug("Parsing block %s",progname);
#endif
                            parse_config_block(file);
                        } else                        
                            skip_config_block(file);
                    }
                }
                skip_unwanted(file);
            } while (more_input(file)); 
            (*__fcloseptr)(file);
        } //end if file != NULL
    } //end if fullpath != NULL
    
#ifdef DEBUG
    audlib_debug("Read config finished");
#endif
}
