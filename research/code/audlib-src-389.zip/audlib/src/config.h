#ifndef __AUD_CONFIG_H_
#define __AUD_CONFIG_H_

// These are used as masks when dealing with errors
#define AUD_PERROR 1
#define AUD_SYSLOG 2
#define AUD_EXIT 4

const char * get_bin_name(const char * path);
void parse_config_block(FILE * config);
void read_config(const char * name);

#endif
