#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include "macros.h"
#include "protos.h"
#include "logent.h"

//------------------------------------------------------------------------------
// Global variables for logging
//------------------------------------------------------------------------------

static struct entry_table *entry_table;
static pthread_once_t table_initialized = PTHREAD_ONCE_INIT;
static pthread_mutex_t entry_table_lock = PTHREAD_MUTEX_INITIALIZER;

//------------------------------------------------------------------------------
// Log entry control functions:
//	audlib_log_newent   : create a new log entry
//	audlib_log_commitent: commit the given log entry
//------------------------------------------------------------------------------

/*-----------------------------------------------------
 * audlib_log_newent - Creates a new log entry with given title. Space is
 * allocated in memory for the entry and a pointer to the entry is placed in a
 * lookup table. The index in the lookup table of the pointer is returned.
 *
 * Parameters:
 *	char newtitle[] : title string, maxsize LOGENT_SIZE_INIT
 *
 * Return:
 *	on success: unique entry handle for the entry created
 *	on failure: -1
 *-----------------------------------------------------
 */
int audlib_log_newent(char newtitle[],pid_t pid, pid_t ppid) {
   
    //create empty entry
    struct logent_header *newent;
    int new_handle;
    newent = (struct logent_header *) (*__mallocptr)(LOGENT_SIZE_INIT);
    if (!newent) {
	//(*__mallocptr) failed
	return (-1);
    }

    //initialize values
    (newent->size) = LOGENT_SIZE_FULLHEADER;
    (*__strncpyptr)(newent->title, newtitle, (LOGENT_TITLE_MAX-1));
    (newent->title)[LOGENT_TITLE_MAX-1] = '\0'; //definitely null terminated
    (newent->cap) = LOGENT_SIZE_INIT;
    (*__clock_gettimeptr)(CLOCK_REALTIME, &(newent->timestart));
    (newent->endptr) = &(newent->startbyte);
    (newent->pid) = getpid();
    (newent->ppid) = getppid();

    //put pointer in table, expand table if necessary

    pthread_once(&table_initialized, (void (*)(void))init_table);
                                              
    pthread_mutex_lock(&entry_table_lock);  // lock the table

    if (entry_table->num_handles + 1 >= entry_table->max_handles)
        expand_table();

    new_handle = get_unused_handle();
    entry_table->handles[new_handle] = newent;
    entry_table->num_handles++;

    pthread_mutex_unlock(&entry_table_lock); // unlock the table

    return new_handle;
}


/*-----------------------------------------------------
 * init_table - Initialize the entry table. Allocate space for an initial
 * number of handles.  Initialize the seek_start variable and nulls out all the
 * handles.
 *
 * Returns:
 *      if successful: 0
 *      otherwise: -1
 *-----------------------------------------------------
 */
int init_table() {
    int i;

    entry_table = (struct entry_table*) (*__mallocptr)(sizeof(struct entry_table));

    if (entry_table) {
        entry_table->max_handles = LOGENT_TABLE_INIT; //LOGENT_TABLE_INIT = 5
        entry_table->handles = (struct logent_header **) (*__mallocptr)(entry_table->max_handles *
                sizeof(void *));
        if (entry_table->handles) {
            //mark new spots with nulls
            for (i = 0; i < entry_table->max_handles; i++)
                entry_table->handles[i] = NULL;

            // reset the rest of the data
            entry_table->seek_start = 0;
            entry_table->num_handles = 0;
            table_initialized = 1;
        } else {
            AUDLIB_ERROR(-1, AUD_INIT_TABLE_FAILURE, "C:init_table");
        }
    } else {
        AUDLIB_ERROR(-1, AUD_INIT_TABLE_FAILURE, "C:init_table");
    }

    // allocate the mutex
    pthread_mutexattr_t attr;
    pthread_mutexattr_init(&attr);
    pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
    pthread_mutex_init(&entry_table_lock, &attr);
    pthread_mutexattr_destroy(&attr);

    return 0;
}

/*-----------------------------------------------------
 * expand_table - Expand the entry table, allocating space for more entries.
 * Call init_table if necessary. At the end, null out the new entries.
 *
 * Returns:
 *      if successful: 0
 *      otherwise: -1
 *-----------------------------------------------------
 */
int expand_table() {
    int i, oldmax;

    pthread_mutex_lock(&entry_table_lock);  // lock the table

    oldmax = entry_table->max_handles;
    entry_table->max_handles += LOGENT_TABLE_INIT; //so we are always adding 5
    entry_table->handles = (struct logent_header **) (*__reallocptr)(entry_table->handles,
            (entry_table->max_handles * sizeof(void *)));
    if (entry_table->handles) {
        //mark new spots with nulls
        for (i = oldmax; i < entry_table->max_handles; i++)
            entry_table->handles[i] = NULL;

        entry_table->seek_start = oldmax;
    } else {
        pthread_mutex_unlock(&entry_table_lock); // unlock the table
        AUDLIB_ERROR(-1, AUD_EXPAND_TABLE_FAILURE, "C:expand_table");
    }

    pthread_mutex_unlock(&entry_table_lock); // unlock the table

    return 0;
}

/*-----------------------------------------------------
 * get_unused_handle - Search through the table for a vacant entry, beginning
 * at seek_start.
 *
 * Return:
 *      A vacant table handle
 *-----------------------------------------------------
 */
int get_unused_handle() {
    int i;

    pthread_mutex_lock(&entry_table_lock);  // lock the table

    for (i = entry_table->seek_start; 
            entry_table->handles[i] != NULL; 
            i = ((i+1) % entry_table->max_handles)) { /* do nothing */ }

    entry_table->seek_start = (i + 1) % entry_table->max_handles;

    // Not needed since the table is already locked
    entry_table->handles[i] = (void *)-1; // mark it so that others won't use

    pthread_mutex_unlock(&entry_table_lock); // unlock the table

    return i;
}

/*-----------------------------------------------------
 * audlib_log_commitent - Commit the contents of the given entry. Entry cannot
 * be accessed after this.
 *
 * Parameter:
 *	int entryhandle	: log entry to commit
 *	FILE *logfile	: file handle of the log file to write to
 *
 * Return:
 *	if entry handle is valid: number of bytes written
 *	otherwise: -1
 *	
 *-----------------------------------------------------
 */
int audlib_log_commitent(int entryhandle, int fd) {         
    
    size_t ret;
    struct logent_header *curent;

    pthread_mutex_lock(&entry_table_lock);  // lock the table

    if (NULL == (curent = audlib_getentry(entryhandle))) {
	//Could not resolve entry ptr
        pthread_mutex_unlock(&entry_table_lock); // unlock the table
	return (-1);
    }

    //mark end time
    (*__clock_gettimeptr)(CLOCK_REALTIME, &(curent->timeend));

    //truncate entry by skipping over the temporary part
    curent->size -= LOGENT_SIZE_TEMP;

    //write entry to file
    ret = mywrite(fd, &(curent->size), (curent->size));
    
    //free entry buffer
    (*__freeptr)(curent);
    //decrease number of handles
    entry_table->num_handles--;
    entry_table->seek_start = entryhandle;
    //clear table entry
    entry_table->handles[entryhandle] = NULL;

    pthread_mutex_unlock(&entry_table_lock); // unlock the table

    return ((int) ret);
}

/*-----------------------------------------------------
 * audlib_getentry - look up the given entry handle in the entry table
 *
 * Parameters:
 *	int entryhandle	: handle of the log entry to add to
 *
 * Return:
 *	on success: pointer to the struct logent_header that contains entry
 *	on failure: NULL
 *-----------------------------------------------------
 */
struct logent_header * audlib_getentry(int entryhandle) {

    pthread_mutex_lock(&entry_table_lock);  // lock the table

    if (    (entryhandle<0) ||
	    (entryhandle>=entry_table->max_handles)) {
	//handle cannot be in table
        pthread_mutex_unlock(&entry_table_lock); // unlock the table
	return (NULL);
    }

    pthread_mutex_unlock(&entry_table_lock); // unlock the table

    return (entry_table->handles[entryhandle]);
}

/*-----------------------------------------------------
 * audlib_setentry - store an entry header in the entry table at a given handle
 *
 * Parameters:
 *      entryhandle : handle of the log entry to store to
 *
 *  Return:
 *      on success: pointer to the old entry header
 *      on failure: NULL
 *-----------------------------------------------------
 */
struct logent_header * audlib_setentry(int entryhandle,
                                                    struct logent_header *hdr) {
    struct logent_header *ret;

    pthread_mutex_lock(&entry_table_lock);  // lock the table
    
    if (    (entryhandle<0) ||
	    (entryhandle>=entry_table->max_handles)) {
	//handle cannot be in table
        pthread_mutex_unlock(&entry_table_lock); // unlock the table
	return NULL;
    }
    ret = entry_table->handles[entryhandle];
    entry_table->handles[entryhandle]=hdr;

    pthread_mutex_unlock(&entry_table_lock); // unlock the table

    return ret;
}
