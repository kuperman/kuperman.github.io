#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <syslog.h>
#include "protos.h"
#include "error.h"
#include "config.h"

/*----------------------------------------
 * get_msg - associate an error code with an error message
 * Parameters:
 *      errnum : the error code as defined in error.h
 * Returns:
 *      on success : The error message as a string
 *      on failure : NULL
 *----------------------------------------
 */
const char * get_msg(int errnum) {
    switch (errnum) {
        default: return "No error message specified";
        case AUD_GENERIC_FAILURE: return audlib_errmsg;
        case AUD_LOG_WRITE_FAILURE: return "Failed to write log entry";
        case AUD_LOG_OPEN_FAILURE: return "Failed to open log file";
        case AUD_NO_LOG_SPECIFIED: return "No log file specified";
        case AUD_CANT_GET_PID: return "Can't acquire pid of process";
        case AUD_CANT_GET_PPID: return "Can't acquire ppid of process";
        case AUD_CANT_GET_CWD: return "Can't acquire current working dir";
        case AUD_CANT_MAKE_LOG_ENTRY: return "Can't make log entry";
        case AUD_CANT_GET_TIME_INFO: return "Could not acquire process time info";
        case AUD_FAILED_STAT: return "Failed stat of process";
        case AUD_FAILED_LSTAT: return "Failed lstat of process";
        case AUD_CANT_GET_USERNAME: return "Failed getting username";
        case AUD_CANT_READ_CONFIG: return "Failed to read configuration file";
        case AUD_CANT_GET_LOCK: return "Failed to obtain lock for writing";
        case AUD_CANT_UNLOCK: return "Failed to release lock";
        case AUD_FILL_ENTRY_FAILURE: return "Failed to fill log entry with data";
        case AUD_GET_ENTRY_FAILURE: return "Failed to find specified log entry";
        case AUD_INIT_TABLE_FAILURE: return "Failed to initialize log entry table";
        case AUD_EXPAND_TABLE_FAILURE: return "Failed to expand table";
    }
    return NULL;
}

/*----------------------------------------
 * audlib_error - report a given error in different ways
 * the methods for reporting are configured by the audlib configuration file
 * (see config.[c|h])
 * Parameters:
 *      errnum : the error code as defined in error.h
 *      call_label : the label to use when reporting the error to identify the
 *      function from which it came
 *----------------------------------------
 */
void audlib_error(int errnum, const char * call_label) {
    intptr_t flags;
    const char * msg = get_msg(errnum);

    flags = getErrorConfiguration(call_label);
    if (-1 != flags) {
        if (flags & AUD_PERROR) {
            if (errno)
                (*__fprintfptr)(stderr, "%s %s: %s\n", call_label, msg, strerror(errno));
            else
                (*__fprintfptr)(stderr, "%s %s\n", call_label, msg);
        }
        if (flags & AUD_SYSLOG) {
            syslog(LOG_ERR, "%s %s: %s\n", call_label, msg, strerror(errno));
        }
        if (flags & AUD_EXIT) {
            exit(errnum);
        }
    } else {
        if (errno)
            (*__fprintfptr)(stderr, "%s %s: %s\n", call_label, msg, strerror(errno));
        else
            (*__fprintfptr)(stderr, "%s %s\n", call_label, msg);
        exit(errnum);
    }
}

