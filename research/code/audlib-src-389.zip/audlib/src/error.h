#ifndef   __AUD_ERROR_H_
#define   __AUD_ERROR_H_

char audlib_errmsg[128];

#define AUDLIB_ERROR(retval, errnum, call_label) audlib_error(errnum, call_label); return retval;

const char * get_msg(int errnum);
void audlib_error(int errnum, const char * call_label);

#define AUD_GENERIC_FAILURE 1
#define AUD_LOG_WRITE_FAILURE 2
#define AUD_LOG_OPEN_FAILURE 3
#define AUD_NO_LOG_SPECIFIED 4
#define AUD_CANT_GET_PID 5
#define AUD_CANT_GET_PPID 6
#define AUD_CANT_GET_CWD 7
#define AUD_CANT_MAKE_LOG_ENTRY 8
#define AUD_CANT_GET_TIME_INFO 9
#define AUD_FAILED_STAT 10
#define AUD_FAILED_LSTAT 11
#define AUD_CANT_GET_USERNAME 12
#define AUD_CANT_READ_CONFIG 13
#define AUD_CANT_GET_LOCK 14
#define AUD_CANT_UNLOCK 15
#define AUD_FILL_ENTRY_FAILURE 16
#define AUD_GET_ENTRY_FAILURE 17
#define AUD_INIT_TABLE_FAILURE 18
#define AUD_EXPAND_TABLE_FAILURE 19

#endif
