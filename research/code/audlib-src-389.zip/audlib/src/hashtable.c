/* hashtable.c
 *
 * A set of utility functions for the creation and maintenance of a hashtable
 *
 * Benjamin Kuperman - Spring 2006
 */

#include "protos.h"
#include "hashtable.h"
#include <math.h>



/*------------------------------------------------------------------------
 * next_prime - find the next largest prime number
 *------------------------------------------------------------------------
 */
int next_prime(int n) {
    if (0==(n%2))
        n++;
    while(!is_prime(n))
        n += 2;
    return n;
}


/*------------------------------------------------------------------------
 * is_prime - do a quick primality test
 *------------------------------------------------------------------------
 */
int is_prime(int n) {

    int limit, i;

    limit = ceil(sqrt(n)+1);

    for (i=3; i<limit; i++) {
        if ((n%i) == 0)
            return 0;
    }
    return 1;
}

/* Function: ht_init
 * ---------
 *  Description: Initialize a hashtable to store items
 *  Parameters: ht - the hash table being initialized
                size - the initial size for the table
 *  Returns: 0 on failure, 1 on success
 */
int ht_init(hashtable *ht, int size) {
    int i;
    int htsize;

    // to ensure insertion using quadratic probing, we'll automatically double
    // this value

    htsize=next_prime(2*size);
    ht->table=(ht_entry **)(*__mallocptr)(htsize * sizeof(ht_entry));
    if (NULL == ht->table) {
        return 0;
    }
    // initialize things
    ht->capacity=htsize;
    ht->size=0;
    for (i = 0; i<htsize; i++) {  // set all pointers to empty
        ht->table[i] = NULL;
    }
    
    return 1;
}


/*------------------------------------------------------------------------
 * ht_resize - double the capacity of ht
 *------------------------------------------------------------------------
 */
void ht_resize(hashtable *ht) {

    ht_entry **old;
    int num_buckets, i;

    old = ht->table;
    num_buckets = ht->capacity;

    ht_init(ht, ht->capacity);  // ht_init always doubles the asked capacity

    for (i=0; i<num_buckets; i++) {
        if (old[i] != NULL) {
            ht_put(ht, old[i]->key, old[i]->value,HT_ADD_IGNORE);
            (*__freeptr)(old[i]->key);
            (*__freeptr)(old[i]);
        }
    }
    (*__freeptr)(old);
}

/*------------------------------------------------------------------------
 * ht_dealloc - deallocate the memory blocks used by ht
 *------------------------------------------------------------------------
 */
void ht_dealloc(hashtable *ht, int dofree) {
    int i;

    for (i=0; i<ht->capacity; i++) {
        if (ht->table[i] != NULL) {
            (*__freeptr)(ht->table[i]->key);
            if (dofree) {
                (*__freeptr)(ht->table[i]->value);
            }
            (*__freeptr)(ht->table[i]);
        }
    }
    (*__freeptr)(ht->table);

}

/* Function: ht_hashcode
 * ---------
 *  Description: gets the hashcode for a given string
 *  Parameters: the string of interest
 *  Returns: an integer hashcode
 */
int ht_hashcode(const char *key) {

    const char *cptr;
    int retval;

    retval = 0;
    cptr=key;

    while (*cptr != '\0') {
        retval *= 31;
        retval += tolower(*cptr); // ignore case
        cptr++;
    }

    return abs(retval);
}


/* Function: ht_put
 * ---------
 *  Description: store a new entry in the table
 *  Parameters: ht - the table to store in
                key - the key for the new entry
                value - the value for the new entry
 *  Returns: nothing
 */
void ht_put(hashtable *ht, char *key, void *value, int mode) {
    int i;
    int bucket;
    int code;

    code = ht_hashcode(key);

    if (ht->size >= (ht->capacity/2))
        ht_resize(ht);

    for (i=0; 1; i++) {
        bucket = abs((code + i*i) % ht->capacity);
        //printf("put Probing =>%s<= %d + %d^2 %d\n", key, code, i, bucket);
        if (ht->table[bucket] == NULL) {

            // Store an entry at this location
            ht->table[bucket] = (*__mallocptr)(sizeof(ht_entry));
            ht->table[bucket]->key = key;
            ht->table[bucket]->value = value;
            ht->size++;
            break;
        } else if (0 == (*__strcmpptr)(ht->table[bucket]->key, key)) {
            //update the value if the keys are equal and the mode allows it
            if (mode == HT_ADD_AND) {
                intptr_t tmp1 = (intptr_t) ht->table[bucket]->value;
                intptr_t tmp2 = (intptr_t) value;
                ht->table[bucket]->value = (void *)(tmp1 & tmp2);
            } else if (mode == HT_ADD_UPDATE) {
                ht->table[bucket]->value = value;
            }
        }
    }

}


/* Function: ht_get
 * ---------
 *  Description: retreive an entry from the table
 *  Parameters: ht - the table to searh
                key - the key to search for
 *  Returns: a pointer to the desired entry, or NULL if no entry is found
 */
void *ht_get(hashtable *ht, const char *key) {
    int i;
    int bucket;
    int code;

    code = ht_hashcode(key);

    for (i=0; 1; i++) {

        bucket = abs((code + i*i) % ht->capacity);

        //printf("get Probing =>%s<= %d + %d^2 %d\n", key, code, i, bucket);
        if (ht->table[bucket] == NULL) {    // not in the list
            return NULL;
        }

        if (0 == (*__strcmpptr)(ht->table[bucket]->key, key)) { // found it
            return ht->table[bucket]->value;
        }
    }
}

/*------------------------------------------------------------------------
 * ht_keys - get an array of keys used in the table
 *------------------------------------------------------------------------
 */
char **ht_keys(hashtable *ht) {
    int i,pos;
    char **retval;

    retval = (char **) (*__mallocptr)(sizeof(char *) * ht->size);

    if (retval == NULL) {
        return NULL;
    }

    for (pos=i=0; i<ht->capacity; i++) {
        if (ht->table[i] != NULL)
            retval[pos++] = ht->table[i]->key;
    }

    return retval;
}

/*------------------------------------------------------------------------
 * ht_values - get an array of values stored in the table
 *------------------------------------------------------------------------
 */
void **ht_values(hashtable *ht) {
    int i,pos;
    void **retval;

    retval = (void **) (*__mallocptr)(sizeof(void *) * ht->size);

    if (retval == NULL) {
        return NULL;
    }

    for (pos=i=0; i<ht->capacity; i++) {
        if (ht->table[i] != NULL)
            retval[pos++] = ht->table[i]->value;
    }

    return retval;
}
