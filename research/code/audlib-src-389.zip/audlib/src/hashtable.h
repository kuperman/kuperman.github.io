#ifndef HASHTABLE_H
#define HASHTABLE_H 1

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

//different modes for adding to the hashtable
#define HT_ADD_AND 1    //ands in the new value to the old (should be used with
                        //integers, only applies when key is already in the table)
#define HT_ADD_UPDATE 2 //updates the old value with the new value 
#define HT_ADD_IGNORE 3 //ignores duplicate keys (default behavior)

/*------------------------------------------------------------------------
 * structs for representing the data
 *------------------------------------------------------------------------
 */

/** and entry in the table */
typedef struct {
    char *key;      // NULL terminated string that is the key
    void *value;    // pointer to whatever is being stored
} ht_entry;

/** the table itself */
typedef struct {
    ht_entry **table;  // array of pointers to entries
    int capacity;       // number of buckets in table
    int size;           // number of things in buckets
} hashtable;


/*------------------------------------------------------------------------
 * FUNCTION PROTOTYPES
 *------------------------------------------------------------------------
 */


/* hashtable.c */
int next_prime(int n);
int is_prime(int n);
int ht_init(hashtable *ht, int size);
void ht_resize(hashtable *ht);
void ht_dealloc(hashtable *ht, int dofree);
int ht_hashcode(const char *key);
void ht_put(hashtable *ht, char *key, void *value, int mode);
void *ht_get(hashtable *ht, const char *key);
char **ht_keys(hashtable *ht);
void **ht_values(hashtable *ht);

#endif /* HASHTABLE_H */
