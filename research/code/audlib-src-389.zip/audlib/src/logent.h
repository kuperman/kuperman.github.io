//$Id: logent.h 354 2010-06-30 02:13:18Z jakimmel $
//Header file for logging functions and stuctures
#ifndef __INC_LOGENT
#define __INC_LOGENT

#include <sys/time.h>
#include <sys/stat.h>
#include <stdio.h>
#include "proclib.h"

//---------------------
//CONSTANT DECLARATIONS
//---------------------

//Log entry constants----------------------------
#define LOGENT_TITLE_MAX 16 //title string length

//size of temporary section of logent_header
#define LOGENT_SIZE_TEMP (sizeof(size_t) + sizeof(void *))
//size of the full static entry header
#define LOGENT_SIZE_FULLHEADER ((2*sizeof(size_t)) + sizeof(void *) +\
	(LOGENT_TITLE_MAX*sizeof(char)) +(2*sizeof(struct timeval))) +\
        (2*sizeof(pid_t))
//default inital entry capacity (malloc size)
#define LOGENT_SIZE_INIT 1024
//default initial entry lookup table
#define LOGENT_TABLE_INIT 5
//-----------------------------------------------

//Token size constants------------------------------
#define SIZE_HDR    (sizeof(struct read_header))
//size of a string token from the strlen() of the string
#define SIZE_STR(x) (x+sizeof(size_t)+(2*sizeof(char)))
#define SIZE_DST    (sizeof(char)+sizeof(char *))
#define SIZE_TIME   (sizeof(aud_time))
#define SIZE_BUF(x) (x+sizeof(size_t)+sizeof(char))
#define SIZE_STAT   (sizeof(struct stat))
#define SIZE_INT    (sizeof(int))
#define SIZE_LONG   (sizeof(long))
#define SIZE_MODE   (sizeof(mode_t))
#define SIZE_UID    (sizeof(uid_t))
#define SIZE_GID    (sizeof(gid_t))
#define SIZE_SIZE   (sizeof(size_t))
#define SIZE_OFFSET (sizeof(off_t))
#define SIZE_POINTER (sizeof(void *))
//--------------------------------------------------
//format string for off_t
#if _FILE_OFFSET_BITS==64
#define OFF_FMT "%lld"
#else
#define OFF_FMT "%ld"
#endif
//-------------------
//STRUCT DECLARATIONS
//-------------------
//logent_header is used when entries are being generated
struct logent_header {
    size_t cap;
    void *endptr;
    size_t size;
    char title[LOGENT_TITLE_MAX];
    aud_time timestart;
    aud_time timeend;
    pid_t pid, ppid;
    char startbyte[1];
};

//read_header is used when entries are being read
struct read_header {
    size_t size;
    char title[LOGENT_TITLE_MAX];
    aud_time timestart;
    aud_time timeend;
    pid_t pid, ppid;
};


//struct for logging string tokens
struct token_str {
    //size of string including null ptr
    size_t str_size; 
    //character indicating where the string is stored
    //	S - stack, H - heap, G - Global
    char str_where;	
    char str_start[1];
};

//the table that is used to store entry handles
struct entry_table {
    int num_handles; //current number of handles used
    int max_handles; //number of handles that can currently fit in the space allocated for them
    int seek_start; //first handle to check for an empty spot
    struct logent_header **handles;
};

struct token_dst {
    char dst_where;
    char *dst_ptr;
};

//-------------------
//FUNCTION PROTOTYPES
//-------------------

int init_table();
int expand_table();
int get_unused_handle();
struct logent_header * audlib_getentry(int);
struct logent_header * audlib_setentry(int, struct logent_header*);

int audlib_log_newent(char [], pid_t pid, pid_t ppid);
int audlib_log_commitent(int, int);

int audlib_log_str(int, const char *);
int audlib_log_buffer(int, const void *, size_t);
int audlib_log_dst(int, const char *);
int audlib_log_int(int, int);
int audlib_log_stat(int, struct stat );
int audlib_log_mode(int, mode_t );
int audlib_log_uid(int, uid_t );
int audlib_log_gid(int, gid_t );
int audlib_log_long(int, long );
int audlib_log_size(int, size_t );
int audlib_log_time(int, aud_time );
int audlib_log_pointer(int, void *);
int audlib_log_offset(int, off_t);
int audlib_log_data(int, const void *, size_t);
#endif
