#ifndef   __MACROS_H
#define   __MACROS_H


#include <stdio.h>
#include <dlfcn.h>
#include <string.h>
#include <stdbool.h>
#include <sys/time.h>
#include "error.h"


/*------------------------------------------------------------------------
 * init_func(x) - set a function to be called at the start
 * fini_func(x) - set a function to be called at the end
 * 
 *------------------------------------------------------------------------
 */
#if defined(__GNUC__)
#define init_func(x) asm("\n\t.section	\".init\"\n\tcall "x" \n\tnop\n");
#define fini_func(x) asm("\n\t.section	\".fini\"\n\tcall x \n\tnop\n");
#else	/* defined(__GNUC__)*/
#if defined(__sun)	/* SPARCCompiler specific */
#define init_func(x) \#pragma init(x)
#define fini_func(x) \#pragma fini(x)
#endif	/* defined(__sun) */
#endif	/* defined(__GNUC__) */

/* --------------------------------------------------------
 * Look up the specified library function
 * Parameters:
 *      t: function type
 *      n: function name
 *      p: pointer to store the function
 *      e: error value to return in case of failure
 *      g: Log_enabled var so we can set whether or not we are logging things
 *      l: name of the library calling AUDLIB_LOOKUP_COMMAND
 * Notes: 
 *      If this fails before audlib_initialize is complete, it will cause
 *      a segfault instead of generating an error message
 *-----------------------------------------------------------
 */
#define AUDLIB_LOOKUP_COMMAND(t,n,p,e,g,l) if (p==NULL) { \
    p=(t)dlsym(RTLD_NEXT,n); \
    AUDLIB_LOOKUP_LOG(n,g,l); \
    if (p==NULL) { \
        (*__snprintfptr)(audlib_errmsg, 127, "Could not find %s in library", n); \
        AUDLIB_ERROR(e, AUD_GENERIC_FAILURE, "C:AUDLIB_LOOKUP_COMMAND"); \
    } }


/*-----------------------------------------------------------
 *  Look up the given function in our hash table and decide whether
 *  or not data from that function is being logged
 *  Parameters:
 *      n: function name
 *      g: log_enabled variable
 *      l: name of library calling AUDLIB_LOOKUP_LOG
 *  Notes: 
 *  This can only be done if audlib_initialize has completed.
 *  otherwise the function pointers will be garbage and dereferencing
 *  them will cause a segfault.  Also, always subtract 1 from the return
 *  value of ht_get when expecting a boolean.  Otherwise we'd have problems
 *  storing 0 values and checking for NULL pointers.
 *-------------------------------------------------------------
 */
#define AUDLIB_LOOKUP_LOG(n,g,l) if (INITIALIZED) { \
    void *ep = (void *)(*__mallocptr)(sizeof(void *)); \
    char buf[256]; \
    (*__snprintfptr)(buf,255,"%s:%s",l,n); \
    if (NULL != (ep = aud_ht_get(buf)) ) { \
     g = (intptr_t) ep -1; \
    } \
    else if (NULL != (ep = aud_ht_get(n)) ) { \
        g = (intptr_t) ep -1; \
    } \
    else if (NULL != (ep = aud_ht_get(l)) ) { \
        g = (intptr_t) ep -1; \
    } \
    else if (NULL != (ep = aud_ht_get("all")) ) { \
        g = (intptr_t) ep -1; \
 } \
    else \
        g = false; \
}


/*-----------------------------------------------------------
 *  Look up the given program name in our hash table and decide
 * whether or not data from that program is being logged
 *  Parameters:
 *      n: binary name (full path)
 *      s: static variable to hold the result (true or false)
 *  Notes: 
 *  Always subtract 1 from the return value of ht_get when expecting
 *  a boolean.  Otherwise we'd have problems storing 0 values and 
 *  checking for NULL pointers.
 *-------------------------------------------------------------
 */
#define AUDLIB_LOOKUP_INTERP(s,n) void *ep = (void *)(*__mallocptr)(sizeof(void *)); \
    if (NULL != (ep = aud_ht_get(n))) { \
        s = (intptr_t) ep -1; \
    } \
    else if (NULL != (ep = aud_ht_get("Default"))) { \
        s = (intptr_t) ep -1; \
    } \
    else { \
        s = false; \
    }


/* these are things that exist on Solaris 9 but not Solaris 5 */
#if defined(__EXTENSIONS__) || (__STDC__ == 0 && \
	        !defined(_XOPEN_SOURCE) && !defined(_POSIX_C_SOURCE))
#define HAS_VSCANF
#define HAS_VFSCANF
#define HAS_VSSCANF
#endif

/* This needs to be at least the number of interposed function in all libraries + 3
 * Last actual count of interposed functions: 140 (7/13/10)
 */
#define AUDLIB_FUNCTIONS_INTERPOSED 175

#endif /* __MACROS_H */
