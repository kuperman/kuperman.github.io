/* 
 * This file contains default paths for logging, configuration, and system libraries
 */

#ifndef _INCL_PATHS
#define _INCL_PATHS

//used for __clock_gettimeptr
#define	 LIBRT_PATH	"/lib/librt.so.1"

//if no logfile path is specified in ENV ($AUDLIB_ATTACK, $AUDLIB_MISUSE, $AUDLIB_INTRUSION)
#define AUD_LOG_PATH "/var/log/audlib"

//if no config file path is specified in ENV ($AUDLIB_CONFIG)
#define AUD_CONFIG_PATH "/etc/audlib.conf"



#endif