/*
 * Header for process information retreival library.
 * $Author: jakimmel $
 */

/*
 * $Id: proclib.h 358 2010-07-01 20:10:57Z jakimmel $
 */

#ifndef _INCL_PROCLIB
#define _INCL_PROCLIB

#define INIT_CMD_STR 1024
#define MAX_STAT_STR 400 
#ifdef LINUX
#include <linux/limits.h>
#else
#include <limits.h>
#endif /* LINUX */
#include <string.h>
#include <sys/types.h>
#include <time.h>

struct procInfo_s {
  //statStr holds the raw information received read from /proc/[pid]/stat
  char statStr[MAX_STAT_STR];

  //variables needed to read all information returned from "stat"
  // all variables have the same names as stated in "man 5 proc"
  //except for "0" which is named "zero"
  uid_t ruid, euid, suid, fuid;
  gid_t rgid, egid, sgid, fgid;
  pid_t pid, ppid, session; 
  gid_t pgrp, tpgid;
  void *startcode, *endcode, *startstack, *kstkesp, *kstkeip;
  int tty_nr,exit_signal, processor;
  char comm[PATH_MAX+1], state;
  unsigned long flags, minflt, cminflt, majflt, cmajflt, utime, stime,
		starttime, vsize, rlim, signal, blocked, sigignore, sigcatch,
		wchan, nswap, cnswap;
  long int cutime,cstime,prioroty,nice,zero,itrealvalue,rss;

  //cmdline_cap indicates the total length of raw command line string
  unsigned int cmdline_cap, cmdline_size;
  unsigned int argc;        /* number of arguments in command line */
  unsigned int envcount;    /* number of entries in environ        */
  unsigned int envlength;   /* binary length of entire environ     */

  char* argstart;
  
  //the absolute path of the binary
  char execpath[PATH_MAX]; 

  //create string to store raw output from cmdline, this string
  //needs to be realloced
  char cmdline[1];
};

typedef struct procInfo_s procInfo_t;

//aud_time is is the way we log time
typedef struct timespec aud_time;

//struct mytms contains process time usage information
// in seconds using variable type double
struct mytms {
  aud_time utime;  /* user time */
  aud_time stime;  /* system time */
  aud_time cutime; /* user time of dead children */
  aud_time cstime; /* system time of dead children */
};

int mytimes(struct mytms * );
procInfo_t *generateProcInfo(void);
procInfo_t *getProcInfo();
#endif
