#ifndef _INCL_PROTOS
#define _INCL_PROTOS
#include <sys/procfs.h>
#include <linux/types.h>
#include <sys/stat.h>
#include <stdarg.h>
#include <stdio.h>
#include <search.h>
#include <math.h>
#include "hashtable.h"

#include "config.h"

extern char **environ;

/* common.c */
void *libopen(const char *path);
void *getfunc(void *handle, const char *name);
void audlib_debug(const char *format, ...);
int audlib_openlog(const char *envfield,int *fd, FILE **stream);
/* common.c */
extern ssize_t (*__writeptr)(int, const void *, size_t);
extern ssize_t (*__readptr)(int, void *, size_t);
extern size_t (*__fwriteptr)(const void *, size_t, size_t, FILE *);
extern int (*__openptr)(const char *, int, ...);
extern int (*__closeptr)(int);
extern int (*__fcloseptr)(FILE *);
extern int (*__fprintfptr)(FILE *, const char *, ...);
extern int (*__snprintfptr)(char *, size_t, const char *, ...);
extern int (*__vsnprintfptr)(char *, size_t, const char *, va_list);
#ifdef LINUX
int	(*__statptr)(int,const char *, struct stat *);
int	(*__lstatptr)(int,const char *, struct stat *);
#else
int	(*__lstatptr)(const char *, struct stat *);
int	(*__statptr)(const char *, struct stat *);
#endif /* LINUX */
extern int (*__sscanfptr)(const char *, const char *, ...);
extern char *(*__fgetsptr)(char *, int, FILE *);
extern FILE *(*__fopenptr)(const char *, const char *);
extern size_t (*__strlenptr)(const char *);
extern int  (*__readlinkptr)(const char *, char *, size_t );
extern char *(*__getloginptr)(void);
extern int  (*__clock_gettimeptr)(clockid_t, struct timespec *);
extern void *(*__memcpyptr)(void *, const void *, size_t);
extern char *(*__strncpyptr)(char *, const char *, size_t);
extern void *(*__mallocptr)(size_t);
extern void *(*__reallocptr)(void *, size_t);
extern void (*__freeptr)(void *);
extern char *(*__get_current_dir_name)(void);
extern int (*__dup2ptr)(int oldfd, int newfd);
extern void *(*__memsetptr)(void *s, int c, size_t n);\
extern int (*__strcmpptr)(const char *s1, const char *s2);
extern int (*__strncmpptr)(const char *s1, const char *s2, size_t n);
extern char *(*__strndupptr)(const char *s, size_t n);
extern int (*__fgetcptr)(FILE *file);
extern int (*__ungetcptr)(int c, FILE *file);
extern char *(*__indexptr)(const char *s, int c);
extern char *(*__rindexptr)(const char *s, int c);
extern char *(*__getenvptr)(const char *name);
extern int (*__fcntlptr)(int fd, int cmd, ... /* arg */ );

void audlib_initialize();
void audlib_initialize_real();
int mystat(const char * , struct stat * );
int mylstat(const char * , struct stat * );
ssize_t mywrite(int fd, const void *buf, size_t nbyte);
size_t aud_strlen(const char * );
int aud_readlink(const char *, char *, size_t );
char *aud_getlogin(void);
char **aud_vargptrs(const char *, va_list);
char *aud_getcwd(void);
void aud_ht_put(char *key, void *value);
void aud_ht_put_and(char *key, intptr_t value);
void *aud_ht_get(const char *key);
void init_configuration(void);
intptr_t getErrorConfiguration(const char *call_label);
#endif
