#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <strings.h>
#include <string.h>
#include <ctype.h>

#include "whereptr.h"
#include "protos.h"
#include "proclib.h"
#include "error.h"

intptr_t text_s, text_e; //the start and end of the address range
intptr_t data_s, data_e;
intptr_t heap_s, heap_e;
intptr_t stack_s, stack_e;
char text_p, data_p, heap_p, stack_p; //permission characters (w = write, x = execute, X = write and execute, - = neither)
char text_c='t', data_c='d', heap_c='h', stack_c='s', env_c='e'; //displayed characters (may be changed in init_whereptr)
void * startstack; //Used to discern environment variables

//These are for segments other than heap, stack, text, and data
#define OTHER_SEGMENTS 20
int other_segment_counter = 0;
intptr_t other_s[OTHER_SEGMENTS];
intptr_t other_e[OTHER_SEGMENTS];
char other_p[OTHER_SEGMENTS];

/* ------------------------------------------------------------------------
 * Parse one line of the /proc/self/maps file and gather information on the
 * address range of the segment and the write or execute permissions on the
 * segment.
 * ------------------------------------------------------------------------
 */
void parse_map_line(char * str, intptr_t * addr_range_start, intptr_t * addr_range_end, char * permission) {
    int result = 0;
    int offset = 0;
    char c = 0;

    c = str[offset++];
    while ('-' != c) {
        result *= 16;
        if (isdigit(c))
            result += c - '0';
        if (isalpha(c))
            result += c - 'a' + 10;
        c = str[offset++];
    }

    *addr_range_start = result;
    result = 0;

    c = str[offset++];
    while (!isspace(c)) {
        result *= 16;
        if (isdigit(c))
            result += c - '0';
        if (isalpha(c))
            result += c - 'a' + 10;
        c = str[offset++];
    }
    *addr_range_end = result;

    c = str[++offset];
    if ('-' == c)
        c = str[++offset];
    *permission = c;
}

/* Set up the address ranges and character values used by where_pointer. */
void init_whereptr() {
#define BUF_SIZE 4096
    int f;
    char buf[BUF_SIZE];   // leave room for null
    ssize_t chars_read;

    f = (*__openptr)("/proc/self/maps", O_RDONLY);
    if ((f < 0) || ((chars_read=(*__readptr)(f, buf, BUF_SIZE-1)) <= 0)) {

        (*__snprintfptr)(audlib_errmsg, 127, "Error reading /proc/self/maps");
        audlib_error(AUD_GENERIC_FAILURE,"C:init_whereptr");
    }
    (*__closeptr)(f);

    if (chars_read>0) {
        buf[chars_read] = '\0';
    }

    /* This routine sets the initial display characters and ranges */
    parse_map_string(buf); 

    /* If any segments are executable, uppercase them */
    if (text_p == 'x' || text_p == 'X')
        text_c = 'T';
    if (data_p == 'x' || data_p == 'X')
        data_c = 'D';
    if (heap_p == 'x' || heap_p == 'X')
        heap_c = 'H';
    if (stack_p == 'x' || stack_p == 'X') {
        stack_c = 'S';
        env_c = 'E';
    }

    procInfo_t *procinfo;
    procinfo = getProcInfo();
    startstack = procinfo->startstack;
}

/* Parse the entire map file as read from /proc/self/maps. 
 * This file is split into separate strings at \n's, and passed
 * on to parse_map_line.
 */
void parse_map_string(char * map_string) {
    int i;
    char *tok;

    char ** string_ptr = &map_string;

    i = 0;
    while (NULL != (tok = strsep(string_ptr, "\n"))) {
        if (0 == i)
            parse_map_line(tok, &text_s, &text_e, &text_p);
        else if (1 == i)
            parse_map_line(tok, &data_s, &data_e, &data_p);
        else if (strstr(tok, "[heap]"))
            parse_map_line(tok, &heap_s, &heap_e, &heap_p);
        else if (strstr(tok, "[stack]"))
            parse_map_line(tok, &stack_s, &stack_e, &stack_p);
        else if (other_segment_counter < OTHER_SEGMENTS) { //Not a named segment, so add it to the array of unnamed segments
            parse_map_line(tok, &other_s[other_segment_counter], 
                    &other_e[other_segment_counter], &other_p[other_segment_counter]);
            other_segment_counter++;
        }
        i++;
    }


}

char where_pointer(const void * ptr)
{
#ifdef SPEEDTEST
    return('?');
#endif
    if (onheap(ptr))
        return heap_c;
    else if (onenv(ptr))
        return env_c;
    else if (onstack(ptr))
        return stack_c;
    else if (ondata(ptr))
        return data_c;
    else if (ontext(ptr))
        return text_c;
    else 
        return onother(ptr);
    return '?';
}

/* Determine whether or not this addr falls within the range of one of the "other" segments
 * I.e., some segment that we don't track
 * Return:
 *      Either a permission char ('x', 'w', or 'X') or '?' 
 */
char onother(const void *addr) {
    int i;
    for (i = 0; i < other_segment_counter; i++) {
        if (addr > (void *)other_s[i] && addr < (void *)other_e[i] && '-' != other_p[i])
            return other_p[i];
    }
    return '?';
}


int onstack(const void * addr) {
    int stacktop;
    return (addr >= (void *)&stacktop && addr <= (void *)stack_e);
}

int ontext(const void * addr) {
    return (addr >= (void *)text_s && addr <= (void *)text_e);
}

int onheap(const void * addr) {
    return (addr >= (void *)heap_s && addr <= (void *)sbrk(0));
}

int ondata(const void * addr) {
    return (addr >= (void *)data_s && addr <= (void *)data_e);
}


int onenv(const void * addr) {
    return (addr >= (void *)startstack);
}

