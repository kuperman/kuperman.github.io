//Header file for finding the location of a pointer
#ifndef __INC_WHEREPTR
#define __INC_WHEREPTR

#include <sys/types.h>

//-------------------
//FUNCTION PROTOTYPES
//-------------------

void parse_map_line(char * str, intptr_t * addr_range_start, intptr_t * addr_range_end, char * permission);
void parse_map_string(char * map_string);
void init_whereptr();
char where_pointer(const void * ptr);
int onstack(const void * addr);
int ontext(const void * addr);
int onheap(const void * addr);
int ondata(const void * addr);
int onenv(const void * addr);
char onother(const void * addr);

#endif
