#include "logreader.h"

/*
 * Print out contents of header in human readable form
 *
 * Parameter:
 *	aud_hdr_t *hdr : pointer to header to read
 */
void *audlib_print_huhdr(aud_hdr_t *hdr, FILE *output) {
    static int count=0;
    fprintf(output, "|-----------------------------------|\n");
    fprintf(output, "|SIZE: %05zd TITLE: %-16.16s", hdr->size, hdr->title);
    fprintf(output, "|\n");
    fprintf(output, "|START: %12d.%09ld      |\n", (int)(hdr->timestart.tv_sec),
	    hdr->timestart.tv_nsec);
    fprintf(output, "|END  : %12d.%09ld      |\n", (int)(hdr->timeend.tv_sec),
	    hdr->timeend.tv_nsec);
    fprintf(output, "|PID  : %-22d      |\n", hdr->pid);
    fprintf(output, "|PPID : %-22d      |\n", hdr->ppid);
    fprintf(output, "|Count : %-21d      |\n", count++);
    fprintf(output, "|-----------------------------------|\n");
    
    return (void *)((char *) hdr + SIZE_HDR);
}

/*
 * Print out contents of a message in human readable form
 *
 * Parameter
 *	aud_message_t *msg : pointer to message to print
 */
void *audlib_print_humsg(aud_msg_t *msg, FILE *output) {
    fprintf(output, "#MESSAGE#\n");
    fprintf(output, "SIZE: %05zd TYPE: %c\n", msg->size, *(msg->message));
    fprintf(output, "MSG: \"%s\"\n", msg->message);
    fprintf(output, "#END#\n");
    fprintf(output, "====================\n");
    
    return (void *)((char *) msg + msg->size);
}

/*
 * following audlib_print_hu* functions print out log token types specified in
 * function name.
 *
 * Paramenter:
 *	[tokentype]_t * : pointer to the beginning of the token
 *
 * Return:
 *	void * : pointer to the memory location after the end of printed token
 */
void *audlib_print_hubuffer(aud_buffer_t *buffer, FILE *output) {
    int i;
    char c;
    fprintf(output, "TOKEN TYPE: buffer\n");
    fprintf(output, "SIZE: %zd | WHERE: %c\n", buffer->size,
	    buffer->where);
    fprintf(output, "PAYLOAD START\n");
    for (i=0; i < (buffer->size); i++) {
        c = buffer->buffer[i];
        if ('\0' == c)
            fprintf(output, " ");
        else
            fprintf(output, "%c", c);
    }
    fprintf(output, "\nPAYLOAD END\n");
    return (void *) ((char *) buffer + SIZE_BUF(buffer->size));
}

void *audlib_print_hustr(aud_str_t *str, FILE *output) {
    fprintf(output, "TOKEN TYPE: string\n");
    fprintf(output, "SIZE: %zd | WHERE: %c\n", str->size, str->where);
    fprintf(output, "STRING: %s\n", str->str);
    return (void *) ((char *) str + SIZE_STR(str->size));
}

void *audlib_print_hudst(aud_dst_t *dst, FILE *output) {
    fprintf(output, "TOKEN TYPE: string buffer address\n");
    fprintf(output, "WHERE: %c | ADDRESS: %p\n", dst->where, dst->dst);
    return (void *) ((char *) dst + SIZE_DST);
}

void *audlib_print_hutimedur(aud_time_t *time, FILE *output) {
    fprintf(output, "TOKEN TYPE: time\n");
    fprintf(output, "%d.%09ld\n", (int)(time->tv_sec), time->tv_nsec);

    return (void *) ((char *) time + SIZE_TIME);
}

void *audlib_print_hustat(aud_stat_t *statptr, FILE *output) {
    char prnttimebuf[27];

    fprintf(output, "TOKEN TYPE: stat\n");
    fprintf(output, "Device: %.3lxx", (long unsigned int)(statptr->st_dev));
    fprintf(output, "/%.3dd ", (int)(statptr->st_dev));
    fprintf(output, "Inode: %d ", (int)(statptr->st_ino));
    fprintf(output, "Mode: 0%o ", statptr->st_mode);
    fprintf(output, "Hard links: %ju\n", (uintmax_t) statptr->st_nlink);
    fprintf(output, "Owner uid: %d Owner gid: %d ", statptr->st_uid,
	    statptr->st_gid);
    fprintf(output, "Device (for inode): %x\n", (unsigned int)(statptr->st_rdev));
    fprintf(output, "Size: " OFF_FMT " Block size: %ld Block count: %d\n",
	    statptr->st_size, statptr->st_blksize, (int)statptr->st_blocks);

    ctime_r(&(statptr->st_atime), prnttimebuf);
    fprintf(output, "Time of last access:        %s", prnttimebuf);
    ctime_r(&(statptr->st_mtime), prnttimebuf);
    fprintf(output, "Time of last modification:  %s" , prnttimebuf);
    ctime_r(&(statptr->st_ctime), prnttimebuf);
    fprintf(output, "Time of last status change: %s", prnttimebuf);

    return (void *) ((char *) statptr + SIZE_STAT);
}

void *audlib_print_huuid(aud_uid_t *uid, FILE *output) {
    fprintf(output, "TOKEN TYPE: uid\n");
    fprintf(output, "%hu\n", *uid);
    return (void *) ((char *) uid + SIZE_UID);
}

void *audlib_print_hugid(aud_gid_t *gid, FILE *output) {
    fprintf(output, "TOKEN TYPE: gid\n");
    fprintf(output, "%hu\n", *gid);
    return (void *) ((char *) gid + SIZE_GID);
}

void *audlib_print_humode(aud_mode_t *mode, FILE *output) {
    fprintf(output, "TOKEN TYPE: mode (permissions)\n");
    fprintf(output, "%o\n", (*mode & ALLPERMS));
    return (void *) ((char *) mode + SIZE_MODE);
}

void *audlib_print_huoffset(aud_offset_t *offset, FILE *output) {
    fprintf(output, "TOKEN TYPE: offset\n");
    fprintf(output, OFF_FMT "\n", *offset);
    return (void *) ((char *) offset + SIZE_OFFSET);
}

void *audlib_print_hupointer(aud_pointer_t *pointer, FILE *output) {
    fprintf(output, "TOKEN TYPE: pointer\n");
    fprintf(output, "%tx\n", (ptrdiff_t)*pointer);
    return (void *) ((char *) pointer + SIZE_POINTER);
}

void *audlib_print_huint(aud_int_t *integer, FILE *output) {
    fprintf(output, "TOKEN TYPE: int\n");
    fprintf(output, "%d\n", *integer);
    return (void *) ((char *) integer + SIZE_INT);
}

void *audlib_print_hulong(aud_long_t *longint, FILE *output) {
    fprintf(output, "TOKEN TYPE: long\n");
    fprintf(output, "%ld\n", *longint);
    return (void *) ((char *) longint + SIZE_LONG);
}

void *audlib_print_husize(aud_size_t *size, FILE *output) {
    fprintf(output, "TOKEN TYPE: size\n");
    fprintf(output, "%zd\n", *size);
    return (void *) ((char *) size + SIZE_SIZE);
}
