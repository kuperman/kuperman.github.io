// $Id: logprintlib.c 374 2010-07-13 19:05:50Z jakimmel $

/*
 * This file contains functions needed for printing out contents of audlib
 * logs.
 * It was originally a part of logreaderlib.c
 *
 * Written by Mustafa Paksoy August 2005
 */

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <ctype.h>
#include "logreader.h"

/*
 * Prints an entry with the options given
 *
 * Parameters:
 *	aud_hdr_t *entry    : entry to print
 *	options_t *opt	    : options to print the entry with
 *
 * Return:
 *	zero (0) on success, non-zero otherwise
 *
 */
int audlib_print_entry(aud_entry_t *entry, options_t *opt) {
    void *nexttoken;
    int i;
    aud_int_t *num;
    
    
    if (opt->format != 'h' && opt->format != 'p')
    {
        fprintf(opt->output, "Cannot print entry, invalid output type: %c\n", opt->format);
        return(-1);
    }
    
    //if title starts with a lowercase letter, the entry is a non-standard
    //message
    if ((islower(*(entry->hdr.title))) && (opt->printmsg)) {
        audlib_print_msg((aud_msg_t *) entry, opt->output, opt->format);
        return (0);
    }
    
    if (opt->printlog) {
        nexttoken = audlib_print_hdr((aud_hdr_t *) entry, opt->output, opt->format);
        if (opt->printtoken) {
            //COMMON
            if (0 == (strncmp((entry->hdr.title), "A:fork", LOGENT_TITLE_MAX)) 
                || 0 == (strncmp((entry->hdr.title), "I:fork", LOGENT_TITLE_MAX)) 
                || 0 == (strncmp((entry->hdr.title), "M:fork", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            
            //ATTACK LIBRARY
            //initialization
            else if (0 == (strncmp((entry->hdr.title), "A:init", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_uid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_uid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_uid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_gid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_gid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_gid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_buffer(nexttoken, opt->output, opt->format);
                num = nexttoken; //Right now, nexttoken is an int which is the number of env variables.
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
                for (i=0; i < *num; i++) {
                    nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                }
                if (opt->format == 'h')
                    fprintf(opt->output, "=======================ENTRY END"
                            "===========================\n");
            }
            //finalization
            else if (0 == (strncmp((entry->hdr.title), "A:fini", LOGENT_TITLE_MAX))) {
                if (opt->format == 'h')
                    fprintf(opt->output, "[empty entry stub for program exit "
                            "notification]\n");
            }
            //close fix notification
            else if (0 == (strncmp((entry->hdr.title), "A:close-fail", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            //close fix notification
            else if (0 == (strncmp((entry->hdr.title), "A:getrlimit-fix", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            
            //strcpy
            else if (0 == (strncmp((entry->hdr.title), "A:strcpy", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_dst(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            
            //strcat
            else if (0 == (strncmp((entry->hdr.title), "A:strcat", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            
            //gets
            else if (0 == (strncmp((entry->hdr.title), "A:gets_pre", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_dst(nexttoken, opt->output, opt->format);
            }
            else if (0 == (strncmp((entry->hdr.title), "A:gets", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            
            //scanf, vscanf, fscanf, vfscanf, printf, fprintf, vprintf,
            //vfprintf
            else if (	(0 == (strncmp((entry->hdr.title), "A:scanf", LOGENT_TITLE_MAX))) || 
                     (0 == (strncmp((entry->hdr.title), "A:vscanf", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:fscanf", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:vfscanf", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:printf", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:fprintf", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:vprintf", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:vfprintf", LOGENT_TITLE_MAX)))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            
            //sscanf, vsscanf
            else if (	(0 == (strncmp((entry->hdr.title), "A:sscanf", LOGENT_TITLE_MAX))) || 
                     (0 == (strncmp((entry->hdr.title), "A:vsscanf", LOGENT_TITLE_MAX)))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            
            //sprint, vsprintf
            else if (	(0 == (strncmp((entry->hdr.title), "A:sprintf", LOGENT_TITLE_MAX))) || 
                     (0 == (strncmp((entry->hdr.title), "A:vsprintf", LOGENT_TITLE_MAX)))) {
                nexttoken = audlib_print_dst(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            
            //realpath
            else if (0 == (strncmp((entry->hdr.title), "A:realpath_pre", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_dst(nexttoken, opt->output, opt->format);
            }
            else if (0 == (strncmp((entry->hdr.title), "A:realpath", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            
            //getwd
            else if (0 == (strncmp((entry->hdr.title), "A:getwd_pre", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            else if (0 == (strncmp((entry->hdr.title), "A:getwd", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_dst(nexttoken, opt->output, opt->format);
            }
            
            //snprintf, vsnprintf
            else if (	(0 == (strncmp((entry->hdr.title), "A:snprintf", LOGENT_TITLE_MAX))) || 
                     (0 == (strncmp((entry->hdr.title), "A:vsnprintf", LOGENT_TITLE_MAX)))) {
                nexttoken = audlib_print_dst(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_size(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            
            else if (	(0 == (strncmp((entry->hdr.title), "A:access", LOGENT_TITLE_MAX))) || 
                     (0 == (strncmp((entry->hdr.title), "A:chmod", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:chown", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:creat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:creat64", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:execv", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:execve", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:execvp", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:lchown", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:open", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:open64", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:stat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:stat64", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:lstat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:lstat64", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:statvfs", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:statvfs64", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:utime", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:utimes", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:execl", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:execle", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:execlp", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:chdir", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:chroot", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:openat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:futimesat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:mknod", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:mknodat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:openat64", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:unlink", LOGENT_TITLE_MAX)))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            
            //link
            else if ( (0 == (strncmp((entry->hdr.title), "A:link", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:linkat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:renameat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:symlink", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:symlinkat", LOGENT_TITLE_MAX)))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            
            //mount
            else if (0 == (strncmp((entry->hdr.title), "A:mount_pre", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            else if (0 == (strncmp((entry->hdr.title), "A:mount", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            else if (0 == (strncmp((entry->hdr.title), "A:rename", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            else if (   (0 == (strncmp((entry->hdr.title), "A:faccessat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:fchmodat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:fchownat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:fstatat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:unlinkat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "A:fstatat64", LOGENT_TITLE_MAX)))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            
            
            
            //umount
            else if (0 == (strncmp((entry->hdr.title), "A:umount", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            
            //umount2
            else if (0 == (strncmp((entry->hdr.title), "A:umount2", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            
            //getcwd
            else if (0 == (strncmp((entry->hdr.title), "A:getcwd_pre", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_dst(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_size(nexttoken, opt->output, opt->format);
            }
            else if (0 == (strncmp((entry->hdr.title), "A:getcwd", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_size(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            
            //acl
            else if (0 == (strncmp((entry->hdr.title), "A:acl", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }        
            
            //ATTACK DONE
            
            //INTRUSION LIBRARY
            else if (0 == (strncmp((entry->hdr.title), "I:init", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_uid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_uid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_uid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_gid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_gid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_gid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_buffer(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_stat(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_stat(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "I:fini", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_uid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_uid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_uid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_gid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_gid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_gid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_buffer(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_stat(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_stat(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_timedur(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_timedur(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_timedur(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "I:close-fail", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "I:getrlimit-fix", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            
            else if (	(0 == (strncmp((entry->hdr.title), "I:execl", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "I:execle", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "I:execlp", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "I:execv", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "I:execve", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "I:execvp", LOGENT_TITLE_MAX)))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            else if (0 == (strncmp((entry->hdr.title), "I:chdir", LOGENT_TITLE_MAX)) ||
                     0 == (strncmp((entry->hdr.title), "I:chroot", LOGENT_TITLE_MAX)) ) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            //INTRUSION DONE
            
            //MISUSE LIBRARY
            else if (0 == (strncmp((entry->hdr.title), "M:init", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_uid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_uid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_uid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_gid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_gid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_gid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_stat(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_stat(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:fini", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_uid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_uid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_uid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_gid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_gid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_gid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_timedur(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_timedur(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_timedur(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_timedur(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:open", LOGENT_TITLE_MAX)) ||
                     0 == (strncmp((entry->hdr.title), "M:open64", LOGENT_TITLE_MAX)) ||
                     0 == (strncmp((entry->hdr.title), "M:openat", LOGENT_TITLE_MAX)) ||
                     0 == (strncmp((entry->hdr.title), "M:openat64", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_mode(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            
            else if (	(0 == (strncmp((entry->hdr.title), "M:close", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:close-fail", LOGENT_TITLE_MAX)))) {
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:creat", LOGENT_TITLE_MAX)) || 
                     0 == (strncmp((entry->hdr.title), "M:creat64", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_mode(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:chown", LOGENT_TITLE_MAX)) ||
                     0 == (strncmp((entry->hdr.title), "M:lchown", LOGENT_TITLE_MAX)) ||
                     0 == (strncmp((entry->hdr.title), "M:fchownat", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_uid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_gid(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:fchown", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_uid(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_gid(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:chmod", LOGENT_TITLE_MAX)) ||
                     0 == (strncmp((entry->hdr.title), "M:fchmodat", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_mode(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:fchmod", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_mode(nexttoken, opt->output, opt->format);
            }
            
            else if (	(0 == (strncmp((entry->hdr.title), "M:stat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:lstat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:stat64", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:lstat64", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:faccessat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:futimesat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:mknodat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:fstatat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:unlinkat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:fstatat64", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:unlink", LOGENT_TITLE_MAX)))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:truncate", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_offset(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:ftruncate", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_long(nexttoken, opt->output, opt->format);
            }
            
            else if (   (0 == (strncmp((entry->hdr.title), "M:fopen", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:linkat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:renameat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:symlinkat", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:fopen64", LOGENT_TITLE_MAX)))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:fclose", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_pointer(nexttoken, opt->output, opt->format);
            }
            
            else if (	(0 == (strncmp((entry->hdr.title), "M:symlink", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:link", LOGENT_TITLE_MAX)))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:rename", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:tmpfile", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_pointer(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:mktemp", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:mkstemp", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            
            else if (	(0 == (strncmp((entry->hdr.title), "M:access", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:acl", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:execv", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:execve", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:execvp", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:execl", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:execle", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:execlp", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:mknod", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:statvfs", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:statvfs64", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:utime", LOGENT_TITLE_MAX))) ||
                     (0 == (strncmp((entry->hdr.title), "M:utimes", LOGENT_TITLE_MAX)))) {
                nexttoken = audlib_print_str(nexttoken, opt->output, opt->format);
            }
            else if (0 == (strncmp((entry->hdr.title), "M:facl", LOGENT_TITLE_MAX)) ||
                     0 == (strncmp((entry->hdr.title), "M:fstat", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:dup", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:dup2", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:write", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_size(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:pwrite", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_size(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_offset(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:read", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_size(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:pread", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_size(nexttoken, opt->output, opt->format);
                nexttoken = audlib_print_offset(nexttoken, opt->output, opt->format);
            }
            
            else if (0 == (strncmp((entry->hdr.title), "M:getrlimit-fix", LOGENT_TITLE_MAX))) {
                nexttoken = audlib_print_int(nexttoken, opt->output, opt->format);
            }
            //MISUSE DONE
            
            //No match for entry title anywhere
            else {
                fprintf(stderr, "audlib_print_entry::cannot print tokens, "
                        "unrecognized entry title: %s\n", entry->hdr.title);
                retval++;
            }
        }
        // handle EOL for parsable
        if ('p' == opt->format) {
            fprintf(opt->output,"\n");
        }
    }
    
    return (0);
}


/*
 * Prints given string (null terminated character array) escaping
 * non-alpha-numeric characters.
 *
 * Parameters:
 *	FILE *output	: output stream
 *	char *printstr	: string to print
 *
 * Return:
 *	On success  : number of characters printed
 *	On error    : -1
 */
int fprint_esc(FILE *output, const char *printstr) {
    return (fprintn_esc(output, printstr, strlen(printstr)));
}

/*
 * Prints n characters from given buffer escaping non-alpha-numeric characters.
 *
 * Parameters:
 *	FILE *output	: output stream
 *	char *printbuf	: string to print
 *
 * Return:
 *	On success  : number of characters printed
 *	On error    : -1
 */
int fprintn_esc(FILE *output, const char *printbuf, size_t n) {
    int i;
    char cur;
    fprintf(output,"\"");
    for (i=0; i<n; i++) {
        cur = printbuf[i];
        //non escaped character, print
        if (isalnum(cur)) {
            //print actual char
            fprintf(output, "%c", cur);
        }
        else {
            //print hex
            fprintf(output, "%%%.2x", cur);
        }
    }
    return (i);
}

/*
 * Prints contents of given time stamp as an escaped string.
 *
 * Parameters:
 *	FILE *output	    : output stream
 *	aud_time_t *timeptr : time to read from
 */
void fprint_time_esc(FILE *output, aud_time_t *timeptr) {
    struct tm tmbuf;
    char strbuf[31];
    size_t strfret;
    
    localtime_r(&(timeptr->tv_sec), &tmbuf);
    strfret = strftime(strbuf, 31, "%F %T", &tmbuf);
    snprintf(&(strbuf[strfret]), 31-strfret, ".%09ld",
             timeptr->tv_nsec);
    
    fprint_esc(output, strbuf);
}

// Print functions
void *audlib_print_hdr(aud_hdr_t *hdr, FILE *output, char format) {
    switch (format) {
        case 'h':
            return (audlib_print_huhdr(hdr, output));
        case 'p':
        default:
            return (audlib_print_pahdr(hdr, output));
    }
}

void *audlib_print_msg(aud_msg_t *msg, FILE *output, char format) {
    switch (format) {
        case 'h':
            return (audlib_print_humsg(msg, output));
        case 'p':
        default:
            return (audlib_print_pamsg(msg, output));
    }
}

void *audlib_print_buffer(aud_buffer_t *buffer, FILE *output, char format) {
    switch (format) {
        case 'h':
            return (audlib_print_hubuffer(buffer, output));
        case 'p':
        default:
            return (audlib_print_pabuffer(buffer, output));
    }
}

void *audlib_print_str(aud_str_t *str, FILE *output, char format) {
    switch (format) {
        case 'h':
            return (audlib_print_hustr(str, output));
        case 'p':
        default:
            return (audlib_print_pastr(str, output));
    }
}

void *audlib_print_dst(aud_dst_t *dst, FILE *output, char format) {
    switch (format) {
        case 'h':
            return (audlib_print_hudst(dst, output));
        case 'p':
        default:
            return (audlib_print_padst(dst, output));
    }
}

void *audlib_print_timedur(aud_time_t *time, FILE *output, char format) {
    switch (format) {
        case 'h':
            return (audlib_print_hutimedur(time, output));
        case 'p':
        default:
            return (audlib_print_patimedur(time, output));
    }
}

void *audlib_print_stat(aud_stat_t *stat, FILE *output, char format) {
    switch (format) {
        case 'h':
            return (audlib_print_hustat(stat, output));
        case 'p':
        default:
            return (audlib_print_pastat(stat, output));
    }
}

void *audlib_print_uid(aud_uid_t *uid, FILE *output, char format) {
    switch (format) {
        case 'h':
            return (audlib_print_huuid(uid, output));
        case 'p':
        default:
            return (audlib_print_pauid(uid, output));
    }
}

void *audlib_print_gid(aud_gid_t *gid, FILE *output, char format) {
    switch (format) {
        case 'h':
            return (audlib_print_hugid(gid, output));
        case 'p':
        default:
            return (audlib_print_pagid(gid, output));
    }
}

void *audlib_print_mode(aud_mode_t *mode, FILE *output, char format) {
    switch (format) {
        case 'h':
            return (audlib_print_humode(mode, output));
        case 'p':
        default:
            return (audlib_print_pamode(mode, output));
    }
}

void *audlib_print_offset(aud_offset_t *offset, FILE *output, char format) {
    switch (format) {
        case 'h':
            return (audlib_print_huoffset(offset, output));
        case 'p':
        default:
            return (audlib_print_paoffset(offset, output));
    }
}

void *audlib_print_pointer(aud_pointer_t *pointer, FILE *output, char format) {
    switch (format) {
        case 'h':
            return (audlib_print_hupointer(pointer, output));
        case 'p':
        default:
            return (audlib_print_papointer(pointer, output));
    }
}

void *audlib_print_int(aud_int_t *integer, FILE *output, char format) {
    switch (format) {
        case 'h':
            return (audlib_print_huint(integer, output));
        case 'p':
        default:
            return (audlib_print_paint(integer, output));
    }
}

void *audlib_print_long(aud_long_t *longint, FILE *output, char format) {
    switch (format) {
        case 'h':
            return (audlib_print_hulong(longint, output));
        case 'p':
        default:
            return (audlib_print_palong(longint, output));
    }
}

void *audlib_print_size(aud_size_t *size, FILE *output, char format) {
    switch (format) {
        case 'h':
            return (audlib_print_husize(size, output));
        default:
        case 'p':
            return (audlib_print_pasize(size, output));
    }
}

