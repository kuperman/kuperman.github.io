#include "logreader.h"

// Parsable token print functions
void *audlib_print_pahdr(aud_hdr_t *hdrptr, FILE *output) {
    fprintf(output, "#%d ", hdrptr->pid);
    fprintf(output, "#%d ", hdrptr->ppid);
    fprint_esc(output, hdrptr->title);
    fprintf(output, " ");
    fprint_time_esc(output, &(hdrptr->timestart));
    fprintf(output, " ");
    fprint_time_esc(output, &(hdrptr->timeend));
    fprintf(output, " ");

    return ((char *) hdrptr + SIZE_HDR);
}

void *audlib_print_pabuffer(aud_buffer_t *bufferptr, FILE *output) {
    fprintn_esc(output, &bufferptr->where, 1);
    fprintn_esc(output, bufferptr->buffer, bufferptr->size);
    fprintf(output, " ");
    return ((char *) bufferptr + SIZE_BUF(bufferptr->size));
}

void *audlib_print_pastr(aud_str_t *strptr, FILE *output) {
    fprintn_esc(output, &strptr->where, 1);
    fprintn_esc(output, strptr->str, strptr->size);
    fprintf(output, " ");
    return ((char *) strptr + SIZE_STR(strptr->size));
}

void *audlib_print_padst(aud_dst_t *dstptr, FILE *output) {
    fprintn_esc(output, &(dstptr->where), 1);
    fprintf(output, "&%tx ", (ptrdiff_t)dstptr->dst);
    return ((char *) dstptr + SIZE_DST);
}

void *audlib_print_pauid(aud_uid_t *uidptr, FILE *output) {
    fprintf(output, "#%d ", *uidptr);
    return ((char *) uidptr + SIZE_UID);
}

void *audlib_print_pagid(aud_gid_t *gidptr, FILE *output) {
    fprintf(output, "#%d ", *gidptr);
    return ((char *) gidptr + SIZE_GID);
}

void *audlib_print_pamode(aud_mode_t *modeptr, FILE *output) {
    fprintf(output, "@%o ", (unsigned int)*modeptr);
    return ((char *) modeptr + SIZE_MODE);
}

void *audlib_print_paoffset(aud_offset_t *offsetptr, FILE *output) {
    fprintf(output, "#" OFF_FMT " ", *offsetptr);
    return ((char *) offsetptr + SIZE_OFFSET);
}

void *audlib_print_papointer(aud_pointer_t *pointerptr, FILE *output) {
    fprintf(output, "&%tx ", (ptrdiff_t)*pointerptr);
    return ((char *) pointerptr + SIZE_POINTER);
}

void *audlib_print_paint(aud_int_t *intptr, FILE *output) {
    fprintf(output, "#%d ", *intptr);
    return ((char *) intptr + SIZE_INT);
}

void *audlib_print_pasize(aud_size_t *sizeptr, FILE *output) {
    fprintf(output, "#%zd ", *sizeptr);
    return ((char *) sizeptr + SIZE_SIZE);
}

void *audlib_print_palong(aud_long_t *longptr, FILE *output) {
    fprintf(output, "#%ld ", *longptr);
    return ((char *) longptr + SIZE_LONG);
}

void *audlib_print_patimedur(aud_time_t *timeptr, FILE *output) {
    fprintf(output, "#%d.%9ld ", (int)timeptr->tv_sec, timeptr->tv_nsec);
    return ((char *) timeptr + SIZE_TIME);
}

void *audlib_print_pamsg(aud_msg_t *msgptr, FILE *output) {
    fprint_esc(output, msgptr->message);
    fprintf(output, " ");
    return ((char *) msgptr + msgptr->size);
}

void *audlib_print_pastat(aud_stat_t *statptr, FILE *output) {
    char prnttimebuf[27];

    fprintf(output, "&%.3lx", (long unsigned int)statptr->st_dev);
    fprintf(output, "#%d", (int)statptr->st_ino);
    fprintf(output, "@%o", statptr->st_mode);
    fprintf(output, "#%ju", (uintmax_t) statptr->st_nlink);
    fprintf(output, "#%d#%d", statptr->st_uid, statptr->st_gid);
    fprintf(output, "&%x", (unsigned int)statptr->st_rdev);
    fprintf(output, "#" OFF_FMT "#%ld#%d",
	    statptr->st_size, statptr->st_blksize, (int)statptr->st_blocks);

    ctime_r(&(statptr->st_atime), prnttimebuf);
    fprint_esc(output, prnttimebuf);
    ctime_r(&(statptr->st_mtime), prnttimebuf);
    fprint_esc(output, prnttimebuf);
    ctime_r(&(statptr->st_ctime), prnttimebuf);
    fprint_esc(output, prnttimebuf);
    fprintf(output, " ");

    return ((char *) statptr + SIZE_STAT);
}
