//$Id: logreader.h 374 2010-07-13 19:05:50Z jakimmel $

/*
 * Header for Audit Library Log Reader
 *
 * Mustafa Paksoy
 * July 05
 */

#include <stdio.h>
#include <sys/types.h>
#include <stddef.h>
#include <stdint.h>
#include "../audlib/src/logent.h"
#include <sys/stat.h>

//MACROS
#define GETOPT(x) getopt(argc, argv, x)

//This should be all file permissions including: SUID, SGID, VTX
#ifndef ALLPERMS
#define ALLPERMS 07777
#endif

//VARIABLE TYPES
//------------------------------------------------------------------------------
//Global variables

extern int retval; 

//------------------------------------------------------------------------------
//Structs and Variable Types for Reading Tokens

//Header    : hdr
//Fixed size header that precedes all standard log entries
struct read_hdr {
    size_t size;
    char title[LOGENT_TITLE_MAX];
    aud_time timestart;
    aud_time timeend;
    pid_t   pid;
    pid_t   ppid;
};
typedef struct read_hdr aud_hdr_t;

//String    : str
struct read_str {
    size_t size;
    char where;
    char str[1];
};
typedef struct read_str aud_str_t;

//Buffer    : buffer
struct read_buffer {
    size_t size;
    char where;
    char buffer[1];
};
typedef struct read_buffer aud_buffer_t;

//String buffer destination : dst
struct read_dst {
    char where;
    char *dst;
};
typedef struct read_dst aud_dst_t;

//Timestamp : time
typedef struct timespec aud_time_t;

//File statistics : stat
typedef struct stat aud_stat_t;

//Used id : uid
typedef uid_t aud_uid_t;

//Group id : gid
typedef gid_t aud_gid_t;

//File modes : mode
typedef mode_t aud_mode_t;

//File offset : offset
typedef off_t aud_offset_t;

//Memory location/pointer : pointer
typedef caddr_t aud_pointer_t;

//Integer : int
typedef int aud_int_t;

//Long integer : long
typedef long aud_long_t;

//Size : size
typedef size_t aud_size_t;

//Message   : msg
//Non-standard log entry used for error messages and such
struct read_msg {
    size_t size;
    char message[1]; 
}; 
typedef struct read_msg aud_msg_t;

//Log entry : entry
//A log entry with a fixed size header and a variable size payload
struct read_entry {
    aud_hdr_t hdr;
    char payload[1];
};
typedef struct read_entry aud_entry_t;
//------------------------------------------------------------------------------

//For storing ang passing output options
struct options_s {
    int printmsg;
    int printlog;
    int printtoken;
    char format;
    FILE *output;
};
typedef struct options_s options_t;

//Default option vals
#define DEFOPT (options_t) {1,1,1,'h',stdout}

//PROTOTYPES

// miscelaneous functinos
void usage();

//Functions for reading log
FILE *audlib_get_logfile(const char *path);
aud_entry_t *audlib_get_entry(FILE *logfile);
int __peekcursize(FILE *logfile, size_t *cursize);

//Functions for printing log tokens
int audlib_print_entry(aud_entry_t *entry, options_t *opt);

// Print functions
void *audlib_print_hdr(aud_hdr_t *hdr, FILE *output, char format);
void *audlib_print_msg(aud_msg_t *msg, FILE *output, char format);
void *audlib_print_buffer(aud_buffer_t *buffer, FILE *output, char format);
void *audlib_print_str(aud_str_t *str, FILE *output, char format);
void *audlib_print_dst(aud_dst_t *dst, FILE *output, char format);
void *audlib_print_timedur(aud_time_t *time, FILE *output, char format);
void *audlib_print_stat(aud_stat_t *stat, FILE *output, char format);
void *audlib_print_uid(aud_uid_t *uid, FILE *output, char format);
void *audlib_print_gid(aud_gid_t *gid, FILE *output, char format);
void *audlib_print_mode(aud_mode_t *mode, FILE *output, char format);
void *audlib_print_offset(aud_offset_t *offset, FILE *output, char format);
void *audlib_print_pointer(aud_pointer_t *pointer, FILE *output, char format);
void *audlib_print_int(aud_int_t *integer, FILE *output, char format);
void *audlib_print_long(aud_long_t *longint, FILE *output, char format);
void *audlib_print_size(aud_size_t *size, FILE *output, char format);

// Human readable printing
void *audlib_print_huhdr(aud_hdr_t *hdr, FILE *output);
void *audlib_print_humsg(aud_msg_t *msg, FILE *output);
void *audlib_print_hubuffer(aud_buffer_t *buffer, FILE *output);
void *audlib_print_hustr(aud_str_t *str, FILE *output);
void *audlib_print_hudst(aud_dst_t *dst, FILE *output);
void *audlib_print_hutimedur(aud_time_t *time, FILE *output);
void *audlib_print_hustat(aud_stat_t *stat, FILE *output);
void *audlib_print_huuid(aud_uid_t *uid, FILE *output);
void *audlib_print_hugid(aud_gid_t *gid, FILE *output);
void *audlib_print_humode(aud_mode_t *mode, FILE *output);
void *audlib_print_huoffset(aud_offset_t *offset, FILE *output);
void *audlib_print_hupointer(aud_pointer_t *pointer, FILE *output);
void *audlib_print_huint(aud_int_t *integer, FILE *output);
void *audlib_print_hulong(aud_long_t *longint, FILE *output);
void *audlib_print_husize(aud_size_t *size, FILE *output);

// Parsable printing
void *audlib_print_pahdr(aud_hdr_t *hdrptr, FILE *output);
void *audlib_print_pabuffer(aud_buffer_t *bufferptr, FILE *output);
void *audlib_print_pastr(aud_str_t *strptr, FILE *output);
void *audlib_print_padst(aud_dst_t *dstptr, FILE *output);
void *audlib_print_pauid(aud_uid_t *uidptr, FILE *output);
void *audlib_print_pagid(aud_gid_t *gidptr, FILE *output);
void *audlib_print_pamode(aud_mode_t *modeptr, FILE *output);
void *audlib_print_paoffset(aud_offset_t *offsetptr, FILE *output);
void *audlib_print_papointer(aud_pointer_t *pointerptr, FILE *output);
void *audlib_print_paint(aud_int_t *intptr, FILE *output);
void *audlib_print_pasize(aud_size_t *sizeptr, FILE *output);
void *audlib_print_palong(aud_long_t *longptr, FILE *output);
void *audlib_print_patimedur(aud_time_t *timeptr, FILE *output);
void *audlib_print_pamsg(aud_msg_t *msgptr, FILE *output);
void *audlib_print_pastat(aud_stat_t *statptr, FILE *output);
int fprint_esc(FILE *output, const char *printstr);
int fprintn_esc(FILE *output, const char *printbuf, size_t n);
void fprint_time_esc(FILE *output, aud_time_t *timeptr);

