//$Id: logreaderlib.c 375 2010-07-13 19:08:45Z jakimmel $
// vim:foldmethod=marker:foldenable

/*
 * Function library for the log reader
 * Paksoy, August 05
 */


#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include "logreader.h"

//Private function prototypes

//------------------------------------------------------------
// LOG READING
//------------------------------------------------------------
/* Opens the logfile and returns its file pointer
 *
 * Parameter:
 *	char *path: nul-terminated string containing file path
 *
 * Return:
 *	ON SUCCESS  : a FILE * to the logfile at the starting index
 *	ON ERROR    : NULL
 */
FILE *audlib_get_logfile(const char *path){
    FILE *logfile;
    
    //open log file
    logfile = fopen(path, "r");
    return logfile;
}
    
/*
 * Return a pointer to the current entry header and seek to the next header
 * NOTE: free returned pointer when done!
 *
 * Parameter:
 *	FILE *logfile :	logfile to read
 *
 * Return:
 *	On success  : pointer to current 
 *	On error/eof: NULL
 */
aud_entry_t *audlib_get_entry(FILE *logfile) {
    size_t cursize, read;
    aud_entry_t *curent;

#ifdef LOGREAD_DEBUG 
        fprintf(stderr, "audlib_getentry::entry ftell %ld\n",ftell(logfile));
#endif 
    if (__peekcursize(logfile, &cursize)) {
#ifdef LOGREAD_DEBUG 
	fprintf(stderr, "audlib_getentry::reached eof.\n");
#endif
	return (NULL);
    }
    if (cursize>(100*1024*1024)) {
        fprintf(stderr, "audlib_getentry::entry size too big %zd\n",cursize);
        retval++;

        char pre=0;
        char cur=0;
        while (!feof(logfile) && 
                !(('A'==pre || 'I' == pre || 'M'==pre || 'F' == pre) &&
                    (':' == cur))) {
            pre=cur;
            cur=fgetc(logfile);
        }
        if (!feof(logfile)) {
            if (-1 == fseek(logfile, -(sizeof(size_t)+2*sizeof(char)), SEEK_CUR)) {
                perror("audlib_getentry::resynchronizing after bad record");
                return(NULL);
            }
#ifdef LOGREAD_DEBUG 
        fprintf(stderr, "audlib_getentry::resynch ftell %ld\n",ftell(logfile));
#endif 
            return(audlib_get_entry(logfile));
        }
        return(NULL);
    }
#ifdef LOGREAD_DEBUG
        fprintf(stderr, "audlib_getentry::entry size %zd\n",cursize);
#endif 

    curent = (aud_entry_t *) malloc(cursize);
    if (curent == NULL) {
#ifdef LOGREAD_DEBUG 
	fprintf(stderr, "audlib_getentry::malloc failed: %zd bytes\n", cursize);
#endif 
	return (NULL);
    }
    if (cursize != (read = fread(curent, 1, cursize, logfile))) {
#ifdef LOGREAD_DEBUG 
	fprintf(stderr, "audlib_getentry::read less bytes than expected\n");
#endif 
	return (NULL);
    }

    if (curent->hdr.title[1] != ':') {
        fprintf(stderr, "audlib_getentry::not a valid record? %s\n",curent->hdr.title);
        retval++;
#ifdef LOGREAD_DEBUG 
        fprintf(stderr, "audlib_getentry::ftell %ld\n",ftell(logfile));
        sleep(1);
#endif 
        free(curent);
        char pre=0;
        char cur=0;
        while (!feof(logfile) && 
                !(('A'==pre || 'I' == pre || 'M'==pre || 'F' == pre
                || 'a'==pre || 'i' == pre || 'm'==pre || 'f' == pre) &&
                (':' == cur))) {
            pre=cur;
            cur=fgetc(logfile);
        }
        if (!feof(logfile)) {
#ifdef LOGREAD_DEBUG 
        fprintf(stderr, "audlib_getentry::ftell before %ld\n",ftell(logfile));
#endif 
            if (-1 == fseek(logfile, -(sizeof(size_t)+2*sizeof(char)), SEEK_CUR)) {
                perror("audlib_getentry::resynchronizing after bad record");
                retval++;
                return(NULL);
            }
#ifdef LOGREAD_DEBUG
        fprintf(stderr, "audlib_getentry::ftell after %ld\n",ftell(logfile));
#endif 
            return(audlib_get_entry(logfile));
        }
#ifdef LOGREAD_DEBUG 
        fprintf(stderr, "audlib_getentry::couldn't resync\n");
#endif 
        return(NULL);
    }

    //successful
    return (curent);
}

//------------------------------------------------------------
// Helper Functions for Log Reading
//------------------------------------------------------------


/* 
 * Read the first size_t variable from given file, and seek back
 * to position before read.
 * 
 * Parameters:
 *	FILE *logfile	: file to read from
 *	size_t *cursize	: pointer to location to store read size
 *
 * Return:
 *	On success  : 0
 *	On error    : -1
 *	On eof	    : -2
 */
int __peekcursize(FILE *logfile, size_t *cursize) {
    if (feof(logfile)) {
#ifdef LOGREAD_DEBUG 
	printf("__peekcursize:: reached eof\n");
#endif 
	return (-2);
    }
    if (0 == (fread(cursize, SIZE_SIZE, 1, logfile))) {
#ifdef LOGREAD_DEBUG
	printf("__peekcursize::read nothing from file\n");
#endif 
	return (-1);
    }

    //seek back to beginning of entry
    fseek(logfile, (long) (0 - SIZE_SIZE), SEEK_CUR);
    return (0);
}
